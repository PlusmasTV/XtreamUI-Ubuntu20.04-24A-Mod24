<?php
$rDebug = true;

if ($rDebug) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL & ~E_NOTICE);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
}

define( 'IPTV_ROOT_PATH', realpath(dirname(__FILE__)) );
define( 'IPTV_INCLUDES_PATH', IPTV_ROOT_PATH . '/includes/' );
define( 'IPTV_TEMPLATES_PATH', IPTV_ROOT_PATH . '/templates/' );
require ( IPTV_ROOT_PATH . "/second_init.php" );

?>