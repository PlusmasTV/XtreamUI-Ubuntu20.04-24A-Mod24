<?php
if ( ! @$argc )
{
    exit( 0 );
}

//ID Given?
if ( empty( $argv[1] ) || ! is_numeric( $argv[1] ) )
{
    echo "[*] Usage: php " . __file__ . " <STREAM_ID>\
";
    exit();
}

$stream_id = intval( $argv[1] );
define( 'IN_CHECKER', true );

require ( str_replace( "\\\\", "/", dirname( $argv[0] ) ) . '/init.php' );


$ipTV_db->query( "SELECT * FROM `streams` WHERE `id` = '%d' AND `pid` IS NOT NULL", $stream_id );
if ( $ipTV_db->num_rows() > 0 )
{
    $row = $ipTV_db->get_row();


    $stream_info = ( empty( $row['stream_info'] ) ) ? null : json_decode( $row['stream_info'], true );


    if ( empty( $stream_info ) || ! ps_running( $row['pid'] ) )
    {
        if ( $codecs = ipTV_Stream::GetCodecs( 'http://127.0.0.1:' . $row['dest_stream_port'] ) )
        {
            SetStatus( 0, $row['id'], $codecs );
            echo "[WORKS] => {$row['stream_display_name']}";
        }
        elseif ( $codecs = ipTV_Stream::GetCodecs( $row['stream_source'] ) )
        {
            //RESTREAM ERROR
            ipTV_Stream::StartStream( $row['id'] );
            sleep( 3 );
            if ( $codecs = ipTV_Stream::GetCodecs( 'http://127.0.0.1:' . $row['dest_stream_port'] ) )
            {
                SetStatus( 0, $row['id'], $codecs );
                echo "[WORKS] => {$row['stream_display_name']}";
            }
            else
            {
                SetStatus( 1, $row['id'] );
                ipTV_Stream::StartStream( $row['id'] );
                echo "[ERROR] => {$row['stream_display_name']}";
            }
        }
        else
        {
            //SOURCE IS DOWN
            SetStatus( 2, $row['id'] );
            ipTV_Stream::StartStream( $row['id'] );
            echo "[DOWN] => {$row['stream_display_name']}";
        }
    }
    else
    {
        if ( ! ipTV_Stream::StreamWorks( $row['dest_stream_port'] ) )
        {
            //VLC CRASHED
            ipTV_Stream::StartStream( $row['id'] );
            echo "[CRASHED] => {$row['stream_display_name']}";
        }
        else
            echo "[OK] => {$row['stream_display_name']}";
    }
}

function SetStatus( $status, $stream_id, $codecs = array() )
{
    global $ipTV_db;

    switch ( $status )
    {
        case 0:
            $ipTV_db->query( "UPDATE `streams` SET `problem_status` = 0,`stream_info` = '%s' WHERE `id` = '%d'", json_encode( $codecs ), $stream_id );
            $ipTV_db->query( "INSERT INTO `logs` (`stream_id`,`date`,`status`) VALUES('%d','%d','Works')", $stream_id, time() );
            break;

        case 1:
            $ipTV_db->query( "UPDATE `streams` SET `problem_status` = 1,`stream_info` = NULL WHERE `id` = '%d'", $stream_id );
            break;

        case 2:
            $ipTV_db->query( "UPDATE `streams` SET `problem_status` = 2,`stream_info` = NULL WHERE `id` = '%d'", $stream_id );
            break;
    }
}

?>
