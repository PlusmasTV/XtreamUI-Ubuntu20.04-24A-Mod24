<?php

ignore_user_abort( true );
register_shutdown_function( 'shutdown' );
ob_implicit_flush( true );
set_time_limit( 0 );

require('./init.php');

$bytes = 0;
$activity_id = 0;
$info = array();
if ( ! isset( ipTV_lib::$request['username'] ) || ! isset( ipTV_lib::$request['password'] ) || ! isset( ipTV_lib::$request['stream'] ) )
{
    die( "Missing parameters." );
}

$user_agent = ( empty( $_SERVER['HTTP_USER_AGENT'] ) ) ? "0" : trim( $_SERVER['HTTP_USER_AGENT'] );
$user_ip = $_SERVER['REMOTE_ADDR'];
$username = ipTV_lib::$request['username'];
$password = ipTV_lib::$request['password'];
$stream_id = intval( ipTV_lib::$request['stream'] );

if ( Is_BlockedIP( $user_ip ) )
{
    exit( "Your IP Is Blocked!" );
}


$ipTV_db->query( "SELECT * FROM streams WHERE `id` = '%d'", $stream_id );
if ( $ipTV_db->num_rows() > 0 )
{
    $info = $ipTV_db->get_row();

    $stream_name = ipTV_Stream::GetFixedStreamName( $info['stream_display_name'] );
    if ( $info['type'] == 'live' )
    {
        if ( ! ps_running( $info['pid'] ) )
        {
            die( 'Not Found' );
        }
    }
    else
    {
        if ( ps_running( $info['pid'] ) || ! file_exists( MOVIES_PATH . $stream_name . "/completed.xtream" ) )
        {
            die( 'Not Found' );
        }

        if ( $_SERVER['SERVER_PORT'] != 88 )
        {
            header( 'Location: http://' . ipTV_lib::$settings['site_url'] . ':88/' . $_SERVER['REQUEST_URI'] );
            exit( 0 );
        }
    }
}
else
{
    die( 'Not Found' );
}

$ipTV_db->query( "SELECT t1.`allowed_ips`,t1.`is_restreamer`,t1.allowed_bandwidth, t1.max_connections, t1.id, t1.exp_date, t2.bouquet_channels, (SELECT count(`user_activity`.`id`) FROM `user_activity` WHERE `user_activity`.`user_id` = t1.id AND ISNULL(`user_activity`.`date_end`)) active_connections
FROM  `users` t1, bouquets t2
WHERE t1.`status` =1
AND t1.`username` =  '%s'
AND t1.`password` =  '%s'
AND t1.`bouquet` = t2.id
LIMIT 1", $username, $password );

if ( $ipTV_db->num_rows() > 0 )
{

    //user found check expdate

    $user_info = $ipTV_db->get_row();
    $user_id = $user_info['id'];
    $user_bouquet_channels = $user_info['bouquet_channels'];
    $user_max_connections = $user_info['max_connections'];
    $user_allowed_bandwidth = $user_info['allowed_bandwidth'] * 1024 * 1024;
    $user_expire_date = $user_info['exp_date'];
    $active_cons = $user_info['active_connections'];
    $allowed_ips = unserialize( $user_info['allowed_ips'] );

    //ip blocked?
    if ( ! empty( $allowed_ips ) )
    {
        if ( ! in_array( $user_ip, $allowed_ips ) )
        {
            exit( "Your IP Is Blocked" );
        }
    }

    if ( time() <= $user_expire_date )
    {

        if ( Is_BlockedUA( $user_agent, $user_id ) )
        {
            exit( "Blocked" );
        }


        if ( $active_cons >= $user_max_connections )
        {

            $ipTV_db->query( "SELECT `id` FROM `user_activity` WHERE `user_id` = '%d' AND ISNULL(`date_end`) AND `user_ip` = '%s' ORDER BY `id` DESC LIMIT 1", $user_id, $user_ip );
            if ( $ipTV_db->num_rows() > 0 )
            {

                $id = $ipTV_db->get_col();
                if ( kick_activity( $id ) === true )
                {
                    --$active_cons;
                }
            }
        }

        if ( $active_cons < $user_max_connections )
        {

            $user_channels = @unserialize( $user_bouquet_channels );

            if ( in_array( $stream_id, $user_channels ) )
            {

                $ipTV_db->query( "INSERT INTO `user_activity` (`user_id`,`stream_id`,`user_agent`,`user_ip`,`pid`,`bandwidth`,`date_start`) VALUES('%d','%d','%s','%s','%d',0,'%d')", $user_id, $stream_id, $user_agent, $user_ip, getmypid(), time() );
                $activity_id = $ipTV_db->last_insert_id();

                $ipTV_db->close_mysql();

                if ( $info['type'] == 'live' )
                {
                    $context = stream_context_create( array( 'http' => array( 'timeout' => 3.0 ) ) );

                    $url = "http://127.0.0.1:" . $info['dest_stream_port'];

                    $file_handler = @fopen( $url, "rb", false, $context ) or die( "Stream Not Working" );


                    foreach ( $http_response_header as $h )
                    {
                        header( $h );
                    }

                    while ( ! feof( $file_handler ) && ClientConnected() )
                    {
                        if ( $user_allowed_bandwidth != 0 and $bytes > $user_allowed_bandwidth )
                        {
                            break;
                        }

                        $response = stream_get_line( $file_handler, 4096 );
                        $bytes += strlen( $response );
                        echo $response;
                    }

                    @fclose( $file_handler );

                }
                else
                {
                    $ext = strtolower( pathinfo( $info['movie_file'], PATHINFO_EXTENSION ) );
                    switch ( $ext )
                    {
                        case 'mkv':
                            header( 'Content-Type: video/x-matroska' );
                            break;

                        case 'mov':
                            header( 'Content-Type: video/quicktime' );
                            break;

                        case 'qt':
                            header( 'Content-Type: video/quicktime' );
                            break;

                        case 'mpg':
                            header( 'Content-Type: video/mpeg' );
                            break;

                        case 'mpeg':
                            header( 'Content-Type: video/mpeg' );
                            break;

                        case 'mpv2':
                            header( 'Content-Type: video/mpeg' );
                            break;

                        case 'mpe':
                            header( 'Content-Type: video/mpeg' );
                            break;

                        case 'mpa':
                            header( 'Content-Type: video/mpeg' );
                            break;

                        case 'mp2':
                            header( 'Content-Type: video/mpeg' );
                            break;

                        case 'mp4':
                            header( 'Content-type: video/mp4' );
                            break;

                        case 'asf':
                            header( 'Content-type: video/x-ms-asf' );
                            break;

                        case 'asr':
                            header( 'Content-type: video/x-ms-asf' );
                            break;

                        case 'asx':
                            header( 'Content-type: video/x-ms-asf' );
                            break;

                        case 'avi':
                            header( 'Content-type: video/x-msvideo' );
                            break;

                        case 'movie':
                            header( 'Content-type: video/x-sgi-movie' );
                            break;

                        default:
                            header( 'Content-Type: application/octet-stream' );
                    }

                    $request = MOVIES_PATH . $stream_name . '/' . $info['movie_file'];

                    $fp = @fopen( $request, 'rb' );

                    $size = filesize( $request ); // File size
                    $length = $size; // Content length
                    $start = 0; // Start byte
                    $end = $size - 1; // End byte

                    header( "Accept-Ranges: 0-$length" );
                    if ( isset( $_SERVER['HTTP_RANGE'] ) )
                    {

                        $c_start = $start;
                        $c_end = $end;

                        list( , $range ) = explode( '=', $_SERVER['HTTP_RANGE'], 2 );
                        if ( strpos( $range, ',' ) !== false )
                        {
                            header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
                            header( "Content-Range: bytes $start-$end/$size" );
                            exit;
                        }
                        if ( $range == '-' )
                        {
                            $c_start = $size - substr( $range, 1 );
                        }
                        else
                        {
                            $range = explode( '-', $range );
                            $c_start = $range[0];
                            $c_end = ( isset( $range[1] ) && is_numeric( $range[1] ) ) ? $range[1] : $size;
                        }
                        $c_end = ( $c_end > $end ) ? $end : $c_end;
                        if ( $c_start > $c_end || $c_start > $size - 1 || $c_end >= $size )
                        {
                            header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
                            header( "Content-Range: bytes $start-$end/$size" );
                            exit;
                        }
                        $start = $c_start;
                        $end = $c_end;
                        $length = $end - $start + 1;
                        fseek( $fp, $start );
                        header( 'HTTP/1.1 206 Partial Content' );
                    }

                    header( "Content-Range: bytes $start-$end/$size" );
                    header( "Content-Length: " . $length );


                    $buffer = 1024 * 8;
                    while ( ! feof( $fp ) && ClientConnected() && ( $p = ftell( $fp ) ) <= $end )
                    {
                        $response = fread( $fp, $buffer );
                        $bytes += strlen( $response );
                        echo $response;
                    }

                    fclose( $fp );
                    exit();
                }

            }
            else
            {
                echo "You are not allowed to view this channel";
            }
        }
        else
        {
            echo "Total Max Connections Reached";
        }
    }
    else
    {
        echo "User has expired";
    }
}
else
{
    echo "No User Found";
}

function ClientConnected()
{
    if ( connection_status() != CONNECTION_NORMAL || connection_aborted() )
    {
        return false;
    }

    return true;
}

function shutdown()
{
    global $ipTV_db, $bytes, $activity_id, $info;


    if ( $activity_id != 0 )
    {
        $ipTV_db->db_connect();
        $ipTV_db->query( "UPDATE `user_activity` SET `date_end` = '%d',`bandwidth` = '%d',`pid` = NULL WHERE `id` = '%d'", time(), $bytes, $activity_id );
    }

    if ( empty( $info['type'] ) || $info['type'] == 'live' )
    {
        posix_kill( getmypid(), 9 );
    }
    else
        exit;
}

function Is_BlockedIP( $ip )
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT `id` FROM `blocked_ips` WHERE `ip` = '%s' LIMIT 1", $ip );
    return $ipTV_db->num_rows() > 0;
}

function Is_BlockedUA( $user_agent, $user_id )
{
    global $ipTV_db;

    $user_agent = $ipTV_db->escape( $user_agent );
    $ipTV_db->simple_query( "SELECT * FROM `blocked_user_agents` WHERE (exact_match = 1 AND user_agent = '$user_agent') OR (exact_match = 0 AND INSTR('$user_agent',user_agent) > 0)" );


    if ( $ipTV_db->num_rows() > 0 )
    {
        $info = $ipTV_db->get_row();

        $ipTV_db->query( "UPDATE `blocked_user_agents` SET `attempts_blocked` = `attempts_blocked`+1 WHERE `id` = '%d'", $info['id'] );

        if ( $info['block_line'] == 1 )
        {
            $ipTV_db->query( "UPDATE `users` SET `status` = 0 WHERE `id` = '%d'", $user_id );
        }

        return true;
    }

    return false;
}

?>
