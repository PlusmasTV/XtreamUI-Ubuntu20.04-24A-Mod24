<div class="spacer"></div>
</section>
</body>

<script src="js/jquery.datetimepicker.js"></script>
<script>
    $('#expire_date').datetimepicker();
</script>
</html
