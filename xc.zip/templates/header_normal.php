<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-Frame-Options" content="deny">
    <title><?php echo ipTV_lib::$settings['server_name']; ?></title>

    <link rel="stylesheet" href="../templates/css/layout.css" type="text/css" media="screen" />
    <link rel="stylesheet" type="text/css" href="../templates/css/jquery.datetimepicker.css"/>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../templates/css/jquery-te-1.4.0.css"/>
    <link rel="stylesheet" type="text/css" href="../templates/css/jqueryFileTree.css" />

    <!--[if lt IE 9]>
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src="../templates/js/jquery.js" type="text/javascript"></script>
    <script src="../templates/js/hideshow.js" type="text/javascript"></script>
    <script type="text/javascript" src="../templates/js/jquery.tablednd_0_5.js"></script>
    <script src="../templates/js/jquery.tablesorter.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="../templates/js/jquery.equalHeight.js"></script>
    <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <script type="text/javascript" src="../templates/js/jqueryFileTree.js"></script>

    <script type="text/javascript" src="../templates/js/jquery-te-1.4.0.min.js"></script>

    <script type="text/javascript">

        function openDialog(){
            $("#dialog-explorer").dialog('open');
            return false;
        }



        function selectAll(selectBox,selectAll) {
            // have we been passed an ID
            if (typeof selectBox == "string") {
                selectBox = document.getElementById(selectBox);
            }
            // is the select box a multiple select box?
            if (selectBox.type == "select-multiple") {
                for (var i = 0; i < selectBox.options.length; i++) {
                    selectBox.options[i].selected = selectAll;
                }
            }
        }

        function ajax_request_dialog(site_url,title,custom_background,custom_width,custom_height)
        {
            if(typeof(custom_background)==='undefined') custom_background = 'white';
            if(typeof(custom_width)==='undefined') custom_width = '1020';
            if(typeof(custom_height)==='undefined') custom_height = '700';
            if(typeof(debug)==='undefined') debug = '';


            $("#dialogDiv").dialog({autoOpen:false,modal:true,width:custom_width,height:custom_height,resizeable:true});



            $("#dialogDiv").dialog({title: title});
            $("#dialogDiv").dialog('open');
            $('.ui-widget-overlay').css('background', 'white');
            $('.ui-dialog-content').css('background', custom_background);
            $('#dialogDiv').html("<center><img src='../templates/images/big_load.GIF' /><br /><?php echo $_LANG['please_wait']; ?></center>");
            $.ajax({
                url: site_url,
                success: function(response)
                {
                    $('#dialogDiv').html(response);
                }
            });
        }


        $(document).ready(function() {


                $(".tablesorter").tablesorter();



            }
        );

        $(function(){
            $('.column').equalHeight();
        });
    </script>

</head>
<body>

 <header id="header">
  <hgroup>
   <h1 class="site_title"><a href="index.php">IPTV</a></h1>
   <h2 class="section_title"><?php echo $_LANG['user_panel']; ?></h2>
  </hgroup>
 </header>
 
 <section id="secondary_bar">
  <div class="user">
   <p><?php echo $mcMember->member_info['username']; ?> (<a href="index.php?action=logout"><u><?php echo $_LANG['logout']; ?></u></a>)</p>
  </div>

 </section>
 
 <aside id="sidebar" class="column">
  <form class="logo">
   <img src="<?php echo ipTV_lib::$settings['logo_url']; ?>" width="70%" />
  </form>
  <hr/>
  <h3><?php echo $_LANG['stream_accs']; ?></h3>
  <ul class="toggle">
            <li class="icn_acc"><a href="index.php"><?php echo $_LANG['manage_accs']; ?></a></li>
  </ul>         
  <footer>
   <hr />
   <p>
             <?php
            
            if ( ipTV_lib::$settings['copyrights_removed'] == 0 )
            {
                echo "<strong>Copyright &copy; ".date("Y")." <a target='_blank' href='http://xtream-codes.com'>Xtream-Codes</a> v".SCRIPT_VERSION."</strong>";
            }
            else
            {
                echo ipTV_lib::$settings['copyrights_text'];
            }
            
            ?> 
            
            </p>

  </footer>
 </aside><!-- end of sidebar -->
    <section id="main" class="column">