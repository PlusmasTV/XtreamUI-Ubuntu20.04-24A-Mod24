<!DOCTYPE html>
<html>
<head>
    <title><?php echo ipTV_lib::$settings['server_name']; ?></title>
    <link rel="stylesheet" type="text/css" href="./templates/css/login.css" />
</head>

<body>

<form id="login" method="post" action="index.php?action=login">
    <h1><?php echo $_LANG['login']; ?></h1>
    <div id="main">
        <?php
        if(!empty($er_message))
            echo show_message('error',$er_message);

        if(!empty($warn_message))
            echo show_message('warning',$warn_message);

        if(!empty($ok_message))
            echo show_message('ok',$ok_message);
        ?>
        <br />
    </div>
    <fieldset id="inputs">
        <input id="username" type="text" placeholder="<?php echo $_LANG['username']; ?>" name="login" autofocus required>
        <input id="password" type="password" name="pass" placeholder="<?php echo $_LANG['password']; ?>" required>
    </fieldset>
    <fieldset id="actions">
        <input type="submit" id="submit" value="Log in">
        <a href="index.php?action=forgot"><?php echo $_LANG['forgot']; ?></a><a href="index.php?action=register"><?php echo $_LANG['register']; ?></a>
    </fieldset>

    <?php

    if ( ipTV_lib::$settings['copyrights_removed'] == 0 )
    {
        echo "<div id='back'>Copyright &copy; ".date("Y")." <a target='_blank' href='http://xtream-codes.com/'>Xtream-Codes</a> v" . SCRIPT_VERSION . "</div>";
}
    else
    {
        echo "<div id='back'>".ipTV_lib::$settings['copyrights_text']."</div>";
}

    ?>
</form>

</body>
</html>