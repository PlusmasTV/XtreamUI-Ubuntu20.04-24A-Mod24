<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-Frame-Options" content="deny">
    <title><?php echo ipTV_lib::$settings['server_name']; ?></title>

    <link rel="stylesheet" href="../templates/css/layout.css" type="text/css" media="screen" />
    <link rel="stylesheet" type="text/css" href="../templates/css/jquery.datetimepicker.css"/>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../templates/css/jquery-te-1.4.0.css"/>
    <link rel="stylesheet" type="text/css" href="../templates/css/jqueryFileTree.css" />

    <!--[if lt IE 9]>
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src="../templates/js/jquery.js" type="text/javascript"></script>
    <script src="../templates/js/hideshow.js" type="text/javascript"></script>
    <script type="text/javascript" src="../templates/js/jquery.tablednd_0_5.js"></script>
    <script src="../templates/js/jquery.tablesorter.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="../templates/js/jquery.equalHeight.js"></script>
    <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <script type="text/javascript" src="../templates/js/jqueryFileTree.js"></script>

    <script type="text/javascript" src="../templates/js/jquery-te-1.4.0.min.js"></script>

    <script type="text/javascript">

        function openDialog(){
            $("#dialog-explorer").dialog('open');
            return false;
        }



        function selectAll(selectBox,selectAll) {
            // have we been passed an ID
            if (typeof selectBox == "string") {
                selectBox = document.getElementById(selectBox);
            }
            // is the select box a multiple select box?
            if (selectBox.type == "select-multiple") {
                for (var i = 0; i < selectBox.options.length; i++) {
                    selectBox.options[i].selected = selectAll;
                }
            }
        }

        function ajax_request_dialog(site_url,title,custom_background,custom_width,custom_height)
        {
            if(typeof(custom_background)==='undefined') custom_background = 'white';
            if(typeof(custom_width)==='undefined') custom_width = '1020';
            if(typeof(custom_height)==='undefined') custom_height = '700';
            if(typeof(debug)==='undefined') debug = '';


            $("#dialogDiv").dialog({autoOpen:false,modal:true,width:custom_width,height:custom_height,resizeable:true});



            $("#dialogDiv").dialog({title: title});
            $("#dialogDiv").dialog('open');
            $('.ui-widget-overlay').css('background', 'white');
            $('.ui-dialog-content').css('background', custom_background);
            $('#dialogDiv').html("<center><img src='../templates/images/big_load.GIF' /><br /><?php echo $_LANG['please_wait']; ?></center>");
            $.ajax({
                url: site_url,
                success: function(response)
                {
                    $('#dialogDiv').html(response);
                }
            });
        }


        $(document).ready(function() {


                $(".tablesorter").tablesorter();



            }
        );

        $(function(){
            $('.column').equalHeight();
        });
    </script>

</head>
<body>

<header id="header">
    <hgroup>
        <h1 class="site_title"><a href="index.php">IPTV</a></h1>
        <h2 class="section_title"><?php echo $_LANG['admin_panel']; ?></h2>
    </hgroup>
</header>

<section id="secondary_bar">
    <div class="user">
        <p><?php echo $mcMember->member_info['username']; ?> (<a href="index.php?action=logout"><u><?php echo $_LANG['logout']; ?></u></a>)</p>
    </div>

</section>

<aside id="sidebar" class="column">
    <form class="logo">
        <img src="<?php echo ipTV_lib::$settings['logo_url']; ?>" width="70%" />
    </form>
    <hr/>
    <h3><?php echo $_LANG['main']; ?></h3>
    <ul class="toggle">
        <li class="icn_dashboard"><a href="index.php"><?php echo $_LANG['dashboard']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['streams']; ?></h3>
    <ul class="toggle">
        <li class="icn_add"><a href="add_stream.php"><?php echo $_LANG['new_stream']; ?></a></li>
        <li class="icn_streams"><a href="streams.php"><?php echo $_LANG['manage_streams']; ?></a></li>
        <li class="icn_massedit"><a href="mass_sedits.php"><?php echo $_LANG['mass_edit']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['movies']; ?></h3>
    <ul class="toggle">
        <li class="icn_addmovie"><a href="add_movie.php"><?php echo $_LANG['new_movie']; ?></a></li>
        <li class="icn_add_movies"><a href="import_movies.php"><?php echo $_LANG['import_movies']; ?></a></li>
        <li class="icn_movie"><a href="movies.php"><?php echo $_LANG['manage_movies']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['categories']; ?></h3>
    <ul class="toggle">
        <li class="icn_categories"><a href="categories.php"><?php echo $_LANG['manage_categories']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['reg_users']; ?></h3>
    <ul class="toggle">
        <li class="icn_add_user"><a href="add_reguser.php"><?php echo $_LANG['new_reguser']; ?></a></li>
        <li class="icn_manage_users"><a href="mng_regusers.php"><?php echo $_LANG['manage_regusers']; ?></a></li>
        <li class="icn_group"><a href="mng_groups.php"><?php echo $_LANG['manage_groups']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['stream_accs']; ?></h3>
    <ul class="toggle">
        <li class="icn_add_user"><a href="add_user.php"><?php echo $_LANG['new_acc']; ?></a></li>
        <li class="icn_acc"><a href="users.php"><?php echo $_LANG['manage_accs']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['bouquets']; ?></h3>
    <ul class="toggle">
        <li class="icn_add"><a href="add_bouquet.php"><?php echo $_LANG['add_bouquet']; ?></a></li>
        <li class="icn_manage"><a href="bouquets.php"><?php echo $_LANG['manage_bouquet']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['security']; ?></h3>
    <ul class="toggle">
        <li class="icn_block"><a href="block_ips.php"><?php echo $_LANG['block_ips']; ?></a></li>
        <li class="icn_ua"><a href="user_agents.php"><?php echo $_LANG['user_agents']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['logs']; ?></h3>
    <ul class="toggle">
        <li class="icon_connections"><a href="connection_logs.php"><?php echo $_LANG['connection_logs']; ?></a></li>
        <li class="icn_logs"><a href="logs.php"><?php echo $_LANG['stream_logs']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['settings']; ?></h3>
    <ul class="toggle">
        <li class="icn_settings"><a href="settings.php"><?php echo $_LANG['general_settings']; ?></a></li>
        <li class="icn_email_settings"><a href="mail_settings.php"><?php echo $_LANG['mail_settings']; ?></a></li>
        <li class="icn_email"><a href="emailmsg.php"><?php echo $_LANG['email_msg']; ?></a></li>

    </ul>
    <h3><?php echo $_LANG['system']; ?></h3>
    <ul class="toggle">
        <li class="icn_database"><a href="database.php"><?php echo $_LANG['database']; ?></a></li>
        <li class="icn_task"><a href="task_manager.php"><?php echo $_LANG['task']; ?></a></li>
        <li class="icn_tools"><a href="tools.php"><?php echo $_LANG['tools']; ?></a></li>
    </ul>
    <h3><?php echo $_LANG['xtream_codes']; ?></h3>
    <ul class="toggle">
        <li class="icn_licence"><a href="licence.php"><?php echo $_LANG['licence']; ?></a></li>
        <li class="icn_update"><a href="update.php"><?php echo $_LANG['update']; ?></a></li>
        <li class="icn_area"><a href="member_area.php"><?php echo $_LANG['member_area']; ?></a></li>
    </ul>
    <footer>
        <hr />
        <p>
            <?php

            if ( ipTV_lib::$settings['copyrights_removed'] == 0 )
            {
                echo "<strong>Copyright &copy; ".date("Y")." <a target='_blank' href='http://xtream-codes.com/'>Xtream-Codes</a> v" . SCRIPT_VERSION . "</strong>";
                }
            else
            {
                echo ipTV_lib::$settings['copyrights_text'];
            }

            ?>
        </p>

    </footer>
</aside><!-- end of sidebar -->
<section id="main" class="column">