<!DOCTYPE html>
<html>
<head>
    <title><?php echo ipTV_lib::$settings['server_name']; ?></title>
    <link rel="stylesheet" type="text/css" href="./templates/css/login.css" />
</head>

<body>

<form id="login" method="post" action="index.php?action=register">
    <h1><?php echo $_LANG['register']; ?></h1>
    <div id="main">
        <?php
        if(!empty($er_message))
            echo show_message('error',$er_message);

        if(!empty($warn_message))
            echo show_message('warning',$warn_message);

        if(!empty($ok_message))
            echo show_message('ok',$ok_message);
        ?>
        <br />
    </div>
    <fieldset id="inputs">
        <input id="username" type="text" autocomplete="off" name="login" placeholder="<?php echo $_LANG['username']; ?>" autofocus required>
        <input id="password" type="password" autocomplete="off" name="pass" placeholder="<?php echo $_LANG['password']; ?>" required>
        <input id="password" type="password" autocomplete="off" name="pass_confirm" placeholder="<?php echo $_LANG['confirm_password']; ?>" required>
        <input  type="text" name="email"  placeholder="<?php echo $_LANG['email']; ?>" required>
    </fieldset>
    <fieldset id="actions">
        <input type="submit" id="submit" value="<?php echo $_LANG['register']; ?>">
        <a href="index.php"><?php echo $_LANG['login']; ?></a><a href="index.php?action=forgot"><?php echo $_LANG['forgot']; ?></a>
    </fieldset>
    <?php

    if ( ipTV_lib::$settings['copyrights_removed'] == 0 )
    {
        echo "<div id='back'>Copyright &copy; 2014 <a target='_blank' href='http://xtream-codes.com/'>Xtream-Codes</a> v" . SCRIPT_VERSION . "</div>";
}
    else
    {
        echo "<div id='back'>".ipTV_lib::$settings['copyrights_text']."</div>";
}

    ?>
</form>

</body>
</html>