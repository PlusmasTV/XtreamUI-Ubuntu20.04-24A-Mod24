<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_bouquet']; ?></h3>
        </header>

        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['bouquet_name1']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>

            <tbody>
            <?php
            foreach($bouquets as $bouquet)
            {


                echo "<tr>";
                echo  "<td><font color='orange'>" . $bouquet['bouquet_name'] . "</font></td>";
                             ?>           
<td>
    <a href="edit_bouquet.php?bouquet_id=<?php echo $bouquet['id']; ?>" class="table-icon edit" title="<?php echo $_LANG['edit_bouquet']; ?>"></a>
    <a onclick="return confirm('<?php echo $_LANG['delete_bouquet']; ?>)" href="bouquets.php?action=bouq_delete&bouquet_id=<?php echo $bouquet['id']; ?>" class="table-icon delete" title="<?php echo $_LANG['delete_bouquet']; ?>"></a>
</td>
</tr>
                        <?php } ?>
            </tbody>
        </table>
    </article>
<?php } ?>