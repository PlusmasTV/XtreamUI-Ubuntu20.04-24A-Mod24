<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['add_bouquet']; ?></h3>
        </header>
        <form method="post" onsubmit="selectAll('bouquet_selection',true);"  action="add_bouquet.php?action=add_bouquet">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['bouquet_name1']; ?></b></legend>

                    <center>
                        <table id="bouquet">
                            <tr>
                                <td><?php echo $_LANG['bouquet_name1'] ;?></td>
                                <td><input type="text" name="bouquet_name" value="" /></td>
                            </tr>
                        </table>
                    </center>

                </fieldset>
                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['select_streams']; ?></b></legend>

                    <center>
                        <table id="bouquet">
                            <tr>
                                <td><?php echo $_LANG['live_streams_select']; ?></td>
                                <td><?php echo $_LANG['movies_select']; ?></td>
                            </tr>
                            <tr>
                                <td style="width: 40%;">
                                    <select style="width:300px;" id="select-from1" name="streams[]" size="20" multiple="multiple" >
                                        <?php
                                        foreach($streams as $stream)
                                        {
                                            if($stream['type'] == 'movie')
                                            {
                                                continue;
                                            }
                                            echo "<option value='{$stream['id']}'>[LIVE] {$stream['stream_display_name']}</option>";
                                            }
                                        ?>
                                    </select>
                                </td>
                                <td style="width: 40%;">
                                    <select style="width:300px;" id="select-from2" name="movies[]" size="20" multiple="multiple" >
                                        <?php
                                        foreach($streams as $stream)
                                        {
                                            if($stream['type'] == 'live')
                                            {
                                                continue;
                                            }
                                            echo "<option value='{$stream['id']}'>[MOVIE] {$stream['stream_display_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="button" onclick="JavaScript:void(0);" class="alt_btn" value="Add" id="btn-add" />

                                </td>
                            </tr>
                        </table>
                    </center>

                </fieldset>

                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['your_bouquet']; ?></b></legend>

                    <center>
                        <table id="bouquet">
                            <tr>
                                <td colspan="3">
                                    <input type="button" onclick="JavaScript:void(0);" class="alt_btn"value="Remove" id="btn-remove" />
                                    <input type="button" onclick="JavaScript:void(0);" class="alt_btn"value="Move Up" id="btn-up" />
                                    <input type="button" onclick="JavaScript:void(0);" class="alt_btn"value="Move Down" id="btn-down" />
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%;">
                                    <select style="width:300px;" id="bouquet_selection" name="bouquet_selection[]" size="20" multiple="multiple"></select>
                                </td>
                            </tr>

                        </table>

                    </center>

                </fieldset>


            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['add_bouquet']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $(document).ready(function() {
        $('#btn-add').click(function(){
            $('#select-from1 option:selected').each( function() {
                $('#bouquet_selection').append("<option value='"+$(this).val()+"'>"+$(this).text()+"</option>");
                $(this).remove();
            });

            $('#select-from2 option:selected').each( function() {
                $('#bouquet_selection').append("<option value='"+$(this).val()+"'>"+$(this).text()+"</option>");
                $(this).remove();
            });
        });
        $('#btn-remove').click(function(){
            $('#bouquet_selection option:selected').each( function() {

                var value = $(this).val();
                var type = $(this).text();
                if(type.substr(0, 6) == "[LIVE]")
                {
                    $('#select-from1').append("<option value='"+value+"'>"+type+"</option>");
                }
                else
                {
                    $('#select-from2').append("<option value='"+value+"'>"+type+"</option>");
                }

                $(this).remove();
            });
        });
        $('#btn-up').bind('click', function() {

            $('#bouquet_selection option:selected').each( function() {
                var newPos = $('#bouquet_selection option').index(this) - 1;
                if (newPos > -1) {
                    $('#bouquet_selection option').eq(newPos).before("<option value='"+$(this).val()+"' selected='selected'>"+$(this).text()+"</option>");
                    $(this).remove();
                }
            });
        });

        $('#btn-down').bind('click', function() {
            var countOptions = $('#bouquet_selection option').size();
            $('#bouquet_selection option:selected').each( function() {
                var newPos = $('#bouquet_selection option').index(this) + 1;
                if (newPos < countOptions) {
                    $('#bouquet_selection option').eq(newPos).after("<option value='"+$(this).val()+"' selected='selected'>"+$(this).text()+"</option>");
                    $(this).remove();
                }
            });
        });
    });
</script> 