<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_regusers']; ?></h3>
        </header>

        <div id="dialogDiv" style="display: none;"><?php echo $_LANG['loading']; ?></div>

        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['verified']; ?></th>
                <th><?php echo $_LANG['username']; ?></th>
                <th><?php echo $_LANG['member_group']; ?></th>
                <th><?php echo $_LANG['ip']; ?></th>
                <th><?php echo $_LANG['total_lines']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach($registered_users as $registered_user)
            {
                echo "<tr>";

                if($registered_user['verified'] == 1)
                {
                    echo "<td><img src='../templates/images/ok.png' /></td>";
                }
                else
                {
                    echo "<td><img src='../templates/images/wrong.png' /></td>";
                }

                echo "<td bgcolor=''><font color='black'>" . $registered_user['username'] . "</font></td>";
                                echo "<td bgcolor=''><font color='{$registered_user['group_color']}'>" . $registered_user['group_name'] . "</font></td>";
                                $user_ip = (is_null($registered_user['ip'])) ? "-" : $registered_user['ip'];
                                echo "<td bgcolor=''><font color='black'>" . $user_ip . "</font></td>";
                                echo "<td bgcolor=''><font color='black'>" . $registered_user['total_lines'] . "</font></td>";

                            ?>
                            <td bgcolor="">
                                <a href="edit_reguser.php?user_id=<?php echo $registered_user['id']; ?>" class="table-icon edit" title="<?php echo $_LANG['edit_user']; ?>"></a>
                                <a onclick="return confirm('<?php echo $_LANG['delete_reg_user']; ?>')" href="mng_regusers.php?action=user_delete&user_id=<?php echo $registered_user['id']; ?>" class="table-icon delete" title="<?php echo $_LANG['delete_user']; ?>"></a>
                            </td>
                            <?php
                            }
            ?>
            </tbody>
        </table>
    </article>
<?php } ?>

<script type="text/javascript">

    $(document).ready(function() {
        $('.menu').dropit();
    });
</script>