<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['block_ua'];?></h3></header>
        <form method="post" action="user_agents.php?action=block">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['block_ua']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['enter_ua']; ?> (<font color="red"><?php echo $_LANG['block_ua_explain']; ?></font>)</td>
                            <td><input type="text"  name="user_agent"  /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['use_exact_match']; ?> </td>
                            <td>
                                <select name="exact_match">
                                    <option value="0" selected><?php echo $_LANG['no']; ?></option>
                                    <option value="1"><?php echo $_LANG['yes']; ?></option>
                                </select>
                            </td>
                        <tr>
                        <tr>
                            <td><?php echo $_LANG['block_lines_ua']; ?> </td>
                            <td>
                                <select name="block_line">
                                    <option value="0" selected><?php echo $_LANG['no']; ?></option>
                                    <option value="1"><?php echo $_LANG['yes']; ?></option>
                                </select>
                            </td>
                        <tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['block_ua'];?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>

    <?php
    if(!empty($user_agents))
    {
        ?>
        <article class="module width_full">
            <header><h3 class="tabs_involved"><?php echo $_LANG['user_agent_block_list']; ?></h3></header>
            <table class="tablesorter" cellspacing="0" >
                <thead>
                <tr>
                    <th><?php echo $_LANG['user_agent']; ?></th>
                    <th><?php echo $_LANG['use_exact_match']; ?></th>
                    <th><?php echo $_LANG['block_line']; ?></th>
                    <th><?php echo $_LANG['blocked_attempts']; ?></th>
                    <th><?php echo $_LANG['options']; ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach($user_agents as $user_agent)
                {
                    echo "<tr>";


                    echo "<td><b>{$user_agent['user_agent']}</b></td>";
                    if($user_agent['exact_match'] == 1)
                    {
                        echo "<td><b><font color='red'>Yes</font></b></td>";
                    }
                    else
                    {
                        echo "<td><b><font color='green'>No</font></b></td>";
                    }
                    if($user_agent['block_line'] == 1)
                    {
                        echo "<td><b><font color='red'>Yes</font></b></td>";
                    }
                    else
                    {
                        echo "<td><b><font color='green'>No</font></b></td>";
                    }

                    echo "<td><b><font size='3'>{$user_agent['attempts_blocked']}</font></b></td>";

                    ?>
                    <td>
                        <a onclick="return confirm('<?php echo $_LANG['unblock_ua']; ?>')" href="user_agents.php?action=unblock&id=<?php echo $user_agent['id']; ?>" class="table-icon enable" title="UnBlock UA"></a>
                    </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </article>
    <?php } ?>
<?php } ?>