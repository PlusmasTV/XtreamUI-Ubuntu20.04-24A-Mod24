<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['new_movie']; ?></h3>
        </header>
        <!-- file picker -->
        <div id="dialog-explorer" title="File Browser"  style="display: none;">
            <div id="dialogContent"></div>
        </div>


        <form method="post" action="add_movie.php?action=add_movie">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['movies_options']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['movie_name']; ?></td>
                            <td><input type="text"  name="movie_name" required /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['movie_location']; ?></td>
                            <td>
                                <select name="movie_location" id="movie_location">
                                    <option value="">-</option>
                                    <option value="local"><?php echo $_LANG['location_local']; ?></option>
                                    <option value="remote"><?php echo $_LANG['location_remote']; ?></option>
                                </select>
                            </td>
                        </tr>


                        <tr id="local" style="display:none">
                            <td><?php echo $_LANG['movie_source']; ?></td>
                            <td><input id="input" type="text" name="movie_source_local" /></td>
                            <td><div class="submit_link"><input type="button" value="<?php echo $_LANG['pick_movie']; ?>" class="alt_btn" onclick="openDialog();"></div></td>
                        </tr>

                        <tr id="remote" style="display:none">
                            <td><?php echo $_LANG['movie_source']; ?></td>
                            <td><input type="text" name="movie_source_remote" value="" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['category_name']; ?></td>
                            <td>
                                <select name="category_id">
                                    <option value=""><?php echo $_LANG['dont_use_category']; ?></option>
                                    <?php
                                    foreach($categories as $category)
                                    {
                                        echo "<option value='{$category['id']}'>{$category['category_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><?php echo $_LANG['transcode_movie']; ?> (<font color="red"><?php echo $_LANG['transcode_movie_desc']; ?></font>)</td>
                            <td><input type="radio" class="tm" name="transcode_movie" value="1"  checked/> <?php echo $_LANG['yes']; ?> <input type="radio" class="tm" name="transcode_movie" value="0" /> <?php echo $_LANG['no']; ?>
                        </tr>

                        <tr id="read_native">
                            <td><?php echo $_LANG['read_non_native']; ?> (<font color="red"><?php echo $_LANG['warning_cpu']; ?></font>)</td>
                            <td><input type="radio" name="go_faster" value="1" checked/> <?php echo $_LANG['yes']; ?> <input type="radio" name="go_faster" value="0" /> <?php echo $_LANG['no']; ?></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['movie_subtitles']; ?></td>
                            <td><input type="text" name="movie_subtitles"  /></td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['new_movie']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $(document).ready(function() {

        $("#dialog-explorer").dialog({
            autoOpen: false,
            width: $(document).width()*0.3,
            height: $(document).height()*0.50,
            //zIndex: 1000000000,
            buttons: {
                "I'm Done": function () {
                    $(this).dialog("close");
                }
            }
        });

        $('#dialogContent').fileTree({root: '/', script: 'filexplorer.php', multiFolder: false, loadMessage: 'Loading files...'},
            function(file) {
                $("#input").val(file);
                $("#dialog-explorer").dialog("close");
            },
            function(dire){ $("#input").val(dire);  }
        );

        $(".tm").change(function () {
            var value = $(this).val();
            if(value == "0")
            {
                $('#read_native').fadeOut();
            }
            else
            {
                $('#read_native').fadeIn();
            }
        });

        $('#movie_location').click(function(){
            var value = $(this).val();

            if(value == "local")
            {
                $('#local').fadeIn();
                $('#remote').fadeOut();
            }
            else if(value == "remote")
            {
                $('#local').fadeOut();
                $('#remote').fadeIn();
            }
            else
            {
                $('#local').fadeOut();
                $('#remote').fadeOut();
            }
        });
    });
</script>