<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
    <header><h3 class="tabs_involved"><?php echo $_LANG['member_area']; ?></h3>
    </header>
    <div class="module_content">
        <p align="center"><?php echo $_LANG['member_area_desc']; ?></p>
        <table width="100%">
            <tr>
                <td>
                    <iframe width="100%" height="500" scrolling="auto" src="http://www.xtream-codes.com/licences/"></iframe>
                </td>
            </tr>
        </table>
    </div>
<?php } ?>