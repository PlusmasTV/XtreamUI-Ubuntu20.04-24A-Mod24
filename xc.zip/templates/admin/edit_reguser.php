<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['edit_reguser']; ?></h3>
        </header>
        <form method="post" name="form" action="edit_reguser.php?action=edit_user&user_id=<?php echo $info['id']; ?>">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['user_details']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['username']; ?></td>
                            <td><input type="text" name="username" value="<?php echo $info['username']; ?>" required/></td>
                        <tr>
                            <td><?php echo $_LANG['password']; ?> (<font color="red"><?php echo $_LANG['reset']; ?></font>)</td>
                            <td><input type="text" name="password"/></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['email']; ?></td>
                            <td><input type="text" name="email" value="<?php echo $info['email']; ?>" required/></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['member_group']; ?></td>
                            <td>
                                <select name="member_group_id">
                                    <?php
                                    foreach($member_groups as $member_group)
                                    {
                                        if($member_group['id'] == $info['member_group_id'])
                                            echo "<option value='{$member_group['id']}' selected>{$member_group['group_name']}</option>";
                                            else
                                        echo "<option value='{$member_group['id']}'>{$member_group['group_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['edit_reguser']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>