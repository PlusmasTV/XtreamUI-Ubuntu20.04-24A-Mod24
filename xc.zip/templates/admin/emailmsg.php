<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['email_msg']; ?></h3>
        </header>
        <form action="emailmsg.php?action=save" method="post">
            <div class="module_content">
                <form method="post" action="emailmsg.php?action=save">
                    <fieldset>
                        <legend><b><?php echo $_LANG['email_msg']; ?></b></legend>
                        <table id="settings">
                            <tr>
                                <td><?php echo $_LANG['email_verify_edit']; ?></td>
                                <td><input type="text" name="email_verify_sub" size="100" value="<?php echo ipTV_lib::$settings['email_verify_sub']; ?>" /></td>
                            </tr>
                            <tr>
                                <td colspan="2"><textarea class="editor" name="email_verify_cont"><?php echo ipTV_lib::$settings['email_verify_cont']; ?></textarea></td>
                            </tr>

                            <tr>
                                <td><?php echo $_LANG['email_forgot_edit']; ?></td>
                                <td><input type="text" name="email_forgot_sub" size="100" value="<?php echo ipTV_lib::$settings['email_forgot_sub']; ?>" /></td>
                            </tr>
                            <tr>
                                <td colspan="2"><textarea class="editor" name="email_forgot_cont"><?php echo ipTV_lib::$settings['email_forgot_cont']; ?></textarea></td>
                            </tr>

                            <tr>
                                <td><?php echo $_LANG['email_new_pass_edit']; ?></td>
                                <td><input type="text" name="email_new_pass_sub" size="100" value="<?php echo ipTV_lib::$settings['email_new_pass_sub']; ?>" /></td>
                            </tr>
                            <tr>
                                <td colspan="2"><textarea class="editor" name="email_new_pass_cont"><?php echo ipTV_lib::$settings['email_new_pass_cont']; ?></textarea></td>
                            </tr>

                        </table>
                    </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['save_settings']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $('.editor').jqte();
</script>