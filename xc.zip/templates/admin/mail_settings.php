<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['mail_settings']; ?></h3>
        </header>
        <form action="mail_settings.php?action=save" method="post">
            <div class="module_content">
                <fieldset>
                    <legend><b><?php echo $_LANG['mail_settings']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['use_remote_smtp']; ?></td>
                            <td><input type="radio" name="use_remote_smtp" value="1" <?php if (ipTV_lib::$settings['use_remote_smtp'] == 1) echo 'checked'; ?>/> Yes <input type="radio" name="use_remote_smtp" value="0" <?php if (ipTV_lib::$settings['use_remote_smtp'] != 1) echo 'checked'; ?>/> No</td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['mail_from']; ?></td>
                            <td><input type="text" name="mail_from" value="<?php echo ipTV_lib::$settings['mail_from']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['smtp_host']; ?></td>
                            <td><input type="text" name="smtp_host" value="<?php echo ipTV_lib::$settings['smtp_host']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['smtp_encryption']; ?></td>
                            <td><input type="radio" name="smtp_encryption" value="ssl" <?php if (ipTV_lib::$settings['smtp_encryption'] == 'ssl') echo 'checked'; ?>/> SSL <input type="radio" name="smtp_encryption" value="tls" <?php if (ipTV_lib::$settings['smtp_encryption'] == 'tls') echo 'checked'; ?>/> TLS <input type="radio" name="smtp_encryption" value="no" <?php if (ipTV_lib::$settings['smtp_encryption'] == 'no') echo 'checked'; ?>/> No Encryption</td>

                        </tr>

                        <tr>
                            <td><?php echo $_LANG['smtp_username']; ?></td>
                            <td><input type="text" name="smtp_username" value="<?php echo ipTV_lib::$settings['smtp_username']; ?>" /></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['smtp_password']; ?></td>
                            <td><input type="text" name="smtp_password" value="<?php echo ipTV_lib::$settings['smtp_password']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['smtp_from_name']; ?></td>
                            <td><input type="text" name="smtp_from_name" value="<?php echo ipTV_lib::$settings['smtp_from_name']; ?>" /></td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="Save Settings" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script type="text/javascript">

    $(document).ready(function(){
        $(document).on('click', '.use_remote_smtp input:checkbox', function() {

            $(this).closest('.use_remote_smtp').next('.remote')[this.checked? 'hide' : 'show']()
        });

    });

</script>
</script>