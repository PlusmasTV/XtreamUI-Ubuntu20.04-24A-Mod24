<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_categories']; ?></h3></header>
        <form method="post" action="categories.php?action=add">
            <div class="module_content">


                <fieldset>
                    <legend><b><?php echo $_LANG['new_category']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['category_name']; ?></td>
                            <td><input type="text"  name="category_name"  required/></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['category_type']; ?></td>
                            <td>
                                <select name="category_type">
                                    <option value="live"><?php echo $_LANG['live']; ?></option>
                                    <option value="movie"><?php echo $_LANG['movie']; ?></option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['do_it']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>

    <?php
    if(!empty($categories))
    {
        ?>
        <article class="module width_full">
            <header><h3 class="tabs_involved"><?php echo $_LANG['manage_categories']; ?></h3></header>
            <table class="tablesorter" cellspacing="0" >
                <thead>
                <tr>
                    <th><?php echo $_LANG['category_name']; ?></th>
                    <th><?php echo $_LANG['category_type']; ?></th>
                    <th><?php echo $_LANG['total_streams']; ?></th>
                    <th><?php echo $_LANG['options']; ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach($categories as $category)
                {
                    echo "<tr>";


                    echo "<td><b>{$category['category_name']}</b></td>";
                    echo "<td><b>{$category['category_type']}</b></td>";
                    echo "<td><b>{$category['total_movies']}</b></td>";
                    ?>
                    <td>
                        <a onclick="return confirm('<?php echo $_LANG['delete_category_confirm']; ?>')" href="categories.php?action=delete&id=<?php echo $category['id']; ?>" class="table-icon delete" title="<?php echo $_LANG['delete_category']; ?>"></a>
                    </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </article>
    <?php } ?>
<?php } ?>