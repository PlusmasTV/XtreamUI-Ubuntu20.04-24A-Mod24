<?php
if(!empty($er_message))
    echo show_message('error',$er_message);

if(!empty($warn_message))
    echo show_message('warning',$warn_message);

if(!empty($info_message))
    echo show_message('info',$info_message);

if(!empty($ok_message))
    echo show_message('ok',$ok_message);
?>
<style>#g1,#g2,#g3{width:200px;height:160px;display:inline-block;margin:1em;}p{display:block;width:450px;margin:2em auto;text-align:left;}</style>
<article class="module width_full">
    <header><h3><?php echo $_LANG['stats']; ?></h3></header>
    <div class="module_content">


        <center>
            <div id="g2"></div>
            <div id="g1"></div>
            <div id="g3"></div>

            <br />

            <article class="stats_overview">
                <div class="overview_today">
                    <p class="overview_day"><?php echo $_LANG['total_open_cons']; ?></p>
                    <p id="live_connections" class="overview_count"><img src="../templates/images/ajax-loader.gif" /></p>
                </div>
                <div class="overview_today">
                    <p class="overview_day"><?php echo $_LANG['total_online_users']; ?></p>
                    <p id="total_online_users" class="overview_count"><img src="../templates/images/ajax-loader.gif" /></p>
                </div>
                <div class="overview_today">
                    <p class="overview_day"><?php echo $_LANG['total_cons_made']; ?></p>
                    <p id="total_connections_made" class="overview_count"><img src="../templates/images/ajax-loader.gif" /></p>
                </div>
                <div class="overview_today">
                    <p class="overview_day"><?php echo $_LANG['total_active_streams']; ?></p>
                    <p id="total_active_streams" class="overview_count"><img src="../templates/images/ajax-loader.gif" /></p>
                </div>
                <div class="overview_today">
                    <p class="overview_day"><?php echo $_LANG['total_bandwidth']; ?></p>
                    <p id="total_bandwidth" class="overview_count"><img src="../templates/images/ajax-loader.gif" /></p>
                </div>
                <div class="overview_today">
                    <p class="overview_day"><?php echo $_LANG['system_uptime']; ?></p>
                    <p id="uptime" class="overview_count"><font color="green" size="1px"><img src="../templates/images/ajax-loader.gif" /></font></p>
                </div>

            </article>
        </center>
        <div class="clear"></div>
    </div>
</article><!-- end of stats article -->

<article class="module width_full">
    <header><h3><?php echo $_LANG['live_bandwidth_usage']; ?></h3></header>
    <center><div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div></center>
</article><!-- end of stats article -->


<script src="../templates/js/highcharts.js"></script>
<script src="../templates/js/raphael.2.1.0.min.js"></script>
<script src="../templates/js/justgage.js"></script>
<script type="text/javascript">
    $(function () {
        $(document).ready(function() {
            Highcharts.setOptions({
                global: {
                    useUTC: false
                }
            });

            var chart;
            $('#container').highcharts({
                chart: {
                    type: 'spline',
                    animation: Highcharts.svg, // don't animate in old IE
                    marginRight: 10,
                    events: {
                        load: function() {


                            // set up the updating of the chart each second
                            var series = this.series[0];

                            function MakeRequest()
                            {
                                $.ajax({
                                    type: "GET",
                                    url: 'index.php?action=bandwidth',
                                    success: function (result) {

                                        result = $.parseJSON(result);

                                        var x = (new Date()).getTime(), // current time
                                            y = result.bytes;
                                        series.addPoint([x, y], true, true);

                                        MakeRequest();

                                    }
                                });

                            }
                            MakeRequest();


                        }
                    }
                },
                title: {
                    text: '<?php echo $_LANG['live_bandwidth_usage']; ?>'
                },
                xAxis: {
                    type: 'datetime',
                    tickPixelInterval: 150
                },
                yAxis: {
                    title: {
                        text: 'Mbps'
                    },
                    plotLines: [{
                        value: 0,
                        width: 1,
                        color: '#808080'
                    }]
                },
                tooltip: {
                    formatter: function() {
                        return '<b>'+ this.series.name +'</b><br/>'+
                            Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', this.x) +'<br/>'+
                            Highcharts.numberFormat(this.y, 2);
                    }
                },
                legend: {
                    enabled: false
                },
                exporting: {
                    enabled: false
                },
                series: [{
                    name: 'BandWidth (Mbps)',
                    data: (function() {
                        // generate an array of random data
                        var data = [],
                            time = (new Date()).getTime(),
                            i;

                        for (i = -9; i <= 0; i++) {
                            data.push({
                                x: time + i * 1000,
                                y: Math.random()
                            });
                        }
                        return data;
                    })()
                }]
            });
        });

    });
</script>

<script type='text/javascript'>


    var g1, g2, g3;

    window.onload = function(){

        var g1 = new JustGage({
            id: "g1",
            value: 0,
            min: 0,
            max: 100,
            title: "CPU",
            label: "load",
            levelColorsGradient: false
        });

        var g2 = new JustGage({
            id: "g2",
            value: 0,
            min: 0,
            max: 100,
            title: "RAM",
            label: "load",
            levelColorsGradient: false
        });

        var g3 = new JustGage({
            id: "g3",
            value: 0,
            min: 0,
            max: 100,
            title: "Users",
            label: "connections",
            levelColorsGradient: false
        });


        setInterval(function() {

            $.ajax({
                type: "GET",
                url: 'index.php?action=information',
                success: function (result) {
                    result = $.parseJSON(result);
                    g1.refresh(parseInt(result.cpu));
                    g2.refresh(parseInt(result.mem));
                    g3.refresh(parseInt(result.connections));
                    document.getElementById("total_bandwidth").innerHTML = result.total_bandwidth;
                    document.getElementById("total_connections_made").innerHTML = parseInt(result.total_connections_made);
                    document.getElementById("uptime").innerHTML = result.uptime;
                    document.getElementById("total_active_streams").innerHTML = parseInt(result.total_active_streams);
                    document.getElementById("live_connections").innerHTML = parseInt(result.live_connections);
                    document.getElementById("total_online_users").innerHTML = parseInt(result.total_online_users);
                }
            });
        }, 1000);
    };
</script>