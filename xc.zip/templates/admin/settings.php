<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['general_settings']; ?></h3>
        </header>
        <form action="settings.php?action=save" method="post">
            <div class="module_content">
                <fieldset>
                    <legend><b><?php echo $_LANG['general_settings']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['server_url']; ?></td>
                            <td><input type="text"  name="site_url" value="<?php echo ipTV_lib::$settings['site_url']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['server_name']; ?></td>
                            <td><input type="text"  name="server_name" value="<?php echo ipTV_lib::$settings['server_name']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['network_interface']; ?></td>
                            <td>
                                <select name="network_interface">
                                    <?php
                                    echo "<option value='".ipTV_lib::$settings['network_interface']."' selected>".ipTV_lib::$settings['network_interface']."</option>";


                                    foreach($network_interfaces as $network_interface)
                                    {
                                        if(ipTV_lib::$settings['network_interface'] == $network_interface)
                                        {
                                            continue;
                                        }
                                        echo "<option value='$network_interface'>$network_interface</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['logo_url']; ?></td>
                            <td><input type="text"  name="logo_url" value="<?php echo ipTV_lib::$settings['logo_url']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['live_pass']; ?></td>
                            <td><input type="text"  name="live_streaming_pass" value="<?php echo ipTV_lib::$settings['live_streaming_pass']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['bouquet_name']; ?></td>
                            <td><input type="text"  name="bouquet_name" value="<?php echo ipTV_lib::$settings['bouquet_name']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['movies_path']; ?></td>
                            <td><input type="text"  name="movies_path" value="<?php echo ipTV_lib::$settings['movies_path']; ?>" /> </td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['copyrights_remove']; ?></td>
                            <td><input type="radio" name="copyrights_removed" value="1" <?php if (ipTV_lib::$settings['copyrights_removed'] == 1) echo 'checked'; ?>/> Yes <input type="radio" name="copyrights_removed" value="0" <?php if (ipTV_lib::$settings['copyrights_removed'] != 1) echo 'checked'; ?>/> No</td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['copyrights_text']; ?></td>
                            <td><input type="text"  name="copyrights_text" value="<?php echo ipTV_lib::$settings['copyrights_text']; ?>" /> </td>
                        </tr>
                    </table>
                </fieldset>
                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['registration_settings']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['allow_registrations']; ?></td>
                            <td><input type="radio" name="allow_registrations" value="1" <?php if (ipTV_lib::$settings['allow_registrations'] == 1) echo 'checked'; ?>/> Yes <input type="radio" name="allow_registrations" value="0" <?php if (ipTV_lib::$settings['allow_registrations'] != 1) echo 'checked'; ?>/> No</td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['confirmation_email']; ?></td>
                            <td><input type="radio" name="confirmation_email" value="1" <?php if (ipTV_lib::$settings['confirmation_email'] == 1) echo 'checked'; ?>/> Yes <input type="radio" name="confirmation_email" value="0" <?php if (ipTV_lib::$settings['confirmation_email'] != 1) echo 'checked'; ?>/> No</td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['allow_multiple_accs']; ?></td>
                            <td><input type="radio" name="allow_multiple_accs" value="1" <?php if (ipTV_lib::$settings['allow_multiple_accs'] == 1) echo 'checked'; ?>/> Yes <input type="radio" name="allow_multiple_accs" value="0" <?php if (ipTV_lib::$settings['allow_multiple_accs'] != 1) echo 'checked'; ?>/> No</td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['username_strlen_setting']; ?></td>
                            <td><input type="text"  name="username_strlen" value="<?php echo ipTV_lib::$settings['username_strlen']; ?>" /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['username_alpha_setting']; ?></td>
                            <td><input type="radio" name="username_alpha" value="1" <?php if (ipTV_lib::$settings['username_alpha'] == 1) echo 'checked'; ?>/> Yes <input type="radio" name="username_alpha" value="0" <?php if (ipTV_lib::$settings['username_alpha'] != 1) echo 'checked'; ?>/> No</td>
                        </tr>
                    </table>
                </fieldset>


            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['save_settings']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $('.editor').jqte();
</script>