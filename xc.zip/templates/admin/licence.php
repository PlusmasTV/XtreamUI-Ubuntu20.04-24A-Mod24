<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_licence']; ?></h3>
        </header>
        <form action="licence.php?action=save" method="post">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['licence_key']; ?></b></legend>
                    <input type="text"  name="licence_key" value="<?php echo ipTV_lib::$licence['licence_key']; ?>" />
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['save_settings']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>