<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['new_stream']; ?></h3>
        </header>
        <form method="post" action="add_stream.php?action=add_stream" enctype="multipart/form-data">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['stream_options']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['import_stream']; ?></td>
                            <td>
                                <select name="type" id="type">
                                    <option value="1" selected><?php echo $_LANG['import_one_stream']; ?></option>
                                    <option value="2"><?php echo $_LANG['import_multiple_streams']; ?></option>
                                </select>
                            </td>
                        <tr>

                        <tr id="multiple" class="multiple" style="display:none">
                            <td><?php echo $_LANG['import_streams_file']; ?></td>
                            <td><input type="file" name="stream_list" id="stream_list" /></td>
                        </tr>

                        <tr id="stream_name" class="stream_name">
                            <td><?php echo $_LANG['stream_name']; ?></td>
                            <td><input type="text"  name="stream_display_name"  /></td>

                        <tr id="stream_source_form" class="stream_source_form">
                            <td><?php echo $_LANG['stream_source']; ?></td>
                            <td><input type="text" id="stream_source" name="stream_source"  /><br /><div id="codecs_checking"></div></td>
                        </tr>
                        <tr id="enable_rtmpdump"  style="display:none">
                            <td><?php echo $_LANG['restream_rtmpdump']; ?></td>
                            <td><input type="checkbox" name="enable_rtmpdump" value="1" /> <?php echo $_LANG['yes']; ?></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['category_name']; ?></td>
                            <td>
                                <select name="category_id">
                                    <option value=""><?php echo $_LANG['dont_use_category']; ?></option>
                                    <?php
                                    foreach($categories as $category)
                                    {
                                        echo "<option value='{$category['id']}'>{$category['category_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>

                        </tr>

                        <tr id="auto_set" class="auto_set">
                            <td><?php echo $_LANG['auto_set']; ?></td>
                            <td><input type="checkbox" id="auto_set" name="auto_set" value="1" checked/> <?php echo $_LANG['auto_set']; ?></td>
                        </tr>

                        <tr id="ports" class="ports" style="display:none">
                            <td><?php echo $_LANG['dest_stream_port']; ?></td>
                            <td><input type="text"  name="dest_stream_port"  /></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['stream_output']; ?></td>
                            <td>
                                <select name="mux_id" required>
                                    <?php
                                    foreach($muxes as $mux)
                                    {
                                        echo "<option value='{$mux['id']}'>{$mux['mux_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['notes']; ?></td>
                            <td><input type="text"  name="notes"  /></td>
                        </tr>
                    </table>
                </fieldset>
                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['restream_ffmpeg']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['restream_ffmpeg_desc']; ?></td>
                            <td><input type="checkbox" id="enable_ffmpeg" name="enable_ffmpeg" value="1" /> <?php echo $_LANG['use_ffmpeg']; ?></td>
                        </tr>
                    </table>

                    <div id="ffmpeg_mode" style="display:none">
                        <legend><b><?php echo $_LANG['ffmpeg_options']; ?></b></legend>


                        <table id="settings">
                            <tr>
                                <td><?php echo $_LANG['ffmpeg_version']; ?></td>
                                <td>
                                    <select name="ffmpeg_bin">
                                        <?php
                                        foreach($ffmpegs as $ffmpeg)
                                        {
                                            echo "<option value='{$ffmpeg['bin']}'>{$ffmpeg['version']}</option>";
                                                    }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <td><?php echo $_LANG['use_h264_filter']; ?></td>
                            <td>
                                <input type="radio" name="h264_filter" value="1" /> <?php echo $_LANG['yes']; ?> <input type="radio" name="h264_filter" value="0" checked/> <?php echo $_LANG['no']; ?><br />
                            </td>
                            <tr>
                        </table>
                    </div>


                </fieldset>
                <br />
                <fieldset id="vlc_options">
                    <legend><b><?php echo $_LANG['vlc_arguments']; ?></b></legend>
                    <table id="settings" width="100%">

                        <?php

                        foreach($arguments as $argument)
                        {
                            echo "<tr>";
                            echo "<td><input type='text'  value='{$argument['argument_name']}' disabled/></td>";  
                                        echo "<td><textarea rows='3' cols='50'  disabled>{$argument['argument_description']}</textarea></td>";  
                                        echo "<td><input type='text' value='{$argument['argument_default_value']}' name='arguments[{$argument['id']}]' /></td>"; 
                                    echo "</tr>";
                                }

                        ?>

                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" id="add_stream" value="<?php echo $_LANG['new_stream']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $(document).ready(function() {

        $('#auto_set').change(function () {
            $('#ports').fadeToggle();
        });
        $('#enable_ffmpeg').change(function () {
            $('#ffmpeg_mode').fadeToggle();
        });


        $("#type").change(function () {
            var value = $(this).val();
            if(value == "0")
            {
                $('#multiple').fadeOut();
                $('#auto_set').fadeIn();
                $('#stream_source_form').fadeIn();
                $('#stream_name').fadeIn();
            }
            else
            {
                $('#multiple').fadeIn();
                $('#auto_set').fadeOut();
                $('#stream_source_form').fadeOut();
                $('#stream_name').fadeOut();
            }
        });


        $('#stream_source').change(function () {


            if(this.value.substr(0,7) == 'rtmp://' && this.value.substr(7,4) != '$OPT')
            {
                $('#enable_rtmpdump').fadeIn();
            }
            else
                $('#enable_rtmpdump').fadeOut();

            $('#codecs_checking').html("<img src='../templates/images/ajax-loader.gif' />");
            if(!this.value || 0 === this.value.length)
            {
                $('#codecs_checking').html("");
            }

            var valueSelected = btoa(this.value);
            $.ajax({
                type: "GET",
                url: 'add_stream.php?action=checkCodecs&url=' + valueSelected,
                success: function (result) {
                    result = $.parseJSON(result);

                    if(typeof(result.audio) == 'undefined')
                    {
                        result.audio = "<img src='../templates/images/mini_nok.png' /> <b><?php echo $_LANG['audio_codec']; ?></b>";
                    }
                    else
                        result.audio = "<img src='../templates/images/mini_ok.png' /> <b><?php echo $_LANG['audio_codec']; ?></b>: " + result.audio ;

                    if(typeof(result.video) == 'undefined')
                    {
                        result.video = "<img src='../templates/images/mini_nok.png' /> <b><?php echo $_LANG['video_codec']; ?></b>";
                    }
                    else
                        result.video = "<img src='../templates/images/mini_ok.png' /> <b><?php echo $_LANG['video_codec']; ?></b>: " + result.video ;

                    $('#codecs_checking').html(result.audio + "<br />"+ result.video);

                }
            });
        });
    });
</script> 