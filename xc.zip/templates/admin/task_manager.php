<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['task']; ?></h3>
        </header>
        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['status']; ?></th>
                <th><?php echo $_LANG['run_per_mins']; ?></th>
                <th><?php echo $_LANG['description']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach($cronjobs as $cronjob)
            {
                $status = ($cronjob['enabled'] == 1) ? "<img src='../templates/images/ok.png' />" : "<img src='../templates/images/wrong.png' />";
                ?>
                <form method="post" action="task_manager.php?action=save&id=<?php echo $cronjob['id']; ?>">
                    <tr>
                        <td><?php echo $status; ?></td>
                        <td><?php echo $cronjob['run_per_mins']; ?></td>
                        <td><?php echo $cronjob['description']; ?></td>
                        <td>
                            <a href="task_manager.php?action=enable&id=<?php echo $cronjob['id']; ?>" class="table-icon enable" title="<?php echo $_LANG['enable_cronjob']; ?>"></a>
                            <a href="task_manager.php?action=disable&id=<?php echo $cronjob['id']; ?>" class="table-icon disable" title="<?php echo $_LANG['disable_cronjob']; ?>"></a>
                        </td>
                    </tr>
                </form>
            <?php } ?>
            </tbody>
        </table>
    </article>
<?php } ?>