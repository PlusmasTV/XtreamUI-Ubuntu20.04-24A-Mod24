<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($info_message))
        echo show_message('info',$info_message);

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>

    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_movies']; ?></h3>
        </header>

        <div id="dialogDiv" style="display: none;"><?php echo $_LANG['loading']; ?></div>
        <table class="tablesorter" cellspacing="0" >
            <thead>
            <tr>
                <th><?php echo $_LANG['status']; ?></th>
                <th><?php echo $_LANG['movie_name']; ?></th>
                <th><?php echo $_LANG['category_name']; ?></th>
                <th><?php echo $_LANG['movie_length']; ?></th>
                <th><?php echo $_LANG['online_clients']; ?></th>
                <th><?php echo $_LANG['audio_codec']; ?></th>
                <th><?php echo $_LANG['video_codec']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach($movies as $movie)
            {
                $is_ready = true;

                if(is_null($movie['category_name']))
                {
                    $movie['category_name'] = '-';
                }

                $movie_length_secs = "<img src='../templates/images/mini_nok.png' />";
                $audio = "<img src='../templates/images/mini_nok.png' />";
                $video = "<img src='../templates/images/mini_nok.png' />";
                echo "<tr>";

                if( is_null($movie['pid']) || !ps_running($movie['pid'] ) )
                {
                    $movie_name_fixed = ipTV_Stream::GetFixedStreamName($movie['stream_display_name'] );
                    if(file_exists(MOVIES_PATH . $movie_name_fixed . '/completed.xtream'))
                    {
                        switch($movie['movie_status'])
                        {
                            case 0:
                                $audio = "<img src='../templates/images/mini_loading.gif' />";
                                $video = "<img src='../templates/images/mini_loading.gif' />";
                                $movie_length_secs = "<img src='../templates/images/mini_loading.gif' />";
                                $color = "EBCCFF";
                                $status = "{$_LANG['verify']}<br /><img width='150' src='../templates/images/ajax_loader.gif' />";
                                        break;


                            case 1:
                                $stream_info = json_decode($movie['stream_info'],true);

                                $audio = (!isset($stream_info['audio']) || is_null($stream_info['audio'])) ? $audio : "<img src='../templates/images/mini_ok.png' /><br />" . $stream_info['audio'];
                                $video = (!isset($stream_info['video']) || is_null($stream_info['video'])) ? $video : "<img src='../templates/images/mini_ok.png' /><br />" .  $stream_info['video'];
                                $movie_length_secs = gmdate("H:i:s",$movie['movie_length_secs']);
                                $color = "D1FFC2";
                                $status = "<img src='../templates/images/ok.png' />";
                                $is_ready = true;
                                break;


                            case 2:
                                $color = "C2FFFF";
                                $status = "<img src='../templates/images/error.png' /><br />{$_LANG['bad_movie']}";
                                break;

                        }

                    }
                    else
                    {
                        $color = "FFCCCC";
                        $status = "<img src='../templates/images/error.png' /><br />{$_LANG['interrupted']}";
                    }
                }
                else
                {
                    $audio = "<img src='../templates/images/mini_loading.gif' />";
                    $video = "<img src='../templates/images/mini_loading.gif' />";
                    $movie_length_secs = "<img src='../templates/images/mini_loading.gif' />";
                    $color = "EBCCFF";
                    $status = "{$_LANG['in_progress']}<br /><img width='150' src='../templates/images/ajax_loader.gif' />";         
                                
                            }


                echo "<td bgcolor='#$color'><b>$status</b>"; 
                            echo  "<td bgcolor='#$color'>{$movie['stream_display_name']}</td>";
                            echo  "<td bgcolor='#$color'>{$movie['category_name']}</td>";
                            echo  "<td bgcolor='#$color'>".$movie_length_secs."</td>";
                            echo  "<td bgcolor='#$color'>{$movie['total_online_clients']}</td>";
                            
                            echo  "<td bgcolor='#$color'>$audio</td>";
                            echo  "<td bgcolor='#$color'>$video</td>";

                            ?> 
<td bgcolor="#<?php echo $color; ?>">
    <?php if($is_ready)
    {
        echo "<a onclick='ajax_request_dialog('streams.php?action=open_stream&stream_id={$movie['id']}','{$_LANG['live_streaming_test']}','black')'   class='table-icon live' href='#' title='{$_LANG['live_stream']}'></a>";
                                    echo "<a href='edit_movie.php?movie_id={$movie['id']}' class='table-icon edit' title='{$_LANG['edit_movie']}'></a>";
                                }
    ?>
    <a onclick="return confirm('<?php echo $_LANG['delete_stream_conf']; ?>')" href="movies.php?action=delete&movie_id=<?php echo $movie['id']; ?>" class="table-icon delete" title="<?php echo $_LANG['delete_movie']; ?>"></a>
</td>
</tr>
                        <?php } ?>
            </tbody>
        </table>
    </article>
<?php } ?>