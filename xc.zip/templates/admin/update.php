<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>

    <?php

    if(is_array($update))
    {
        ?>
        <article class="module width_full">
            <header><h3 class="tabs_involved"><?php echo $_LANG['update_panel']; ?></h3>
            </header>
            <div class="module_content">
                <?php
                if(@$can_update)
                {
                    ?>
                    <center>
                        <form action="update.php?action=download" method="post">
                            <table>
                                <tbody>
                                <tr>
                                    <td><div class="submit_link"><input type="submit" value="<?php echo $_LANG['download_update']; ?>" class="alt_btn"></td>
                                </tr>
                                </tbody>
                            </table>
                        </form>
                    </center>
                    <br /><br />
                <?php
                }
                else
                {
                    echo "<p align='center'><font color='red'>{$_LANG['files_writeable']} ".substr(IPTV_ROOT_PATH,0,-1)."</font></p>";
                }
                ?>
                <p>
                    <?php

                    foreach($update['change_log'] as $version=>$data)
                    {

                        $changelog = $data[0];
                        $description = trim($data[1]);
                        echo "<font color='red'>** {$_LANG['change_log']} $version</font>";
                        echo "<br /><br />";
                        if(is_array($changelog))
                        {
                            echo "- " .implode("<br />- ",$changelog);
                        }
                        else
                        {
                            echo "- " . $changelog;
                        }
                        if(!empty($description))
                            echo "<br /><br /><font color='orange'><b>$description</b></font>";
    echo "<br /><br />";
    }
                    ?>
                </p></article>
    <?php } ?>
    </div>

<?php } ?>