<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_database']; ?></h3>
        </header>
        <div class="module_content">
            <form method="post" action="database.php?action=manage">
                <fieldset>
                    <legend><b><?php echo $_LANG['manage_database']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['select_tables']; ?></td>
                            <td><select name="tables[]" size="10" multiple="">
                                    <?php
                                    foreach($all_tables as $table)
                                    {
                                        echo "<option value='$table'>$table</option>";
                                            }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['with_selected']; ?></td>
                            <td><div class="submit_link"><input type="submit" value="<?php echo $_LANG['optimize_tables']; ?>" name="manage_click" class="alt_btn"></div><div class="submit_link"><input type="submit" value="<?php echo $_LANG['backup_tables']; ?>" name="manage_click" class="alt_btn"></div></td>
                        </tr>
                    </table>
                </fieldset>

            </form>
        </div>
    </article>

    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['restore_database']; ?></h3></header>
        <form enctype="multipart/form-data" action="database.php?action=restore" method="post">
            <div class="module_content">

                <fieldset>
                    <label><?php echo $_LANG['restore_database']; ?></label>
                    <input type="file" name="db" />
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['restore_database']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>

    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['run_queries_title']; ?></h3></header>
        <form action="database.php?action=run" method="post">
            <div class="module_content">
                <fieldset>
                    <legend><b><?php echo $_LANG['paste_queries']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><textarea name="queries" rows="10" cols="100"></textarea></td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['run_queries']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>