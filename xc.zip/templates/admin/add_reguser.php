<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['new_reguser']; ?></h3>
        </header>
        <form method="post" name="form" action="add_reguser.php?action=add_user">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['user_details']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['username']; ?></td>
                            <td><input type="text" name="username"  required/></td>
                        <tr>
                            <td><?php echo $_LANG['password']; ?></td>
                            <td><input type="text" name="password"  required/></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['email']; ?></td>
                            <td><input type="text" name="email"  required/></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['member_group']; ?></td>
                            <td>
                                <select name="member_group_id" required>
                                    <option value="" selected>-</option>
                                    <?php
                                    foreach($member_groups as $member_group)
                                    {
                                        echo "<option value='{$member_group['id']}'>{$member_group['group_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                </fieldset>

            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['new_reguser']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?> 