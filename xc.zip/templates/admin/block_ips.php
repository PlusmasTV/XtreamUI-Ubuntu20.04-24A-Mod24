<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['block_ip']; ?></h3></header>
        <form method="post" action="block_ips.php?action=block">
            <div class="module_content">


                <fieldset>
                    <legend><b><?php echo $_LANG['block_ip']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['add_block_ip']; ?> (<font color="red"><?php echo $_LANG['block_ip_explain']; ?></font>)</td>
                            <td><input type="text"  name="ip"  /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['notes']; ?> </td>
                            <td><input type="text"  name="notes"  /></td>
                        <tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['do_it']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>

    <?php
    if(!empty($blocked_ips))
    {
        ?>
        <article class="module width_full">
            <header><h3 class="tabs_involved"><?php echo $_LANG['blocked_ips']; ?></h3></header>
            <table class="tablesorter" cellspacing="0" >
                <thead>
                <tr>
                    <th><?php echo $_LANG['ip']; ?></th>
                    <th><?php echo $_LANG['date_blocked']; ?></th>
                    <th style="width:250px"><?php echo $_LANG['notes']; ?></th>
                    <th><?php echo $_LANG['options']; ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach($blocked_ips as $block_ip)
                {
                    echo "<tr>";


                    echo "<td><b>{$block_ip['ip']}</b></td>";
                    echo "<td><b>".date("j F, Y, g:i a",$block_ip['date'])."</b></td>";
                    if(!empty($block_ip['notes']))
                        echo "<td><textarea rows='3'  style='width:250px;' disabled>{$block_ip['notes']}</textarea></td>";  
                            else
                                echo "<td>-</td>";
                            ?>
<td>
    <a onclick="return confirm('<?php echo $_LANG['unblock_ip']; ?>')" href="block_ips.php?action=unblock&id=<?php echo $block_ip['id']; ?>" class="table-icon enable" title="UnBlock IP"></a>
</td>
</tr>
                        <?php } ?>
                </tbody>
            </table>
        </article>
    <?php } ?>
<?php } ?>