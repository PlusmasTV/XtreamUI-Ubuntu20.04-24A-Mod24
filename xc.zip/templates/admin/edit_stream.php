<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['edit_stream']; ?></h3>
        </header>
        <form method="post" action="edit_stream.php?action=edit_stream&stream_id=<?php echo $info['id']; ?>">
            <div class="module_content">


                <fieldset>
                    <legend><b><?php echo $_LANG['stream_options']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['stream_name']; ?></td>
                            <td><input type="text"  name="stream_display_name"  value="<?php echo $info['stream_display_name']; ?>"  /></td>
                        <tr>
                            <td><?php echo $_LANG['stream_source']; ?></td>
                            <td><input type="text" id="stream_source" name="stream_source" value="<?php echo $info['stream_source']; ?>"  /><br /><div id="codecs_checking"></div></td>
                        </tr>
                        <tr id="enable_rtmpdump_form"  style="display:none">
                            <td><?php echo $_LANG['restream_rtmpdump']; ?></td>
                            <td><input type="checkbox" name="enable_rtmpdump" id="enable_rtmpdump" value="1" <?php if($info['enable_rtmpdump'] == 1) echo 'checked'; ?>/> <?php echo $_LANG['yes']; ?></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['category_name']; ?></td>
                            <td>
                                <select name="category_id">
                                    <?php
                                    if($info['category_id'] == null)
                                    {
                                        echo "<option value='' selected>{$_LANG['dont_use_category']}</option>";
                                    }
                                    else
                                    {
                                        echo "<option value=''>{$_LANG['dont_use_category']}</option>";
                                    }

                                    foreach($categories as $category)
                                    {
                                        if($info['category_id'] == $category['id'])
                                            echo "<option value='{$category['id']}' selected>{$category['category_name']}</option>";
                                        else
                                            echo "<option value='{$category['id']}'>{$category['category_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>

                        </tr>


                        <tr>
                            <td><?php echo $_LANG['dest_stream_port']; ?></td>
                            <td><input type="text"  name="dest_stream_port" value="<?php echo $info['dest_stream_port']; ?>" /></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['stream_output']; ?></td>
                            <td>
                                <select name="mux_id" required>
                                    <?php
                                    foreach($muxes as $mux)
                                    {
                                        if($mux['id'] == $info['mux_id'])
                                            echo "<option value='{$mux['id']}' selected>{$mux['mux_name']}</option>";
                                        else
                                            echo "<option value='{$mux['id']}'>{$mux['mux_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['notes']; ?></td>
                            <td><input type="text"  name="notes" value="<?php echo $info['notes']; ?>" /></td>
                        </tr>
                    </table>
                </fieldset>
                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['restream_ffmpeg']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['restream_ffmpeg_desc']; ?></td>
                            <td><input type="checkbox" id="enable_ffmpeg" name="enable_ffmpeg" value="1" <?php if($info['enable_ffmpeg'] == 1) echo 'checked'; ?>/> <?php echo $_LANG['use_ffmpeg']; ?></td>
                        </tr>
                    </table>

                    <div id="ffmpeg_mode" style="display:none">
                        <legend><b><?php echo $_LANG['ffmpeg_options']; ?></b></legend>


                        <table id="settings">
                            <tr>
                                <td><?php echo $_LANG['ffmpeg_version']; ?></td>
                                <td>
                                    <select name="ffmpeg_bin">
                                        <?php
                                        foreach($ffmpegs as $ffmpeg)
                                        {
                                            if($ffmpeg['bin'] == $info['ffmpeg_bin'])
                                                echo "<option value='{$ffmpeg['bin']}' selected>{$ffmpeg['version']}</option>";
                                                        else
                                                            echo "<option value='{$ffmpeg['bin']}'>{$ffmpeg['version']}</option>";
                                                    }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <td><?php echo $_LANG['use_h264_filter']; ?></td>
                            <td>
                                <input type="radio" name="h264_filter" value="1" <?php if($info['h264_filter'] == 1) echo 'checked'; ?> /> <?php echo $_LANG['yes']; ?> <input type="radio" name="h264_filter" value="0" <?php if($info['h264_filter'] == 0) echo 'checked'; ?>/> <?php echo $_LANG['no']; ?><br />
                            </td>
                            <tr>
                        </table>
                    </div>


                </fieldset>
                <br />
                <fieldset id="vlc_options">
                    <legend><b><?php echo $_LANG['vlc_arguments']; ?></b></legend>
                    <table id="settings" width="100%">
                        <?php

                        foreach($arguments as $argument)
                        {
                            echo "<tr>";
                            echo "<td><input type='text'  value='{$argument['argument_name']}' disabled/></td>";  
                                        echo "<td><textarea rows='3' cols='50'  disabled>{$argument['argument_description']}</textarea></td>"; 
                                        if(array_key_exists($argument['id'],$stream_arguments))
                                            echo "<td><input type='text' name='arguments[{$argument['id']}]' value='{$stream_arguments[$argument['id']]}' /></td>";
                                        else
                                            echo "<td><input type='text' name='arguments[{$argument['id']}]'  /></td>";
                                    
                                    echo "</tr>";
                                }

                        ?>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['edit_stream']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $(document).ready(function() {

        var StreamSource = $('#stream_source').val();

        GetCodecs(StreamSource);

        $('#enable_ffmpeg').change(function () {
            $('#ffmpeg_mode').fadeToggle();
        });


        if(StreamSource.substr(0,7) == 'rtmp://' && StreamSource.substr(7,4) != '$OPT')
        {
            $('#enable_rtmpdump_form').fadeIn();
        }
        else
        {
            $('#enable_rtmpdump').attr('checked', false);
            $('#enable_rtmpdump_form').fadeOut();
        }


        if($("#enable_ffmpeg").prop('checked'))
        {
            $('#ffmpeg_mode').fadeIn();
        }



        $('#stream_source').change(function () {

            var StreamSource = $('#stream_source').val();
            if(StreamSource.substr(0,7) != 'rtmp://')
            {
                $('#enable_rtmpdump').attr('checked', false);
                $('#enable_rtmpdump_form').fadeOut();
            }
            else
            {
                if(StreamSource.substr(7,4) != '$OPT')
                    $('#enable_rtmpdump_form').fadeIn();
            }

            GetCodecs(StreamSource);
        });

        function GetCodecs(streamURL)
        {
            $('#codecs_checking').html("<img src='../templates/images/ajax-loader.gif' />");
            if(!streamURL || 0 === streamURL.length)
            {
                $('#codecs_checking').html("");
            }
            else
            {
                var valueSelected = btoa(streamURL);
                $.ajax({
                    type: "GET",
                    url: 'add_stream.php?action=checkCodecs&url=' + valueSelected,
                    success: function (result) {
                        result = $.parseJSON(result);

                        if(typeof(result.audio) == 'undefined')
                        {
                            result.audio = "<img src='../templates/images/mini_nok.png' /> <b><?php echo $_LANG['audio_codec']; ?></b>";
                        }
                        else
                            result.audio = "<img src='../templates/images/mini_ok.png' /> <b><?php echo $_LANG['audio_codec']; ?></b>: " + result.audio ;

                        if(typeof(result.video) == 'undefined')
                        {
                            result.video = "<img src='../templates/images/mini_nok.png' /> <b><?php echo $_LANG['video_codec']; ?></b>";
                        }
                        else
                            result.video = "<img src='../templates/images/mini_ok.png' /> <b><?php echo $_LANG['video_codec']; ?></b>: " + result.video ;

                        $('#codecs_checking').html(result.audio + "<br />"+ result.video);

                    }
                });
            }
        }


    });
</script> 