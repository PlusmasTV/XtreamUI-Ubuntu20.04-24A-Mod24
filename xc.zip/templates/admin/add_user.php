<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['new_acc']; ?></h3>
        </header>
        <form method="post" name="form" onsubmit="selectAll('allowed_ips',true);" action="add_user.php?action=add_user">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['user_details']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['username']; ?></td>
                            <td><input type="text" name="username"  required/></td>
                        <tr>
                            <td><?php echo $_LANG['password']; ?></td>
                            <td><input type="text" name="password"  required/></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['assign_to']; ?></td>
                            <td>
                                <select name="member_id" required>
                                    <option value="" selected></option>
                                    <?php
                                    foreach($registered_users as $reg_user)
                                    {
                                        echo "<option value='{$reg_user['id']}'>{$reg_user['username']}</option>";
                                            }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['allowed_ips']; ?> [<font color="red"><?php echo $_LANG['def_all_allowed']; ?></font>]</td>
                            <td>
                                <input type="text" name="allow_ip" id="allow_ip" value="Enter IP..." style="width:200px;" /> <input type="button" value="Add This IP to Allowed List" onclick="appendOptionLast();" />
                                <input type="button" value="Remove Selected" onclick="removeOptionSelected();" />
                                <input type="button" value="Allow All IPs (Default)" onclick="Reset();" />
                                <select size="5" name="allowed_ips[]" id="allowed_ips" multiple="">
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['allow_restream']; ?></td>
                            <td>
                                <select name="is_restreamer" required>
                                    <option value="0" selected><?php echo $_LANG['no']; ?></option>
                                    <option value="1"><?php echo $_LANG['yes']; ?></option>
                                </select>
                            </td>
                        </tr>


                        <tr>
                            <td><?php echo $_LANG['max_connections']; ?> [<font color="red"><?php echo $_LANG['same_time']; ?></font>]</td>
                            <td><input type="text" name="max_connections" value="1" required/></td>
                        </tr>


                        <tr>
                            <td><?php echo $_LANG['band_limit']; ?> [<font color="red"><?php echo $_LANG['zero_unlimited']; ?></font>]</td>
                            <td><input type="text" name="allowed_bandwidth"  value="0" required/></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['expire_date']; ?></td>
                            <td><input type="text" name="expire_date" id="expire_date" required/></td>
                        </tr>


                        <tr>
                            <td><?php echo $_LANG['select_bouquet']; ?></td>
                            <td>
                                <select name="bouquet_selection" required>
                                    <?php

                                    foreach($bouquets as $bouquet)
                                    {
                                        echo "<option value='{$bouquet['id']}'>{$bouquet['bouquet_name']}</option>";
                                                }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['notes']; ?></td>
                            <td><input type="text" name="notes"/></td>
                        </tr>
                    </table>
                </fieldset>

            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['new_acc']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    function removeOptionSelected()
    {
        var elSel = document.getElementById('allowed_ips');
        var i;
        for (i = elSel.length - 1; i>=0; i--) {
            if (elSel.options[i].selected) {
                elSel.remove(i);
            }
        }
    }


    function Reset()
    {
        var elSel = document.getElementById('allowed_ips');
        while(elSel.options.length > 0){
            elSel.remove(0);
        }
    }


    function appendOptionLast()
    {
        var elSel = document.getElementById('allowed_ips');
        var elOptNew = document.createElement('option');
        elOptNew.text = document.getElementById("allow_ip").value;
        elOptNew.value = document.getElementById("allow_ip").value;

        try {
            elSel.add(elOptNew, null); // standards compliant; doesn't work in IE
        }
        catch(ex) {
            elSel.add(elOptNew); // IE only
        }
    }
</script> 