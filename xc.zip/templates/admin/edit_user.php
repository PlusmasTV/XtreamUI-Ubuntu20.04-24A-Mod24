<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['edit_user']; ?></h3>
        </header>
        <form method="post" name="form" onsubmit="selectAll('allowed_ips',true);" action="edit_user.php?action=edit_user&user_id=<?php echo $info['id']; ?>">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['user_details']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['username']; ?></td>
                            <td><input type="text" name="username"  value="<?php echo $info['username']; ?>" required/></td>
                        <tr>
                            <td><?php echo $_LANG['password']; ?></td>
                            <td><input type="text" name="password"  value="<?php echo $info['password']; ?>" required/></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['assign_to']; ?> (<font color="red"><?php echo $_LANG['leave_blank']; ?></font>)</td>
                            <td>
                                <select name="member_id" required>
                                    <?php
                                    foreach($registered_users as $reg_user)
                                    {
                                        if($reg_user['id'] == $info['member_id'])
                                            echo "<option value='{$reg_user['id']}' selected>{$reg_user['username']}</option>";
                                                else
                                                    echo "<option value='{$reg_user['id']}'>{$reg_user['username']}</option>";
                                            }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['allowed_ips']; ?></td>
                            <td>
                                <input type="text" name="allow_ip" id="allow_ip" value="Enter IP..." style="width:200px;" /> <input type="button" value="Add This IP to Allowed List" onclick="appendOptionLast();" />
                                <input type="button" value="Remove Selected" onclick="removeOptionSelected();" />
                                <input type="button" value="Allow All IPs (Default)" onclick="Reset();" />
                                <select size="5" name="allowed_ips[]" id="allowed_ips" multiple="">
                                    <?php
                                    foreach(unserialize($info['allowed_ips']) as $allow_ip)
                                    {
                                        echo "<option value='$allow_ip'>$allow_ip</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['allow_restream']; ?></td>
                            <td>
                                <select name="is_restreamer" required>
                                    <?php
                                    if($info['is_restreamer'] == 0)
                                    {
                                        echo "<option value='0' selected>No</option>";
                                                echo "<option value='1'>Yes</option>";
                                            }
                                    else
                                    {
                                        echo "<option value='1' selected>Yes</option>";
                                                echo "<option value='0'>No</option>";                                       
                                            }
                                    ?>
                                </select>
                            </td>
                        </tr>


                        <tr>
                            <td><?php echo $_LANG['max_connections']; ?> [<font color="red"><?php echo $_LANG['same_time']; ?></font>]</td>
                            <td><input type="text" name="max_connections" value="<?php echo $info['max_connections']; ?>" required/></td>
                        </tr>


                        <tr>
                            <td><?php echo $_LANG['band_limit']; ?> [<font color="red"><?php echo $_LANG['zero_unlimited']; ?></font>]</td>
                            <td><input type="text" name="allowed_bandwidth"  value="<?php echo $info['allowed_bandwidth']; ?>"  required/></td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['expire_date']; ?></td>
                            <td><input type="text" name="expire_date" id="expire_date" value="<?php echo date("Y/m/d H:i",$info['exp_date']); ?>" required/></td>
                        </tr>


                        <tr>
                            <td><?php echo $_LANG['select_bouquet']; ?></td>
                            <td>
                                <select name="bouquet_selection" required>
                                    <?php

                                    foreach($bouquets as $bouquet)
                                    {
                                        if($bouquet['id'] == $info['bouquet'])
                                            echo "<option value='{$bouquet['id']}' selected>{$bouquet['bouquet_name']}</option>";
                                                    else
                                                        echo "<option value='{$bouquet['id']}'>{$bouquet['bouquet_name']}</option>";
                                                }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['notes']; ?></td>
                            <td><input type="text" name="notes" value="<?php echo $info['notes']; ?>" /></td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['edit_user']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    function removeOptionSelected()
    {
        var elSel = document.getElementById('allowed_ips');
        var i;
        for (i = elSel.length - 1; i>=0; i--) {
            if (elSel.options[i].selected) {
                elSel.remove(i);
            }
        }
    }


    function Reset()
    {
        var elSel = document.getElementById('allowed_ips');
        while(elSel.options.length > 0){
            elSel.remove(0);
        }
    }

    function selectAll(selectBox,selectAll) {
        // have we been passed an ID 
        if (typeof selectBox == "string") {
            selectBox = document.getElementById(selectBox);
        }
        // is the select box a multiple select box? 
        if (selectBox.type == "select-multiple") {
            for (var i = 0; i < selectBox.options.length; i++) {
                selectBox.options[i].selected = selectAll;
            }
        }
    }

    function appendOptionLast()
    {
        var elSel = document.getElementById('allowed_ips');
        var elOptNew = document.createElement('option');
        elOptNew.text = document.getElementById("allow_ip").value;
        elOptNew.value = document.getElementById("allow_ip").value;

        try {
            elSel.add(elOptNew, null); // standards compliant; doesn't work in IE
        }
        catch(ex) {
            elSel.add(elOptNew); // IE only
        }
    }
</script> 