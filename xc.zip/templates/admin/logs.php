<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>

    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['stream_logs']; ?></h3>
        </header>
        <center>
            <?php
            echo $pagination;
            ?>
        </center>
        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['stream_name']; ?></th>
                <th><?php echo $_LANG['date']; ?></th>
                <th><?php echo $_LANG['status']; ?></th>
            </tr>
            </thead>

            <tbody>
            <?php
            foreach($logs as $log)
            {


                echo "<tr>";
                echo  "<td>{$log['stream_display_name']}</td>";
                echo  "<td>".date("d/m/Y H:m:s", $log['date'])."</td>";
                echo  "<td>{$log['status']}</td>";
                echo "</tr>";
            }
            ?>
            </tbody>
        </table>
        <center>
            <?php
            echo $pagination;
            ?>
        </center>
    </article>
<?php } ?>