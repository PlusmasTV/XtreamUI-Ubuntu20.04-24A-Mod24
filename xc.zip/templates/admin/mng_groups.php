<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['create_new_group']; ?></h3></header>
        <form method="post" action="mng_groups.php?action=new">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['options']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['group_name']; ?></td>
                            <td><input type="text" name="group_name"required/></td>
                        <tr>
                            <td><?php echo $_LANG['group_color']; ?> (<font color="red"><?php echo $_LANG['html_code']; ?></font>)</td>
                            <td><input type="text" name="group_color"/></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['access_admin_cp']; ?></td>
                            <td>
                                <select name="is_admin" required>
                                    <option value="0" selected><?php echo $_LANG['no']; ?></option>
                                    <option value="1"><?php echo $_LANG['yes']; ?></option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><?php echo $_LANG['group_banned']; ?></td>
                            <td>
                                <select name="is_banned" required>
                                    <option value="0" selected><?php echo $_LANG['no']; ?></option>
                                    <option value="1"><?php echo $_LANG['yes']; ?></option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['create_new_group']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>

    <?php
    if(!empty($member_groups))
    {
        ?>
        <article class="module width_full">
            <header><h3 class="tabs_involved"><?php echo $_LANG['manage_groups']; ?></h3></header>
            <table class="tablesorter" cellspacing="0" >
                <thead>
                <tr>
                    <th><?php echo $_LANG['group_name']; ?></th>
                    <th><?php echo $_LANG['total_users']; ?></th>
                    <th><?php echo $_LANG['access_admin_cp']; ?></th>
                    <th><?php echo $_LANG['group_banned']; ?></th>
                    <th><?php echo $_LANG['options']; ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach($member_groups as $member_group)
                {
                    echo "<tr>";


                    echo "<td><b><font color='{$member_group['group_color']}'>{$member_group['group_name']}</font></b></td>";
                    echo "<td><b><font size='3'>{$member_group['total_users']}</font></b></td>";
                    if($member_group['is_admin'] == 1)
                    {
                        echo "<td><img src='../templates/images/ok.png' /></td>";
                    }
                    else
                    {
                        echo "<td><img src='../templates/images/wrong.png' /></td>";
                    }

                    if($member_group['is_banned'] == 1)
                    {
                        echo "<td><img src='../templates/images/ok.png' /></td>";
                    }
                    else
                    {
                        echo "<td><img src='../templates/images/wrong.png' /></td>";
                    }



                    ?>
                    <td>
                        <?php
                        if($member_group['can_delete'] == 1)
                        {
                            echo "<a onclick='return confirm('{$_LANG['delete_group']}')' href='mng_groups.php?action=delete&id={$member_group['id']}' class='table-icon delete' title='Delete Group'></a>";
                        }
                        else
                        {
                            echo "-";
                        }
                        ?>
                    </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </article>
    <?php } ?>
<?php } ?>