<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['edit_movie']; ?></h3>
        </header>
        <form method="post" action="edit_movie.php?action=edit_movie&movie_id=<?php echo $info['id']; ?>">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['movies_options']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['movie_name']; ?></td>
                            <td><input type="text" name="movie_name" value="<?php echo $info['stream_display_name']; ?>"  /></td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['category_name']; ?></td>
                            <td>
                                <select name="category_id">
                                    <?php
                                    if($info['category_id'] == null)
                                    {
                                        echo "<option value='' selected>{$_LANG['dont_use_category']}</option>";
                                    }
                                    else
                                    {
                                        echo "<option value=''>{$_LANG['dont_use_category']}</option>";
                                    }

                                    foreach($categories as $category)
                                    {
                                        if($info['category_id'] == $category['id'])
                                            echo "<option value='{$category['id']}' selected>{$category['category_name']}</option>";
                                        else
                                            echo "<option value='{$category['id']}'>{$category['category_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['edit_movie']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>