<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <center>
        <table>
            <tbody>
            <tr>
                <td><form method="post" action="connection_logs.php?show=show_all"><div class="submit_link"><input type="submit" value="<?php echo $_LANG['show_all_cons']; ?>" class="alt_btn"></div></form></td>
                <td><form method="post" action="connection_logs.php?show=open"><div class="submit_link"><input type="submit" value="<?php echo $_LANG['show_open_cons']; ?>" class="alt_btn"></div></form></td>
                <td><form method="post" action="connection_logs.php?show=closed"><div class="submit_link"><input type="submit" value="<?php echo $_LANG['show_closed_cons']; ?>" class="alt_btn"></div></form></td>
            </tr>
            </tbody>
        </table>
    </center>


    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['view_connections']; ?></h3></header>
        <center>
            <?php
            echo $pagination;
            ?>
        </center>

        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['connection']; ?></th>
                <th><?php echo $_LANG['username']; ?></th>
                <th><?php echo $_LANG['channel']; ?></th>
                <th><?php echo $_LANG['ip']; ?></th>
                <th><?php echo $_LANG['flag']; ?></th>
                <th><?php echo $_LANG['user_agent']; ?></th>
                <th><?php echo $_LANG['date_started']; ?></th>
                <th><?php echo $_LANG['date_end']; ?></th>
                <th><?php echo $_LANG['total_time_online']; ?></th>
                <th><?php echo $_LANG['bandwidth']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>
            <tbody>

            <?php

            foreach($activities as $activity)
            {
                $activity['user_agent'] = htmlentities($activity['user_agent']);
                echo "<tr>";
                if(is_null($activity['pid']))
                {
                    $color = "FFD6CC";
                    echo "<td bgcolor='#$color'><b>{$_LANG['closed']}</b></td>"; 
                            }
                elseif(ps_running($activity['pid']))
                {
                    $color = "E0FFD6";
                    echo "<td bgcolor='#$color'><b>{$_LANG['opened']}</b></td>"; 
                            }
                else
                {
                    $color = "EBD6EB";
                    echo "<td bgcolor='#$color'><b>{$_LANG['closed_unex']}</b></td>";  
                            }


                echo "<td bgcolor='#$color'>{$activity['member_name']}</td>";
                        echo "<td bgcolor='#$color'>{$activity['stream_display_name']}</td>";
                        echo "<td bgcolor='#$color'>{$activity['user_ip']}</td>";  
                                

                        $country = strtoupper(geoip_country_code_by_name($activity['user_ip']));
                                        $country_img = "<img src='../templates/images/flags_country/unknown.png' title='{$_LANG['unknown']}'>";
                                        if(@$country)
                                        {
                                            $country_img = "<img src='../templates/images/flags_country/".$country.".png' title='".$country."' />";
                                        }
                                        
                                        echo "<td bgcolor='#$color'>$country_img</td>";
                                        
                                
                        echo "<td bgcolor='#$color'>{$activity['user_agent']}</td>"; 
                        echo "<td bgcolor='#$color'>" . date("j F, Y, H:i:s", $activity['date_start']) . "</td>";
                        if(is_null($activity['date_end']))
                        {

                            echo "<td bgcolor='#$color'><font color='orange'>{$_LANG['still_watching']}</font></td>";
                            echo "<td bgcolor='#$color'><font color='blue'>".gmdate("H:i:s", time()-$activity['date_start'])." +</font></td>";
                            echo "<td bgcolor='#$color'><font color='blue'>{$_LANG['waiting']}</font></td>";
                            echo "<td bgcolor='#$color'><a href='connection_logs.php?action=kill_activity&activity_id={$activity['id']}&show=$selected_show' class='table-icon kill' title='{$_LANG['kill_connection']}'></a> <a onclick='return confirm('{$_LANG['kill_con']}')' href='connection_logs.php?action=del_activity&activity_id={$activity['id']}' class='table-icon delete' title='{$_LANG['delete_activity']}'></a></td>";
                        
                        }
                        else
                        {
                            echo "<td bgcolor='#$color'>" . date("j F, Y, H:i:s", $activity['date_end']) . "</td>";
                            echo "<td bgcolor='#$color'>".gmdate("H:i:s", $activity['date_end']-$activity['date_start'])."</td>";
                            echo "<td bgcolor='#$color'>".formatBytes($activity['bandwidth'],2)."</td>";
                            echo "<td bgcolor='#$color'><a onclick='return confirm('{$_LANG['kill_con']}')' href='connection_logs.php?action=del_activity&activity_id={$activity['id']}&show=$selected_show' class='table-icon delete' title='{$_LANG['delete_activity']}'></a></td>";
                        
                        }
                        
                        echo "</tr>";
                    }
            ?>
            </tbody>
        </table>
        <center>
            <?php
            echo $pagination;
            ?>
        </center>
    </article>
<?php } ?>