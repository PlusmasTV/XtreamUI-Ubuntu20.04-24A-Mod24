<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['new_movie']; ?></h3>
        </header>
        <!-- file picker -->
        <div id="dialog-explorer" title="File Browser"  style="display: none;">
            <div id="dialogContent"></div>
        </div>


        <form method="post" action="import_movies.php?action=import_movies">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['import_movies']; ?></b></legend>

                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['movies_location']; ?></td>
                            <td>
                                <select name="movie_location" id="movie_location">
                                    <option value="">-</option>
                                    <option value="local"><?php echo $_LANG['location_local']; ?></option>
                                    <option value="remote"><?php echo $_LANG['location_remote']; ?></option>
                                </select>
                            </td>
                        </tr>

                        <tr id="local" style="display:none">
                            <td><?php echo $_LANG['movie_source_folder']; ?></td>
                            <td><input id="input" type="text" name="movie_source_local" /></td>
                            <td><div class="submit_link"><input type="button" value="<?php echo $_LANG['pick_folder']; ?>" class="alt_btn" onclick="openDialog();"></div></td>
                        </tr>

                        <tr id="remote" style="display:none">
                            <td><?php echo $_LANG['movie_source_web']; ?></td>
                            <td><input type="text" name="movie_source_remote" value="" /></td>
                    </table>
                </fieldset>
                <?php
                if(!empty($added))
                {
                    ?>
                    <br />
                    <fieldset>
                        <legend><b><?php echo $_LANG['movies_imported']; ?></b></legend>
                        <textarea style="width:100%;" rows="18"><?php echo implode("\
",$added); ?></textarea>
                    </fieldset>
                <?php } ?>
                <?php
                if(!empty($movies_no_permissions))
                {
                    ?>
                    <br />
                    <fieldset>
                        <legend><b><?php echo $_LANG['movies_no_permission']; ?></b></legend>
                        <textarea style="width:100%;" rows="18"><?php echo implode("\
",$movies_no_permissions); ?></textarea>
                    </fieldset>
                <?php } ?>
                <?php
                if(!empty($failed))
                {
                    ?>
                    <br />
                    <fieldset>
                        <legend><b><?php echo $_LANG['movies_failed']; ?></b></legend>
                        <textarea style="width:100%;" rows="18"><?php echo implode("\
",$failed); ?></textarea>
                    </fieldset>
                <?php } ?>                           <br />
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['import_movies']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $('#movie_location').click(function(){

        $("#dialog-explorer").dialog({
            autoOpen: false,
            width: $(document).width()*0.3,
            height: $(document).height()*0.50,
            //zIndex: 1000000000,
            buttons: {
                "I'm Done": function () {
                    $(this).dialog("close");
                }
            }
        });

        $('#dialogContent').fileTree({root: '/', script: 'filexplorer.php', multiFolder: false, loadMessage: 'Loading files...'},
            function(file) {
                $("#input").val(file);
                $("#dialog-explorer").dialog("close");
            },
            function(dire){ $("#input").val(dire);  }
        );

        var value = $(this).val();

        if(value == "local")
        {
            $('#local').fadeIn();
            $('#remote').fadeOut();
        }
        else if(value == "remote")
        {
            $('#local').fadeOut();
            $('#remote').fadeIn();
        }
        else
        {
            $('#local').fadeOut();
            $('#remote').fadeOut();
        }
    });
</script>