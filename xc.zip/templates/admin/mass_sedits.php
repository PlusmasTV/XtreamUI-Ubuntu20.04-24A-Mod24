<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['mass_edit']; ?></h3>
        </header>
        <form method="post" action="mass_sedits.php?action=save">
            <div class="module_content">

                <fieldset>
                    <legend><b><?php echo $_LANG['options']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['select_live_streams']; ?></td>
                            <td>
                                <select name="streams[]" size="10" multiple="multiple" >
                                    <?php

                                    foreach($streams as $stream)
                                    {
                                        echo "<option value='{$stream['id']}'>{$stream['stream_display_name']}</option>";
                                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['category_name']; ?></td>
                            <td>
                                <select name="category_id">
                                    <option value="-1" selected><?php echo $_LANG['dont_change']; ?></option>
                                    <option value="0"><?php echo $_LANG['dont_use_category']; ?></option>
                                    <?php
                                    foreach($categories as $category)
                                    {
                                        echo "<option value='{$category['id']}'>{$category['category_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $_LANG['stream_output']; ?></td>
                            <td>
                                <select name="mux_id">
                                    <option value=""><?php echo $_LANG['output_default']; ?></option>
                                    <?php
                                    foreach($muxes as $mux)
                                    {
                                        if($mux['id'] == $info['mux_id'])
                                            echo "<option value='{$mux['id']}' selected>{$mux['mux_name']}</option>";
                                        else
                                            echo "<option value='{$mux['id']}'>{$mux['mux_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><?php echo $_LANG['restart_streams_after']; ?></td>
                            <td><input type="radio" name="restart_streams" value="1" checked/> <?php echo $_LANG['yes']; ?> <input type="radio" name="restart_streams" value="0" /> <?php echo $_LANG['no']; ?></td>
                        </tr>

                    </table>
                </fieldset>
                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['restream_rtmpdump']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['restream_rtmpdump_desc']; ?></td>
                            <td><input type="radio" name="enable_rtmpdump" id="value="-1" checked/> <?php echo $_LANG['dont_change']; ?> <input type="radio" name="enable_rtmpdump" value="1" /> <?php echo $_LANG['yes']; ?> <input type="radio" name="enable_rtmpdump" value="0" /> <?php echo $_LANG['no']; ?> </td>
                        </tr>
                    </table>

                </fieldset>
                <br />
                <br />
                <fieldset>
                    <legend><b><?php echo $_LANG['restream_ffmpeg']; ?></b></legend>
                    <table id="settings">
                        <tr>
                            <td><?php echo $_LANG['restream_ffmpeg_desc']; ?></td>
                            <td><input type="radio" name="enable_ffmpeg" id="value="-1" checked/> <?php echo $_LANG['dont_change']; ?> <input type="radio" name="enable_ffmpeg" value="1" /> <?php echo $_LANG['yes']; ?> <input type="radio" name="enable_ffmpeg" value="0" /> <?php echo $_LANG['no']; ?> </td>
                        </tr>
                    </table>

                    <div id="ffmpeg_mode" style="display:none">
                        <legend><b><?php echo $_LANG['ffmpeg_options']; ?></b></legend>


                        <table id="settings">
                            <tr>
                                <td><?php echo $_LANG['ffmpeg_version']; ?></td>
                                <td>
                                    <select name="ffmpeg_bin">
                                        <?php
                                        foreach($ffmpegs as $ffmpeg)
                                        {
                                            if($ffmpeg['bin'] == $info['ffmpeg_bin'])
                                                echo "<option value='{$ffmpeg['bin']}' selected>{$ffmpeg['version']}</option>";
                                                        else
                                                            echo "<option value='{$ffmpeg['bin']}'>{$ffmpeg['version']}</option>";
                                                    }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <td><?php echo $_LANG['use_h264_filter']; ?></td>
                            <td>
                                <input type="radio" name="h264_filter" value="1" <?php if($info['h264_filter'] == 1) echo 'checked'; ?> /> <?php echo $_LANG['yes']; ?> <input type="radio" name="h264_filter" value="0" <?php if($info['h264_filter'] == 0) echo 'checked'; ?>/> <?php echo $_LANG['no']; ?><br />
                            </td>
                            <tr>
                        </table>
                    </div>


                </fieldset>
                <br />
                <fieldset id="vlc_options">
                    <legend><b><?php echo $_LANG['vlc_arguments']; ?></b></legend>
                    <table id="settings" width="100%">

                        <?php

                        foreach($arguments as $argument)
                        {
                            echo "<tr>";
                            echo "<td><input type='text'  value='{$argument['argument_name']}' disabled/></td>";  
                                        echo "<td><textarea rows='3' cols='50'  disabled>{$argument['argument_description']}</textarea></td>";  
                                        echo "<td><input type='text' name='arguments[{$argument['id']}]' /></td>"; 
                                        echo "<td><input type='checkbox' name='arguments_remove[{$argument['id']}]' value='1' />{$_LANG['remove_from_arguments']}</td>"; 
                                    echo "</tr>";
                                }

                        ?>

                    </table>
                </fieldset>
            </div>
            <footer>
                <div class="submit_link">
                    <input type="submit" value="<?php echo $_LANG['mass_edit']; ?>" class="alt_btn">
                </div>
            </footer>
        </form>
    </article>
<?php } ?>
<script>
    $(document).ready(function() {


        $('input[name=enable_ffmpeg]').change(function () {
            var value = $('input[name=enable_ffmpeg]:checked').val();

            if(value == 1)
                $('#ffmpeg_mode').fadeIn();
            else
                $('#ffmpeg_mode').fadeOut();
        });






    });
</script>   