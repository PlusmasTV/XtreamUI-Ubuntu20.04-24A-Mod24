<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <center>
        <table>
            <tbody>
            <tr>
                <td><form method="post" action="users.php?show=show_all"><div class="submit_link"><input type="submit" value="<?php echo $_LANG['show_all']; ?>" class="alt_btn"></div></form></td>
                <td><form method="post" action="users.php?show=restreamers"><div class="submit_link"><input type="submit" value="<?php echo $_LANG['show_restreamers']; ?>" class="alt_btn"></div></form></td>
                <td><form method="post" action="users.php?show=streamers"><div class="submit_link"><input type="submit" value="<?php echo $_LANG['show_streamers']; ?>" class="alt_btn"></div></form></td>
            </tr>
            </tbody>
        </table>
    </center>

    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_accs']; ?></h3>
        </header>

        <div id="dialogDiv" style="display: none;"><?php echo $_LANG['loading']; ?></div>

        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['online']; ?></th>
                <th><?php echo $_LANG['status']; ?></th>
                <th><?php echo $_LANG['owner']; ?></th>
                <th><?php echo $_LANG['username']; ?></th>
                <th><?php echo $_LANG['password']; ?></th>
                <th><?php echo $_LANG['expire_date']; ?></th>
                <th><?php echo $_LANG['connections']; ?></th>
                <th><?php echo $_LANG['bandwidth_per_con']; ?></th>
                <th><?php echo $_LANG['bouquet']; ?></th>
                <th style="width:90px;"><?php echo $_LANG['download']; ?></th>
                <th><?php echo $_LANG['ls_channel']; ?></th>
                <th><?php echo $_LANG['user_activity']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach($users as $user)
            {

                if($user['is_restreamer'] == 1)
                {
                    $color = "CCFFFF";
                }
                else
                {
                    $color = "FFFFFF";
                }
                echo "<tr>";

                if($user['active_connections'] > 0)
                {
                    $status_image = "<img src='../templates/images/online.png' title='Online'>";
                }
                else
                {
                    $status_image = "<img src='../templates/images/offline.png' title='Offline'>";
                }


                echo "<td bgcolor='#$color'>$status_image</td>";  
                                
                                
                                if ($user['status'] == 0) {
                                    echo "<td bgcolor='#$color'><img src='../templates/images/block_big.png' /></td>";
                                }elseif(time() > $user['exp_date'])
                                {
                                    echo "<td bgcolor='#$color'><img src='../templates/images/expired.png' title='Expired' /></td>";
                                }
                                else
                                {
                                    echo "<td bgcolor='#$color'><img src='../templates/images/ok.png' /></td>";
                                }
                                
                                echo "<td bgcolor='#$color'><font color='black'>" . $user['owner'] . "</font></td>";
                                echo "<td bgcolor='#$color'><font color='black'>" . $user['username'] . "</font></td>";
                                echo "<td bgcolor='#$color'><font color='black'>" . $user['password'] . "</font></td>";
                                if (time() > $user['exp_date']) {
                                    echo "<td bgcolor='#$color'><font color='red'><b>{$_LANG['expired']}</b></font></td>";
                                } elseif (time() + 43200 > $user['exp_date']) {
                                    echo "<td bgcolor='#$color'><font color='orange'><b>" . date("j F, Y, g:i a", $user['exp_date']) .
                                        "</b></font></td>";
                                } else
                                    echo "<td bgcolor='#$color'>" . date("j F, Y, g:i a", $user['exp_date']) . "</td>";
                                
                                 echo "<td bgcolor='#$color'><font color='black'>" .$user['active_connections'] . "/" . $user['max_connections'] . "</font></td>";
                                 
                                 if($user['allowed_bandwidth'] == 0)
                                 {
                                     echo "<td bgcolor='#$color'><font color='purple'><b>{$_LANG['unlimited']}</b></font></td>";
                                 }
                                 else
                                 {
                                     echo "<td bgcolor='#$color'><font color='black'>" . $user['allowed_bandwidth'] . " MB</font></td>";
                                 }
                                echo "<td bgcolor='#$color'>".$user['bouquet_name']."</td>";
                            ?>
                            
<td bgcolor="#<?php echo $color; ?>">
    <select style="width:90px;" name="cars" onchange="if (this.value !== undefined && this.value !== null) { var x = this.value; var arr = x.split(':'); window.location='users.php?action=' + arr[0] + '&type=' + arr[1] + '&user_id=<?php echo $user['id']; ?>' }">
        <option value="" selected>-</option>
        <option style="background-color:orange;" value="">=[Receivers]=</option>
        <option value="download_list:gigablue">GigaBlue</option>
        <option value="download_list:enigma16">Enigma2 OE 1.6</option>
        <option value="download_list:dreambox">DreamBox OE 2.0</option>
        <option value="download_list:m3u">m3u File</option>
        <option value="download_list:pcm3u">PC m3u File</option>
        <option value="download_list:simple">Simple</option>
        <option value="download_list:octagon">Octagon</option>
        <option value="download_list:starlivev3">StarLive v3</option>
        <option value="download_list:mediastar">MediaStar/StarLive v4</option>
        <option value="download_list:starlivev5">StarLive v5</option>
        <option style="background-color:orange;" value="">=[Scripts]=</option>
        <option value="generate_script:enigma16">Enigma2 OE 1.6 Auto Update Channels</option>
        <option value="generate_script:dreambox">DreamBox Auto Update Channels</option>
    </select>


    </div>

</td>
                            <td bgcolor="#<?php echo $color; ?>"><?php echo ($user['active_connections'] > 0) ? $user['last_seen'] : "-"; ?></td>
                            <td bgcolor="#<?php echo $color; ?>"><a onclick="ajax_request_dialog('users.php?action=user_activity&user_id=<?php echo $user["id"]; ?>','<?php echo $user['username']; ?>')" href="#" class="table-icon info" title="<?php echo $_LANG['view_user_activity']; ?>"></a></td>
                            <td bgcolor="#<?php echo $color; ?>">
                                <a href="users.php?action=user_kick&user_id=<?php echo $user['id']; ?>" class="table-icon kill" title="<?php echo $_LANG['kick_user']; ?>"></a>
                                <a href="users.php?action=user_enable&user_id=<?php echo $user['id']; ?>" class="table-icon enable" title="<?php echo $_LANG['enable_user']; ?>"></a>
                                <a href="users.php?action=user_disable&user_id=<?php echo $user['id']; ?>" class="table-icon disable" title="<?php echo $_LANG['disable_user']; ?>"></a>
                                <a href="edit_user.php?user_id=<?php echo $user['id']; ?>" class="table-icon edit" title="Edit User"></a>
                                <a onclick="return confirm('<?php echo $_LANG['delete_line']; ?>')" href="users.php?action=user_delete&user_id=<?php echo $user['id']; ?>" class="table-icon delete" title="Delete User"></a>
                            </td>
                            <?php
                            }
            ?>
            </tbody>
        </table>
    </article>
<?php } ?>

<script type="text/javascript">

    $(document).ready(function() {
        $('.menu').dropit();
    });
</script>