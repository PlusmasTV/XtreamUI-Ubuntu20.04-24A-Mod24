<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>
    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['tools']; ?></h3>
        </header>
        <table class="tablesorter" cellspacing="0">
            <thead>
            <tr>
                <th><?php echo $_LANG['tool_name']; ?></th>
                <th><?php echo $_LANG['description']; ?></th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <form method="post" action="tools.php?action=delete_stream_logs">
                <tr>
                    <td><?php echo $_LANG['clear_slogs']; ?></td>
                    <td><?php echo $_LANG['clear_slogs_desc']; ?></td>
                    <td>
                        <div class="submit_link"><input type="submit" value="<?php echo $_LANG['run_tool'];?>" class="alt_btn" />
                    </td>
                </tr>
            </form>
            <form method="post" action="tools.php?action=kill_active_cons">
                <tr>
                    <td><?php echo $_LANG['kill_all']; ?></td>
                    <td><?php echo $_LANG['kill_all_desc']; ?></td>
                    <td>
                        <div class="submit_link"><input type="submit" value="<?php echo $_LANG['run_tool'];?>" class="alt_btn" />
                    </td>
                </tr>
            </form>
            <form method="post" action="tools.php?action=delete_closed_connections">
                <tr>
                    <td><?php echo $_LANG['delete_closed']; ?></td>
                    <td><?php echo $_LANG['delete_closed_desc']; ?></td>
                    <td>
                        <div class="submit_link"><input type="submit" value="<?php echo $_LANG['run_tool'];?>" class="alt_btn" />
                    </td>
                </tr>
            </form>
            <form method="post" action="tools.php?action=delete_connections">
                <tr>
                    <td><?php echo $_LANG['delete_closed_based']; ?></td>
                    <td><?php echo $_LANG['delete_closed_based_desc']; ?></td>
                    <td>
                        <div class="submit_link"><input type="text" name="seconds" /><br /><input type="submit" value="<?php echo $_LANG['run_tool'];?>" class="alt_btn" />
                    </td>
                </tr>
            </form>
            <form method="post" action="tools.php?action=stop_streams">
                <tr>
                    <td><?php echo $_LANG['stop_streams_based']; ?></td>
                    <td><?php echo $_LANG['stop_streams_based_desc']; ?></td>
                    <td>
                        <div class="submit_link"><input type="text" name="problem_status_in_a_row" /><br /><input type="submit" value="<?php echo $_LANG['run_tool'];?>" class="alt_btn" />
                    </td>
                </tr>
            </form>
            </tbody>
        </table>
    </article>
<?php } ?>