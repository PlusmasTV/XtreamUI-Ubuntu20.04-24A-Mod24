<?php
if(!empty($er_message))
    echo show_message('error',$er_message);
else {

    if(!empty($info_message))
        echo show_message('info',$info_message);

    if(!empty($warn_message))
        echo show_message('warning',$warn_message);

    if(!empty($ok_message))
        echo show_message('ok',$ok_message);

    ?>

    <article class="module width_full">
        <header><h3 class="tabs_involved"><?php echo $_LANG['manage_streams']; ?></h3>
        </header>


        <center>
            <table>
                <tbody>
                <tr>
                    <td><form method="post" action="streams.php?action=start_all"> <div class="submit_link"><input type="submit" value="<?php echo $_LANG['start_all']; ?>" class="alt_btn"></div></form></td>
                    <td><form method="post" action="streams.php?action=stop_all"> <div class="submit_link"><input type="submit" value="<?php echo $_LANG['stop_all']; ?>" class="alt_btn"></div></form></td>
                </tr>
                </tbody>
            </table>
        </center>

        <div id="dialogDiv" style="display: none;"><?php echo $_LANG['loading']; ?></div>

        <table class="tablesorter" cellspacing="0" >
            <thead>
            <tr>
                <th><?php echo $_LANG['status']; ?></th>
                <th><?php echo $_LANG['stream_name']; ?></th>
                <th><?php echo $_LANG['category_name']; ?></th>
                <th><?php echo $_LANG['online_clients']; ?></th>
                <th><?php echo $_LANG['uptime_stream']; ?></th>
                <th><?php echo $_LANG['audio_codec']; ?></th>
                <th><?php echo $_LANG['video_codec']; ?></th>
                <th><?php echo $_LANG['restarts']; ?></th>
                <th><?php echo $_LANG['debug']; ?></th>
                <th><?php echo $_LANG['options']; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach($streams as $stream)
            {
                if(is_null($stream['category_name']))
                {
                    $stream['category_name'] = '-';
                }
                echo "<tr>";

                $audio = "<img src='../templates/images/mini_nok.png' />";
                $video = "<img src='../templates/images/mini_nok.png' />";

                if(is_null($stream['pid']))
                {
                    $color = "FFD6CC";
                    $status = "Stopped";

                    $audio = $video = '-';
                }
                elseif( ! ps_running($stream['pid'] ) && $stream['problem_status'] == 0)
                {
                    $color = "FFFFE0";
                    $status = $_LANG['stream_closed_unexp'];
                }
                elseif($stream['problem_status'] > 0)
                {
                    switch((int)$stream['problem_status'])
                    {
                        case 2:
                            $status = "<img src='../templates/images/warning.png' /><br />{$_LANG['source_down']}";
                            $color = "FFB2B2";
                            break;

                        case 1:
                            $status = "<img src='../templates/images/warning.png' /><br />{$_LANG['restream_error']}";
                            $color = "FFFFCC";
                            break;
                    }

                }
                else
                {
                    if(!is_null($stream['stream_info']))
                    {
                        $stream_info = json_decode($stream['stream_info'],true);

                        $audio = (!isset($stream_info['audio']) || is_null($stream_info['audio'])) ? $audio : "<img src='../templates/images/mini_ok.png' /><br />" . $stream_info['audio'];
                        $video = (!isset($stream_info['video']) || is_null($stream_info['video'])) ? $video : "<img src='../templates/images/mini_ok.png' /><br />" .  $stream_info['video'];
                    }
                    else
                    {
                        $audio = "<img src='../templates/images/mini_loading.gif' />";
                        $video = "<img src='../templates/images/mini_loading.gif' />";
                    }

                    $color = "D1FFC2";
                    $status = "<img src='../templates/images/ok.png' />";
                }

                echo "<td bgcolor='#$color\'><b>$status</b>";

                            echo  "<td bgcolor='#$color'><b>{$stream['stream_display_name']}</b></td>";
                            echo  "<td bgcolor='#$color'>{$stream['category_name']}</td>";
                            echo  "<td bgcolor='#$color'>{$stream['total_online_clients']}</td>";

                            if(is_null($stream['stream_started']) || $stream['problem_status'] > 0 || !ps_running($stream['pid']) )
                            {
                                echo  "<td bgcolor='#$color'>-</td>";
                            }
                            else
                            {
                                echo  "<td bgcolor='#$color'>".gmdate("H:i:s",time() - $stream['stream_started'])."</td>";
                            }
                            echo  "<td bgcolor='#$color'>$audio</td>";
                            echo  "<td bgcolor='#$color'>$video</td>";

                            echo "<td bgcolor='#$color'> {$stream['total_logs']}</td>";

                            ?>
                            <td bgcolor="#<?php echo $color; ?>">
                                <a class="table-icon download" title="<?php echo $_LANG['download_log']; ?>" onclick="ajax_request_dialog('streams.php?action=debug&stream_id=<?php echo $stream['id']; ?>','<?php echo $_LANG['debug_stream']; ?>','white')" href="#" ></a>
                            </td>

<td bgcolor="#<?php echo $color; ?>">
    <a href="streams.php?action=str_start&stream_id=<?php echo $stream['id']; ?>" class="table-icon play" title="<?php echo $_LANG['start_stream']; ?>"></a>
    <a href="streams.php?action=str_stop&stream_id=<?php echo $stream['id']; ?>" class="table-icon stop" title="<?php echo $_LANG['stop_stream']; ?>"></a>
    <a href="streams.php?action=str_restart&stream_id=<?php echo $stream['id']; ?>" class="table-icon restart" title="<?php echo $_LANG['restart_stream']; ?>"></a>
    <?php echo "<a onclick='ajax_request_dialog('streams.php?action=open_stream&stream_id={$stream['id']}','{$_LANG['live_streaming_test']}','black')'   class='table-icon live' href='#' title='{$_LANG['live_stream']}'></a>"; ?>
    <a href="edit_stream.php?stream_id=<?php echo $stream['id']; ?>" class="table-icon edit" title="<?php echo $_LANG['edit_stream']; ?>"></a>
    <a onclick="return confirm('<?php echo $_LANG['delete_stream_conf']; ?>')" href="streams.php?action=str_delete&stream_id=<?php echo $stream['id']; ?>" class="table-icon delete" title="<?php echo $_LANG['delete_stream']; ?>"></a>
</td>
</tr>
                        <?php } ?>
            </tbody>
        </table>
    </article>

<?php } ?>