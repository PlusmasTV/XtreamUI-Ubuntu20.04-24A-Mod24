<?php

/**
 * @author Xtream-Codes
 * @copyright 2013
 */
$_QUERIES = array();

$_QUERIES['1.2.0'][] = "ALTER TABLE  `streams` ADD  `live_caching` INT NULL DEFAULT NULL";
$_QUERIES['1.2.0'][] = "ALTER TABLE  `streams` ADD  `movie_sub` TEXT NULL DEFAULT NULL";
$_QUERIES['1.2.0'][] = "ALTER TABLE  `streams` ADD  `sub_encoding` TEXT NULL DEFAULT NULL";
$_QUERIES['1.2.0'][] = "ALTER TABLE  `streams` ADD  `type_of_stream` TEXT NOT NULL AFTER  `id`";
$_QUERIES['1.2.0'][] = "ALTER TABLE  `streams` ADD  `movie_path` TEXT NULL DEFAULT NULL AFTER  `stream_link`";
$_QUERIES['1.2.0'][] = "ALTER TABLE  `streams` CHANGE  `stream_link`  `stream_link` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;";
$_QUERIES['1.2.0'][] = "UPDATE `streams` SET `type_of_stream` = 'live';";

$_QUERIES['2.0.0'][] = "ALTER TABLE  `users` ADD  `max_connections` INT NOT NULL DEFAULT  '1' AFTER  `bouquet`;";
$_QUERIES['2.0.0'][] = "ALTER TABLE  `users` ADD  `allowed_bandwidth` INT NOT NULL DEFAULT  '0' AFTER  `max_connections`;";
$_QUERIES['2.0.0'][] = "ALTER TABLE  `users` ADD  `online` INT NOT NULL DEFAULT  '0' AFTER  `allowed_bandwidth`;";
$_QUERIES['2.0.0'][] = "ALTER TABLE `streams` DROP `dest_ext_port`;";

$_QUERIES['2.0.0'][] = "CREATE TABLE IF NOT EXISTS `user_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `user_agent` text,
  `user_ip` text NOT NULL,
  `connection_number` int(11) NOT NULL,
  `end` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL,
  `bandwidth` int(11) NOT NULL DEFAULT '0',
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;";

$_QUERIES['2.1.0'][] = "ALTER TABLE  `streams` ADD  `pid` INT NULL DEFAULT NULL";

$_QUERIES['2.1.0'][] = "ALTER TABLE  `streams` DROP  `type_of_stream` ,
DROP  `movie_path` ,
DROP  `stream_desync` ,
DROP  `proxy` ,
DROP  `user_agent` ,
DROP  `log` ,
DROP  `proxy_error` ,
DROP  `live_caching` ,
DROP  `movie_sub` ,
DROP  `sub_encoding`;";
$_QUERIES['2.1.0'][] = "ALTER TABLE  `streams` CHANGE  `channel_name`  `stream_display_name` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL";
$_QUERIES['2.1.0'][] = "ALTER TABLE  `streams` CHANGE  `stream_link`  `stream_source` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL";
$_QUERIES['2.1.0'][] = "ALTER TABLE `user_activity` DROP `end`;";
$_QUERIES['2.1.0'][] = "ALTER TABLE `streams` DROP `status`;";
$_QUERIES['2.1.0'][] = "ALTER TABLE  `user_activity` CHANGE  `pid`  `pid` INT( 11 ) NULL DEFAULT NULL";
$_QUERIES['2.1.0'][] = "ALTER TABLE  `streams` ADD  `order` INT NOT NULL DEFAULT  '1'";
$_QUERIES['2.1.0'][] = "ALTER TABLE  `users` CHANGE  `exp_date`  `exp_date` INT NOT NULL";
$_QUERIES['2.1.0'][] = "ALTER TABLE `settings` DROP `nginx_path`;";
$_QUERIES['2.1.0'][] = "ALTER TABLE `settings` ADD  `network_interface` TEXT NOT NULL";
$_QUERIES['2.1.0'][] = "ALTER TABLE  `streams` ADD  `restarts_in_a_row` INT NOT NULL DEFAULT  '0'";
$_QUERIES['2.1.0'][] = "CREATE TABLE IF NOT EXISTS `streams_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `argument_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;";
$_QUERIES['2.1.0'][] = "CREATE TABLE IF NOT EXISTS `vlc_arguments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `argument_name` text NOT NULL,
  `argument_description` text NOT NULL,
  `argument_key` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
$_QUERIES['2.1.0'][] = "ALTER TABLE `users` DROP `online`";
$_QUERIES['2.1.0'][] = "ALTER TABLE `user_activity` DROP `connection_number`;";
$_QUERIES['2.1.0'][] = "INSERT INTO `vlc_arguments` (`id`, `argument_name`, `argument_description`, `argument_key`) VALUES
(1, 'User Agent', 'You can use a custom User agent or use a known one', ':http-user-agent'),
(2, 'Audio Desync', 'This delays the audio output. The delay must be given in milliseconds. This can be handy if you notice a lag between the video and the audio.', '--audio-desync'),
(3, 'HTTP Proxy', 'HTTP proxy to be used It must be of the form http://[user@]myproxy.mydomain:myport/If empty, the http_proxy environment variable will be tried.', '--http-proxy'),
(4, 'SubTitle File', 'Load this subtitle file. Useful if you stream a movie and you want subtitles', '--sub-file'),
(5, 'SubTitles Encoding', 'Subtitles text encoding', '--subsdec-encoding'),
(6, 'Live Capture Caching', 'Caching value for cameras and microphones, in milliseconds.', '--live-caching'),
(7, 'Network Caching', 'Caching value for network resources, in milliseconds.', '--network-caching'),
(8, 'Stream output muxer caching', 'This allow you to configure the initial caching amount for stream output muxer. This value should be set in milliseconds.', '--sout-mux-caching'),
(9, 'Transcode Video Encoder', 'This is the video encoder module that will be used (and its associated options).', '--sout-transcode-venc'),
(11, 'Transcode Destination Video Codec', 'This is the video codec that will be used.', '--sout-transcode-vcodec'),
(12, 'Transcode Video Bitrate', 'Target bitrate of the transcoded video stream.', '--sout-transcode-vb'),
(13, 'Transcode Video Scaling', 'Scale factor to apply to the video while transcoding (eg: 0.25)', '--sout-transcode-scale'),
(14, 'Transcode Video Frame-Rate', 'Target output frame rate for the video stream.', '--sout-transcode-fps'),
(15, 'Transcode Video Width', 'Output video width.', ':sout-transcode-width'),
(16, 'Transcode Video Height', 'Output video height.', ':sout-transcode-height'),
(17, 'Transcode Maximum Video Width', 'Maximum output video width.', '--sout-transcode-maxwidth'),
(18, 'Transcode Maximum Video Height', 'Maximum output video height.', '--sout-transcode-maxheight'),
(19, 'Transcode Video Filter', 'Video filters will be applied to the video streams (after overlays are applied). You can enter a colon-separated list of filters.', '--sout-transcode-vfilter'),
(20, 'Transcode Audio Encoder', 'This is the audio encoder module that will be used (and its associated options).', '--sout-transcode-aenc'),
(21, 'Transcode Destination Audio Codec', 'This is the audio codec that will be used.', '--sout-transcode-acodec'),
(22, 'Transcode Audio Bitrate', 'Target bitrate of the transcoded audio stream.', '--sout-transcode-ab'),
(23, 'Transcode Audio Sample Rate', 'Sample rate of the transcoded audio stream (11250, 22500, 44100 or 48000).', '--sout-transcode-samplerate'),
(24, 'Transcode Audio Filter', 'Audio filters will be applied to the audio streams (after conversion filters are applied). You can enter a colon-separated list of filters.', '--sout-transcode-afilter');";
$_QUERIES['2.1.6'][] = "ALTER TABLE  `user_activity` ADD INDEX (  `user_id` ,  `stream_id` );";
$_QUERIES['2.1.6'][] = "ALTER TABLE  `streams_options` ADD INDEX (  `stream_id` );";

$_QUERIES['2.1.7'][] = "CREATE TABLE IF NOT EXISTS `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(39) NOT NULL,
  `notes` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";

$_QUERIES['2.1.10'][] = "ALTER TABLE `streams` CHANGE `dest_int_port` `dest_stream_port` INT NOT NULL;";
$_QUERIES['2.1.10'][] = "ALTER TABLE `streams` ADD `dest_restream_port` INT NOT NULL AFTER `dest_stream_port`;";
$_QUERIES['2.1.10'][] = "ALTER TABLE  `users` ADD  `is_restreamer` TINYINT NOT NULL DEFAULT  '0' AFTER  `allowed_bandwidth` ;";
$_QUERIES['2.1.10'][] = "ALTER TABLE `settings` DROP `script_dir`,DROP `vlc_dir`;";
$_QUERIES['2.1.10'][] = "ALTER TABLE  `settings` DROP  `super_username` ;";
$_QUERIES['2.1.10'][] = "ALTER TABLE  `settings` CHANGE  `super_password`  `live_streaming_pass` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;";
$_QUERIES['2.1.12'][] = "ALTER TABLE `users` ADD `allowed_ips` TEXT NOT NULL ;";
$_QUERIES['2.1.12'][] = "CREATE TABLE `blocked_user_agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_agent` text NOT NULL,
  `exact_match` int(11) NOT NULL DEFAULT '0',
  `block_line` int(11) NOT NULL DEFAULT '0',
  `attempts_blocked` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;";

$_QUERIES['2.1.13'][] = "ALTER TABLE `streams` ADD `problem_status` INT NOT NULL DEFAULT '0';";
$_QUERIES['2.2.0'][] = "ALTER TABLE  `streams` CHANGE  `restarts_in_a_row`  `problem_status_in_a_row` INT( 11 ) NOT NULL DEFAULT  '0'";
$_QUERIES['2.2.0'][] = "ALTER TABLE `streams` DROP `dest_restream_port`";
$_QUERIES['2.2.0'][] = "ALTER TABLE `streams` ADD  `stream_info` TEXT NULL DEFAULT NULL;";
$_QUERIES['2.2.0'][] = "ALTER TABLE  `vlc_arguments` ADD  `argument_default_value` TEXT NULL DEFAULT NULL AFTER  `argument_key`;";
$_QUERIES['2.2.0'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  '4000' WHERE `id` =6;";
$_QUERIES['2.2.0'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  '4000' WHERE `id` =7;";
$_QUERIES['2.2.0'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  '4000' WHERE `id` =8;";
$_QUERIES['2.2.0'][] = "ALTER TABLE  `logs` CHANGE  `stream_name`  `stream_id` INT NOT NULL;";
$_QUERIES['2.2.0'][] = "ALTER TABLE  `logs` ADD INDEX (  `stream_id` );";

$_QUERIES['2.3.0'][] = "ALTER TABLE  `users` ADD  `member_id` INT NULL DEFAULT NULL AFTER  `id`;";
$_QUERIES['2.3.0'][] = "ALTER TABLE `streams` DROP `stream_name`;";
$_QUERIES['2.3.0'][] = "ALTER TABLE  `settings` ADD  `email_verify_sub` TEXT NOT NULL ,
ADD  `email_verify_cont` TEXT NOT NULL ,
ADD  `email_forgot_sub` TEXT NOT NULL ,
ADD  `email_forgot_cont` TEXT NOT NULL ,
ADD  `mail_from` TEXT NOT NULL ,
ADD  `smtp_host` TEXT NOT NULL ,
ADD  `smtp_port` INT NOT NULL ,
ADD  `confirmation_email` INT NOT NULL ,
ADD  `min_password` INT NOT NULL DEFAULT  '5',
ADD  `username_strlen` INT NOT NULL DEFAULT  '15',
ADD  `username_alpha` INT NOT NULL DEFAULT  '1',
ADD  `allow_multiple_accs` INT NOT NULL DEFAULT  '0',
ADD  `allow_registrations` INT NOT NULL DEFAULT  '0',
ADD  `server_name` TEXT NOT NULL,
ADD  `use_remote_smtp` INT NOT NULL ,
ADD  `smtp_username` TEXT NOT NULL ,
ADD  `smtp_password` TEXT NOT NULL ,
ADD  `email_new_pass_sub` TEXT NOT NULL ,
ADD  `logo_url` TEXT NOT NULL,
ADD  `email_new_pass_cont` TEXT NOT NULL,
ADD  `smtp_from_name` TEXT NOT NULL";

$_QUERIES['2.3.0'][] = "CREATE TABLE IF NOT EXISTS `member_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` text NOT NULL,
  `group_color` varchar(7) NOT NULL DEFAULT '#000000',
  `is_banned` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;";

$_QUERIES['2.3.0'][] = "CREATE TABLE IF NOT EXISTS `reg_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date_registered` int(11) NOT NULL,
  `verify_key` text,
  `last_login` int(11) DEFAULT NULL,
  `member_group_id` int(11) NOT NULL,
  `verified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;";

$_QUERIES['2.3.0'][] = "INSERT INTO `reg_users` (`username`,`password`,`email`,`ip`,`date_registered`,`member_group_id`,`verified`) SELECT 'admin',MD5(admin_password),'email@xtream-codes.com','127.0.0.1',UNIX_TIMESTAMP(),1,1 FROM `settings` WHERE `id` = 1;";

$_QUERIES['2.3.0'][] = "INSERT INTO `member_groups` (`id`, `group_name`, `group_color`, `is_banned`, `is_admin`, `can_delete`) VALUES
(1, 'Administrators', '#FF0000', 0, 1, 0),
(2, 'Registered Users', '#009900', 0, 0, 0),
(3, 'Banned', '#194775', 1, 0, 0);";

$_QUERIES['2.3.0'][] = "ALTER TABLE `settings` DROP `admin_password`";
$_QUERIES['2.3.0'][] = "UPDATE `users` SET `member_id` = 1";
$_QUERIES['2.3.0'][] = "UPDATE `vlc_arguments` SET  `argument_key` =  ':http-proxy' WHERE `id` = 3;";
$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `logo_url` = '../templates/images/logo.png' WHERE `id` = 1;";

$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `email_verify_sub` = 'Verify Registration @ {SERVER_NAME}' WHERE `id` = 1;";
$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `email_forgot_sub` = 'Forgot Password @ {SERVER_NAME}' WHERE `id` = 1;";
$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `email_new_pass_sub` = 'Your New Password @ {SERVER_NAME}' WHERE `id` = 1;";

$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `email_verify_cont` = 'Hello,<p><br></p><p>Please Click at the following URL to activate your account {VERIFY_LINK}</p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>' WHERE `id` = 1;";
$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `email_forgot_cont` = 'Hello,<p><br></p><p>Someone requested new password @&nbsp;&nbsp;{SERVER_NAME} . To verify this request please click at the following link: {FORGOT_LINK}<br></p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>' WHERE `id` = 1;";
$_QUERIES['2.3.0'][] = "UPDATE `settings` SET `email_new_pass_cont` = 'Hello,<p><br></p><p>Your New Password is: {NEW_PASSWORD}<br></p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>' WHERE `id` = 1;";

$_QUERIES['2.3.1'][] = "ALTER TABLE  `users` ADD INDEX (  `member_id` ) ;";
$_QUERIES['2.3.1'][] = "ALTER TABLE  `reg_users` ADD INDEX (  `member_group_id` ) ;";

$_QUERIES['2.3.2'][] = "CREATE TABLE IF NOT EXISTS `stream_mux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mux_name` text NOT NULL,
  `mux_code` text NOT NULL,
  `mux_header` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;";

$_QUERIES['2.3.2'][] = "INSERT INTO `stream_mux` (`id`, `mux_name`, `mux_code`, `mux_header`) VALUES
(1, 'Transport Stream [TS]', 'ts', NULL),
(2, 'FFmpeg FLV', 'ffmpeg{mux=flv}', '{mime=video/x-flv}'),
(3, 'VLC FLV', 'flv', '{mime=video/x-flv}');";

$_QUERIES['2.3.2'][] = "ALTER TABLE  `streams` ADD  `mux_id` INT NOT NULL";
$_QUERIES['2.3.2'][] = "UPDATE `streams` SET `mux_id` = 1;";


$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `transcode_id`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `movie_length_secs`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `stream_started`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `stream_output`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `custom_command`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `type`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `stream_info`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `mux_id`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `order`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` DROP  `problem_status_in_a_row`;";

$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `dest_stream_port` INT NOT NULL AFTER `stream_source`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `problem_status` INT( 11 ) NULL DEFAULT '0';";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `stream_info` TEXT NULL DEFAULT NULL;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `mux_id` INT( 11 ) NULL DEFAULT NULL;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `movie_length_secs` VARCHAR( 255 ) NULL DEFAULT NULL ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `type` VARCHAR( 255 ) NOT NULL AFTER `id`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `streams` ADD `movie_file` VARCHAR( 255 ) NULL DEFAULT NULL;";

$_QUERIES['2.5.0'][] = "DELETE FROM `vlc_arguments` WHERE `id` = 4 LIMIT 1;";
$_QUERIES['2.5.0'][] = "DELETE FROM `vlc_arguments` WHERE `id` = 5 LIMIT 1;";
$_QUERIES['2.5.0'][] = "DELETE FROM `cronjobs` WHERE `id` > 2;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `user_activity` ADD INDEX (  `pid` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `user_activity` ADD INDEX (  `date_end` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `user_activity` ADD INDEX (  `stream_pid` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `user_activity` ADD INDEX (  `user_id` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `logs` ADD INDEX (  `stream_id` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `settings` ADD  `smtp_encryption` TEXT NOT NULL;";
$_QUERIES['2.5.0'][] = "DROP TABLE `stream_mux`;";
$_QUERIES['2.5.0'][] = "DROP TABLE `vlc_arguments`;";
$_QUERIES['2.5.0'][] = "DROP TABLE `streams_options`;";
$_QUERIES['2.5.0'][] = "DROP TABLE `stream_output`;";
$_QUERIES['2.5.0'][] = "TRUNCATE `user_activity`;";
$_QUERIES['2.5.0'][] = "TRUNCATE `logs`;";


$_QUERIES['2.5.0'][] = "CREATE TABLE IF NOT EXISTS `streams_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `argument_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";


$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams_options` ADD INDEX (  `stream_id` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams_options` ADD INDEX (  `argument_id` ) ;";

$_QUERIES['2.5.0'][] = "DROP TABLE `stream_mux`;";
$_QUERIES['2.5.0'][] = "CREATE TABLE IF NOT EXISTS `stream_mux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mux_name` text NOT NULL,
  `mux_code` text NOT NULL,
  `mux_header` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;";

$_QUERIES['2.5.0'][] = "INSERT INTO `stream_mux` (`id`, `mux_name`, `mux_code`, `mux_header`) VALUES(1, 'Transport Stream [TS]', 'ts', NULL),(2, 'FFmpeg FLV', 'ffmpeg{mux=flv}', '{mime=video/x-flv}'),(3, 'VLC FLV', 'flv', '{mime=video/x-flv}');";

$_QUERIES['2.5.0'][] = "UPDATE streams SET mux_id = 1;";
$_QUERIES['2.5.0'][] = "UPDATE streams SET `type` = 'live';";
$_QUERIES['2.5.0'][] = "UPDATE `streams` SET `type` = 'live';";

$_QUERIES['2.5.0'][] = "DROP TABLE `vlc_arguments`;";
$_QUERIES['2.5.0'][] = "CREATE TABLE IF NOT EXISTS `vlc_arguments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `argument_name` text NOT NULL,
  `argument_description` text NOT NULL,
  `argument_key` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";

$_QUERIES['2.5.0'][] = "INSERT INTO `vlc_arguments` (`id`, `argument_name`, `argument_description`, `argument_key`) VALUES
(1, 'User Agent', 'You can use a custom User agent or use a known one', ':http-user-agent'),
(2, 'Audio Desync', 'This delays the audio output. The delay must be given in milliseconds. This can be handy if you notice a lag between the video and the audio.', '--audio-desync'),
(3, 'HTTP Proxy', 'HTTP proxy to be used It must be of the form http://[user@]myproxy.mydomain:myport/If empty, the http_proxy environment variable will be tried.', '--http-proxy'),
(6, 'Live Capture Caching', 'Caching value for cameras and microphones, in milliseconds.', '--live-caching'),
(7, 'Network Caching', 'Caching value for network resources, in milliseconds.', '--network-caching'),
(8, 'Stream output muxer caching', 'This allow you to configure the initial caching amount for stream output muxer. This value should be set in milliseconds.', '--sout-mux-caching'),
(9, 'Transcode Video Encoder', 'This is the video encoder module that will be used (and its associated options).', '--sout-transcode-venc'),
(11, 'Transcode Destination Video Codec', 'This is the video codec that will be used.', '--sout-transcode-vcodec'),
(12, 'Transcode Video Bitrate', 'Target bitrate of the transcoded video stream.', '--sout-transcode-vb'),
(13, 'Transcode Video Scaling', 'Scale factor to apply to the video while transcoding (eg: 0.25)', '--sout-transcode-scale'),
(14, 'Transcode Video Frame-Rate', 'Target output frame rate for the video stream.', '--sout-transcode-fps'),
(15, 'Transcode Video Width', 'Output video width.', ':sout-transcode-width'),
(16, 'Transcode Video Height', 'Output video height.', ':sout-transcode-height'),
(17, 'Transcode Maximum Video Width', 'Maximum output video width.', '--sout-transcode-maxwidth'),
(18, 'Transcode Maximum Video Height', 'Maximum output video height.', '--sout-transcode-maxheight'),
(19, 'Transcode Video Filter', 'Video filters will be applied to the video streams (after overlays are applied). You can enter a colon-separated list of filters.', '--sout-transcode-vfilter'),
(20, 'Transcode Audio Encoder', 'This is the audio encoder module that will be used (and its associated options).', '--sout-transcode-aenc'),
(21, 'Transcode Destination Audio Codec', 'This is the audio codec that will be used.', '--sout-transcode-acodec'),
(22, 'Transcode Audio Bitrate', 'Target bitrate of the transcoded audio stream.', '--sout-transcode-ab'),
(23, 'Transcode Audio Sample Rate', 'Sample rate of the transcoded audio stream (11250, 22500, 44100 or 48000).', '--sout-transcode-samplerate'),
(24, 'Transcode Audio Filter', 'Audio filters will be applied to the audio streams (after conversion filters are applied). You can enter a colon-separated list of filters.', '--sout-transcode-afilter');";

$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams_options` ADD INDEX (  `stream_id` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams_options` ADD INDEX (  `argument_id` ) ;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `settings` DROP `thread_limit`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE `settings` ADD  `movies_path` VARCHAR( 255 ) NOT NULL;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams` ADD  `category_id` INT NULL DEFAULT NULL AFTER  `type`;";
$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams` ADD  `movie_status` TINYINT( 0 ) NULL DEFAULT NULL;";

$_QUERIES['2.5.0'][] = "CREATE TABLE IF NOT EXISTS `stream_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_type` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1";


$_QUERIES['2.5.0'][] = "INSERT INTO `stream_categories` (`id`, `category_type`, `category_name`) VALUES
(1, 'live', 'General Streams'),
(2, 'movie', 'General Movies');";

$_QUERIES['2.5.0'][] = "ALTER TABLE  `streams` ADD  `stream_started` INT NULL DEFAULT NULL;";
$_QUERIES['2.5.0'][] = "UPDATE  `settings` SET `movies_path` = '/iptv_xtream_codes/movies'";
$_QUERIES['2.5.0'][] = "DROP TABLE `streams_transcodes`";
$_QUERIES['2.5.0'][] = "DROP TABLE `streams_arguments`";
$_QUERIES['2.5.3'][] = "ALTER TABLE  `streams` ADD  `enable_ffmpeg` TINYINT NOT NULL DEFAULT  '0'";
$_QUERIES['2.5.3'][] = "UPDATE `streams` SET `dest_stream_port` = 20000 + `id`;";
$_QUERIES['2.5.3'][] = "ALTER TABLE  `vlc_arguments` ADD  `argument_default_value` TEXT NOT NULL;";
$_QUERIES['2.5.3'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  'Xtream-Codes IPTV Panel' WHERE `id` = 1;";
$_QUERIES['2.5.3'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  '20000' WHERE `id` = 6;";
$_QUERIES['2.5.3'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  '4000' WHERE `id` = 7;";
$_QUERIES['2.5.3'][] = "UPDATE `vlc_arguments` SET  `argument_default_value` =  '2000' WHERE `id` = 8;";
$_QUERIES['2.6.0'][] = "UPDATE `streams` SET  `enable_ffmpeg` = 0;";
$_QUERIES['2.6.0'][] = "ALTER TABLE  `settings` ADD  `unique_id` TEXT NOT NULL";
$_QUERIES['2.6.0'][] = "UPDATE `settings` t1, (SELECT `site_url` FROM `settings` LIMIT 1) tvalue SET t1.`unique_id` = tvalue.site_url;";
$_QUERIES['2.6.0'][] = "ALTER TABLE  `logs` CHANGE  `status`  `status` VARCHAR( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;";
$_QUERIES['2.6.0'][] = "ALTER TABLE  `logs` ADD INDEX (  `status` ) ;";
$_QUERIES['2.7.2'][] = "ALTER TABLE  `streams` ADD  `ffmpeg_bin` VARCHAR( 255 ) NULL DEFAULT NULL;";
$_QUERIES['2.7.2'][] = "ALTER TABLE  `streams` ADD  `h264_filter` TINYINT NOT NULL DEFAULT  '0';";
$_QUERIES['2.7.4'][] = "ALTER TABLE  `settings` ADD  `copyrights_removed` TINYINT NOT NULL;";
$_QUERIES['2.7.4'][] = "ALTER TABLE  `settings` ADD  `copyrights_text` TEXT NOT NULL;";
$_QUERIES['2.7.8'][] = "ALTER TABLE  `streams` ADD  `enable_rtmpdump` TINYINT NOT NULL DEFAULT  '0';";
$_QUERIES['2.7.9'][] = "CREATE TABLE `languages` (`key` varchar(128) NOT NULL DEFAULT '', `language` varchar(4096) NOT NULL DEFAULT '', PRIMARY KEY (`key`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
$_QUERIES['2.7.9'][] = "INSERT INTO `languages`(`key`, `language`) VALUES('en', 'English'), ('es', 'Español'), ('br', 'Português'), ('it', 'Italian');";
?>