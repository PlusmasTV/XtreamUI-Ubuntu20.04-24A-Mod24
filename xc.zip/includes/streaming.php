<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

class ipTV_Stream
{
    /**
     * Database Instance
     *
     * @var\t\tinstance
     */
    static public $ipTV_db;


    /**
     * Restart Given Stream ID
     *
     * @param int $stream_id
     * @return bool
     */
    static public function StopStream( $stream_id )
    {
        self::$ipTV_db->query( "SELECT * FROM `streams` WHERE `id` = '%d' AND `pid` IS NOT NULL", $stream_id );
        if ( self::$ipTV_db->num_rows() > 0 )
        {
            //Stream Found!
            $stream_info = self::$ipTV_db->get_row();
            //Check if pid is Running
            @posix_kill( $stream_info['pid'], 9 );
            self::$ipTV_db->query( "UPDATE `streams` SET `stream_info` = NULL,`stream_started` = NULL,`pid` = NULL WHERE `id` = '%d'", $stream_id );
        }

        return true;
    }

    /**
     * PARSE $OPT Stream
     *
     * @param string $opt_stream
     * @return string [RTMPDUMP Command]
     */
    static public function ParseOPTstream( $opt_url )
    {
        if ( strtoupper( substr( $opt_url, 7, 4 ) ) != '$OPT' )
        {
            return $opt_url;
        }

        $rtmpdump_command = "rtmpdump ";

        $arguments = array(
            'playpath' => '-y',
            'swfurl' => '-s',
            'pageurl' => '-p',
            'token' => '-T' );


        $del = "rtmp-raw=";
        $pos = strpos( $opt_url, $del );
        $first_parse = substr( $opt_url, $pos + strlen( $del ), strlen( $opt_url ) - 1 );

        $second_parse = explode( " ", $first_parse );

        $rtmpdump_command .= '-r "' . $second_parse[0] . '" ';
        array_shift( $second_parse );

        foreach ( $second_parse as $argument )
        {
            $data = explode( '=', $argument, 2 );

            if ( count( $data ) != 2 )
            {
                continue;
            }

            $key = strtolower( $data[0] );
            if ( array_key_exists( $key, $arguments ) )
            {
                $rtmpdump_command .= $arguments[$key] . ' "' . $data[1] . '" ';
            }
        }
        $rtmpdump_command .= '-q';


        return $rtmpdump_command;
    }

    /**
     * Stream File Parser
     *
     * @param string FileName
     * @return array
     */
    static public function FileParser( $FileName )
    {

        if ( ! file_exists( $FileName ) )
        {
            return false;
        }

        $streams = array();


        $need_stream_url = false;
        $fp = fopen( $FileName, 'r' );

        while ( ! feof( $fp ) )
        {
            $line = trim( fgets( $fp ) );
            if ( empty( $line ) )
            {
                continue;
            }

            if ( stristr( $line, '#EXTM3U' ) )
            {
                continue;
            }

            if ( $need_stream_url )
            {
                $streams[$stream_name] = $line;
                $need_stream_url = false;
                continue;
            }

            if ( stristr( $line, '#EXTINF' ) && ! $need_stream_url )
            {
                $stream_name = trim( end( explode( ',', $line ) ) );
                $need_stream_url = true;
            }
        }
        return $streams;
    }


    /**
     * GetCodecs Of Given File
     *
     * @param string $folder
     * @param string $FileName
     * @return array / bool
     */
    static public function GetCodecs( $RequestURI )
    {

        $command = "";

        if ( strtoupper( substr( $RequestURI, 7, 4 ) ) == '$OPT' )
        {
            $command = self::ParseOPTstream( $RequestURI ) . ' |';

            $RequestURI = '-';
        }
        else
            $RequestURI = '"' . $RequestURI . '"';

        $codecs = json_decode( shell_exec( trim( "$command /usr/bin/timeout 20s " . FFPROBE_PATH . " -analyzeduration 10000000 -probesize 9000000 -i $RequestURI -v quiet -print_format json  -show_streams" ) ), true );

        if ( isset( $codecs['streams'] ) )
        {
            $output = array();

            foreach ( $codecs['streams'] as $codec )
            {
                if ( $codec['codec_type'] != "audio" && $codec['codec_type'] != 'video' )
                {
                    continue;
                }

                $output[$codec['codec_type']] = $codec['codec_name'];

            }


            return $output;
        }

        return false;
    }

    /**
     * Get Stream Command
     *
     * @param array $stream_info
     * @return bool
     */
    static public function GetStreamCommand( $stream_info, $debug = false )
    {
        if ( empty( $stream_info ) )
        {
            return false;
        }

        //Arguments
        self::$ipTV_db->query( "SELECT t2.argument_key,t1.value FROM `streams_options` t1,`vlc_arguments` t2 WHERE t1.stream_id = '%d' AND t1.argument_id = t2.id", $stream_info['id'] );
        $arguments = "";
        if ( self::$ipTV_db->num_rows() > 0 )
        {
            $arguments_rows = self::$ipTV_db->get_rows();

            foreach ( $arguments_rows as $argument )
            {
                $arguments .= ' ' . $argument['argument_key'] . '="' . $argument['value'] . '"';
            }
        }


        self::$ipTV_db->query( "SELECT * FROM `stream_mux` WHERE `id` = '%d'", $stream_info['mux_id'] );
        $mux_data = self::$ipTV_db->get_row();
        $mux_header = $mux_data['mux_header'];
        $mux_code = $mux_data['mux_code'];


        $stream_source = "'{$stream_info['stream_source']}'";

        $command = '';
        $end_command = ' -q >/dev/null 2>/dev/null & jobs -p';
        if ( $debug )
        {
            $command = '/usr/bin/timeout 10s ';
            $end_command = ' -vvv 2>&1';
        }


        if ( strtoupper( substr( $stream_info['stream_source'], 7, 4 ) ) == '$OPT' )
        {
            $command .= self::ParseOPTstream( $stream_info['stream_source'] ) . ' | ';
            $stream_source = '-'; //piped
        }
        elseif ( substr( $stream_info['stream_source'], 0, 7 ) == 'rtmp://' && $stream_info['enable_rtmpdump'] == 1 )
        {
            $command .= "rtmpdump -r " . $stream_info['stream_source'] . " -q | ";
            $stream_source = '-'; //piped
        }


        if ( $stream_info['enable_ffmpeg'] == 1 )
        {

            $command .= BIN_PATH . $stream_info['ffmpeg_bin'] . " -y -loglevel quiet -analyzeduration 10000000 -probesize 9000000 -i $stream_source -acodec copy -vcodec copy -flags -global_header ";
            if ( $stream_info['h264_filter'] == 1 )
            {
                $command .= ' -vbsf h264_mp4toannexb ';
            }
            $command .= '-f mpegts - | ';
            $stream_source = '-';
        }

        //Start Command-
        $command .= VLC_BIN . " -I dummy $stream_source $arguments --sout-all --http-host='127.0.0.1' --sout '#transcode{}:std{access=http{$mux_header},mux={$mux_code},dst=:" . $stream_info['dest_stream_port'] . "}' vlc://quit" . $end_command;

        return $command;
    }

    /**
     * Get FFmpeg Bins
     *
     * @param none
     * @return array
     */
    static public function GetFFmpegBins()
    {
        $files = scandir( BIN_PATH );

        $ffmpegs = array();
        foreach ( $files as $file )
        {
            if ( $file == '.' || $file == '..' || ! is_file( BIN_PATH . $file ) )
            {
                continue;
            }

            $output = shell_exec( BIN_PATH . $file . ' -version | head -1' );
            if ( stristr( $output, 'ffmpeg' ) )
            {
                $ffmpeg_bin = array();
                $ffmpeg_bin['bin'] = $file;
                $ffmpeg_bin['version'] = $output;

                $ffmpegs[] = $ffmpeg_bin;
            }
        }

        return $ffmpegs;
    }


    /**
     * Start Given Stream ID
     *
     * @param int $stream_id
     * @return bool
     */
    static public function StartStream( $stream_id )
    {

        self::$ipTV_db->query( "SELECT * FROM `streams` WHERE `id` = '%d'", $stream_id );
        if ( self::$ipTV_db->num_rows() > 0 )
        {
            //Stream Found!
            $stream_info = self::$ipTV_db->get_row();

            //Starting a Movie? Nah
            if ( $stream_info['type'] == 'movie' )
            {
                return false;
            }

            //Check if pid is Running
            if ( ps_running( $stream_info['pid'] ) )
            {
                posix_kill( $stream_info['pid'], 9 );
            }

            if ( empty( $stream_info['dest_stream_port'] ) )
            {

                $stream_port = ipTV_lib::GetNewPort();

                if ( $stream_port === false )
                {
                    return false;
                }


                self::$ipTV_db->query( "UPDATE `streams` SET `dest_stream_port` = '%d' WHERE `id` = '%d'", $stream_port, $stream_info['id'] );
                $stream_info['dest_stream_port'] = $stream_port;
            }


            $final_command = self::GetStreamCommand( $stream_info );
            $pid = intval( trim( shell_exec( $final_command ) ) );
            self::$ipTV_db->query( "UPDATE `streams` SET `pid` = '%d',`stream_info` = NULL,`stream_started` = '%d' WHERE `id` = '%d'", $pid, time(), $stream_info['id'] );

            if ( ! defined( 'IN_CHECKER' ) )
            {
                self::$ipTV_db->query( "UPDATE `streams` SET `problem_status` = 0 WHERE `id` = '%d'", $stream_info['id'] );
            }
            else
            {
                self::$ipTV_db->query( "INSERT INTO `logs` (`stream_id`,`date`,`status`) VALUES('%d','%d','Restart')", $stream_info['id'], time() );
            }
            return $pid;
        }

        return false;
    }

    /**
     * Is Stream Working
     *
     * @param int $stream_id
     * @return void
     */
    static public function StreamWorks( $port )
    {
        $fp = @fopen( "http://127.0.0.1:$port", "rb" );

        if ( ! $fp )
        {
            return false;
        }

        stream_set_blocking( $fp, 0 );
        $invalid = 0;
        $valid = 0;

        while ( ! feof( $fp ) && $invalid < 3 && $valid < 6 )
        {
            $line = fread( $fp, 8192 );
            if ( empty( $line ) )
            {
                ++$invalid;
            }
            else
            {
                $valid++;
                $invalid = 0;
            }

            sleep( 2 );
        }

        fclose( $fp );

        if ( $invalid == 3 || $valid != 6 )
        {
            return false;
        }

        return true;
    }

    /**
     * Debug Given Stream ID
     *
     * @param int $stream_id
     * @return void
     */
    static public function DebugStream( $stream_id )
    {
        self::$ipTV_db->query( "SELECT * FROM `streams` WHERE `id` = '%d'", $stream_id );
        if ( self::$ipTV_db->num_rows() > 0 )
        {
            //Stream Found!
            $stream_info = self::$ipTV_db->get_row();

            //Starting a Movie? Nah
            if ( $stream_info['type'] == 'movie' )
            {
                return false;
            }

            $command = self::GetStreamCommand( $stream_info, true );

            $fp = popen( $command, "r" );
            while ( ! feof( $fp ) )
            {
                $line = fgets( $fp );
                if ( empty( $line ) )
                {
                    usleep( 90000 );
                    continue;
                }

                echo $line;

            }
            pclose( $fp );
        }
    }

    /**
     * Get Stream Codecs In Background
     *
     * @param int $stream_id
     * @return void
     */
    static public function StreamAnalyze( $stream_id, $PHP_BIN = null )
    {
        if ( ! is_numeric( $stream_id ) )
        {
            return false;
        }

        if ( is_null( $PHP_BIN ) )
        {
            $PHP_BIN = sys_var( 'PHP_BIN' );
        }


        system( "nohup $PHP_BIN " . IPTV_ROOT_PATH . "codecs.php $stream_id >/dev/null 2>/dev/null &" );
    }

    /**
     * Get Duration
     *
     * @param string $FileSource
     * @return string
     */
    static public function GetDuration( $FileSource )
    {
        $output = shell_exec( "/usr/bin/timeout 8s " . FFPROBE_PATH . " -i " . $FileSource .  "2>&1" );
        preg_match( "/Duration\\: (.*?)\\,/", $output, $duration );
        if ( ! empty( $duration[1] ) && $duration[1] != 'N/A' )
        {
            list( $hours, $minutes, $seconds ) = explode( ':', $duration[1] );
            $total = intval( $hours * 3600 + $minutes * 60 + $seconds );
        }
        else
            $total = 'N/A';
        return $total;
    }

    /**
     * Movie Start
     *
     * @param Movie Name, Movie_Subtitles
     * @return bool
     */
    static public function StartMovie( $movie_name, $movie_source, $movie_subtitles = null, $go_faster = false, $movie_location = 'remote', $transcode = true, $category_id = null )
    {
        global $_LANG;
        if ( $movie_location == 'local' && ! is_file( $movie_source ) )
        {
            return $_LANG['no_file'];
        }

        if ( ! is_null( $movie_subtitles ) )
        {
            if ( ! file_exists( $movie_subtitles ) )
            {
                return $_LANG['subtitles_not_exists'];
            }
            else
            {
                $subtitles_command = " -vf subtitles='$movie_subtitles'";
            }
        }

        $rand = "";
        do
        {
            $movie_name = urldecode( $movie_name ) . $rand;
            $rand = mt_rand( 0, 10000 );
        } while ( RowExists( "streams", "stream_display_name", $movie_name ) );
        $movie_name_fixed = self::GetFixedStreamName( $movie_name );
        exec( "rm -rf " . MOVIES_PATH . $movie_name_fixed );
        mkdir( MOVIES_PATH . $movie_name_fixed );
        $pid = -1;
        if ( $transcode )
        {
            $command = "(" . FFMPEG_PATH;
            if ( ! $go_faster )
            {
                $command .= ' -re';
            }

            $command .= " -y -i '$movie_source'' -c:v libx264 -c:a aac -flags -global_header -strict -2";
            if ( isset( $subtitles_command ) )
            {
                $command .= $subtitles_command;
            }


            $command .= " -f mp4 '" . MOVIES_PATH . "{$movie_name_fixed}/$movie_name.mp4' > /dev/null 2>/dev/null && echo 2 > " . MOVIES_PATH . "{$movie_name_fixed}/completed.xtream) & echo $!";
            $fp = popen( $command, 'r' );
            $pid = intval( trim( fgets( $fp ) ) );
            pclose( $fp );
            $movie_file = $movie_name . '.mp4';
        }
        else
        {
            if ( $movie_location == 'local' )
            {
                @rename( $movie_source, MOVIES_PATH . $movie_name_fixed . '/' . basename( $movie_source ) );
                @file_put_contents( MOVIES_PATH . $movie_name_fixed . '/' . 'completed.xtream', 1 );
                $movie_file = basename( $movie_source );
            }
            else
            {

                $remote_movie_name = urldecode( basename( $movie_source ) );
                $pid = intval( trim( shell_exec( '(wget -qO "' . MOVIES_PATH . $movie_name_fixed . '/' . $remote_movie_name . '" ' . $movie_source . ' && echo 2 > ' . MOVIES_PATH . $movie_name_fixed . '/' . 'completed.xtream) >/dev/null 2>/dev/null & echo $!' ) ) );
                $movie_file = $remote_movie_name;
            }

            $return = true;
        }


        if ( is_null( $category_id ) || ! RowExists( "stream_categories", "id", $category_id ) )
            self::$ipTV_db->query( "INSERT INTO `streams` (`type`,`stream_display_name`,`stream_source`,`pid`,`movie_file`) VALUES('movie','%s','%s','%d','%s')", $movie_name, $movie_source, $pid, $movie_file );
        else
            self::$ipTV_db->query( "INSERT INTO `streams` (`type`,`category_id`,`stream_display_name`,`stream_source`,`pid`,`movie_file`) VALUES('movie','%d','%s','%s','%d','%s')", $category_id, $movie_name, $movie_source, $pid, $movie_file );
        return true;
    }


    /**
     * Movie Start
     *
     * @param Movie Name, Movie_Subtitles
     * @return bool
     */

    static public function GetFixedStreamName( $stream_name )
    {
        return substr( md5( $stream_name . ipTV_lib::$settings['unique_id'] ), 0, 16 );
    }
}

?>
