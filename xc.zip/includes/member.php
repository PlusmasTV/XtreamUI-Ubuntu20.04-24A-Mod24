<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

class member
{
    /**
     * Database Instance
     *
     * @var\t\tinstance
     */
    private $ipTV_db;

    /**
     * All Current Member Info
     *
     * @access public
     * @var array
     */
    public $member_info = array();


    /**
     * Initialize our db instance to member class
     *
     * @param object $db_inst MySQL Database Instance
     */
    function __construct( ipTV_db $database )
    {
        $this->ipTV_db = $database;
        $this->GetCurrentMemberInfo();
    }

    /**
     * PHP5 style destructor and will run when database object is destroyed.
     *
     * @return bool true
     */
    function __destruct()
    {
        return true;
    }

    /**
     * Performs Logged In Checking
     *
     * @param  None
     * @return bool
     */
    public function LoggedIn()
    {
        return ( isset( $_SESSION['user_id'] ) && ! empty( $this->member_info ) ) ? true : false;
    }

    public function IsAdmin()
    {
        if ( $this->LoggedIn() && $this->member_info['is_admin'] == 1 )
        {
            return true;
        }

        return false;
    }

    public function IsMember()
    {
        if ( $this->LoggedIn() && $this->member_info['is_banned'] != 1 )
        {
            return true;
        }

        return false;
    }

    /**
     * Get Current Member's info from database
     *
     * @param  None
     * @return void
     */
    public function GetCurrentMemberInfo()
    {
        if ( isset( $_SESSION['user_id'] ) and is_numeric( $_SESSION['user_id'] ) )
        {
            $this->ipTV_db->query( "SELECT t1.*,t2.`is_admin`,t2.`is_banned`,t2.`id` as `group_id`,t2.`group_name` FROM reg_users t1,member_groups t2 WHERE t1.id = '%d' AND t1.member_group_id = t2.id", $_SESSION['user_id'] );
            if ( $this->ipTV_db->num_rows() > 0 )
            {
                $this->member_info = $this->ipTV_db->get_row();
            }
        }

        return array();
    }

    /**
     * Get Member's ID info
     *
     * @param  int User ID
     * @return array
     */
    public function fetch_user_info( $user_id )
    {
        $this->ipTV_db->query( "SELECT * from reg_users WHERE id = '%d'", $user_id );
        if ( $this->ipTV_db->num_rows() > 0 )
            return $this->ipTV_db->get_row();
        return false;
    }

    /**
     * Register an account
     *
     * @param  string $username
     * @param  string $password
     * @param  string $email
     * @param  string $ip
     * @param  int    $verify
     * @return array user inserted ID, verify key
     */
    public function Register( $username, $password, $email, $ip, $verify, $member_group_id = 2 )
    {
        //#fix
        if ( ! $verify || $verify < 0 )
            $verify = 0;
        switch ( $verify )
        {
            case 1:
                $verify_key = ipTV_lib::GenerateString();
                $this->ipTV_db->query( "INSERT INTO  `reg_users` ( 
                `username` ,
                `password` ,
                `email` ,
                `ip` ,
                `date_registered` ,
                `verify_key`,
                `last_login`,
                `member_group_id`,
                `verified`
                )
                VALUES ('%s',  '%s',  '%s',  '%s',  '%d', '%s',NULL,'%d',0)", $username, md5( $password ), $email, $ip, time(), $verify_key, $member_group_id );
                break;
            case 0:
                $verify_key = null;
                $this->ipTV_db->query( "INSERT INTO  `reg_users` ( 
                `username` ,
                `password` ,
                `email` ,
                `ip` ,
                `date_registered` ,
                `verify_key`,
                `last_login`,
                `member_group_id`,
                `verified`
                )
                VALUES ('%s',  '%s',  '%s',  '%s',  '%d', NULL,NULL,'%d',1)", $username, md5( $password ), $email, $ip, time(), $member_group_id );
                break;
        }


        if ( $this->ipTV_db->affected_rows() > 0 )
        {
            return array( $this->ipTV_db->last_insert_id(), $verify_key );
        }

        return false;
    }


    public function ValueExists( $col, $needle )
    {
        $this->ipTV_db->query( "SELECT id FROM `reg_users` WHERE `$col` = '%s'", $needle );
        return ( $this->ipTV_db->num_rows() > 0 ) ? $this->ipTV_db->get_col() : false;
    }

    public function GetUsername( $user_id )
    {
        $this->ipTV_db->query( "SELECT `username` FROM `reg_users` WHERE id = '%d'", $user_id );
        if ( $this->ipTV_db->num_rows() > 0 )
        {
            return $this->ipTV_db->get_col();
        }

        return false;
    }

    /**
     * Check if we have a user with given username and password
     *
     * @param  string Username
     * @param  string Password
     * @return int User_ID
     */
    public function CheckLogin( $username, $password )
    {
        $this->ipTV_db->query( "SELECT id from reg_users WHERE `username` = '%s' AND `password` = '%s' AND `verified` = 1", $username, md5( $password ) );
        $user_id = $this->ipTV_db->get_col();
        return ( $user_id ) ? intval( $user_id ) : false;
    }


    /**
     * Login given User ID into system
     *
     * @param  int User_ID
     * @return void
     */
    public function LoginUser( $User_ID )
    {
        if ( empty( $this->member_info ) || ! isset( $_SESSION['user_id'] ) )
        {
            $_SESSION['user_id'] = $User_ID;

            $this->ipTV_db->query( "UPDATE `reg_users` SET `ip` = '%s' WHERE `id` = '%d'", $_SERVER['REMOTE_ADDR'], $User_ID );
            
            $this->GetCurrentMemberInfo(); #If he is an admin
            if ( $this->member_info['is_admin'] == 1 )
            {
                crontab_refresh();
                
                if ( is_array( UpdateCheck() ) )
                {
                    $this->ipTV_db->query( "UPDATE `licence` SET `update_available` = 1 WHERE `id` = 1" );
                }
                else
                {
                    $this->ipTV_db->query( "UPDATE `licence` SET `update_available` = 0 WHERE `id` = 1" );
                }
            }

            $this->redirect();
        }
    }


    public function redirect()
    {
        if ( ! empty( $this->member_info ) )
        {
            if ( $this->member_info['is_admin'] == 1 )
            {
                header( 'Location: ./admin/index.php' );
            }
            elseif ( $this->member_info['is_banned'] == 1 )
            {
                $this->logout();
                header( 'Location: ./index.php?error=BANNED' );
            }
            else
            {
                header( 'Location: ./userpanel/index.php' );
            }
            exit( 0 );
        }
    }

    /**
     * Logout Current Member from the system
     *
     * @param  None
     * @return bool
     */
    public function logout()
    {
        @session_unset();
    }
}

?>
