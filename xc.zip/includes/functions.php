<?php

function getAdminSettings() {
    global $ipTV_db;
    $query = $ipTV_db->query( "SELECT `type`, `value` FROM `admin_settings`" );
    $rows = array();
    if ( $query->num_rows() > 0 ){
        $rows = $query->get_rows();
    }
	ipTV_lib::SaveLog('MySQL Query Failed [' . $query . ']: ' . mysqli_error($ipTV_db));
    return $rows;
}

function getSettings() {
    global $ipTV_db;
	$bouquets = array();
    $result = $ipTV_db->query("SELECT * FROM `settings` LIMIT 1");
    if ( $ipTV_db->num_rows() > 0 )
    {
        $bouquets = $ipTV_db->get_rows();
    }
    return $bouquets;
}

function GetMySQLTables()
{
    global $ipTV_db;

    $ipTV_db->query( 'SHOW TABLES' );
    $tables = ipTV_lib::array_values_recursive( $ipTV_db->get_rows() );

    return $tables;
}

function DumpQueries( $contents )
{
    $queries = array();

    if ( ! is_array( $contents ) )
        $contents = explode( "\
", $contents );

    foreach ( $contents as $sql_line )
    {
        $sql_line = trim( $sql_line );

        if ( $sql_line != "" && substr( $sql_line, 0, 2 ) != "--" )
        {
            $query .= $sql_line;
            if ( substr( rtrim( $query ), -1 ) == ';' )
            {
                $queries[] = $query;

                $query = "";
            }
        }
    }

    return $queries;
}

function logout()
{
    @session_unset();
    @session_destroy();
}

function GetVLCArguments()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT * FROM `vlc_arguments`" );
    $rows = array();

    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
    }

    return $rows;
}

function LineBelongsTo( $user_line, $member_id )
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT 1 FROM `users` WHERE `member_id` = '%d' AND `id` = '%d'", $member_id, $user_line );

    return $ipTV_db->num_rows() > 0;
}

function GetUserLines( $member_id )
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT t1.*, t2.`bouquet_name`, user_activity.stream_id, streams.stream_display_name as last_seen,(SELECT count(`user_activity`.`id`) FROM `user_activity` WHERE `user_activity`.`user_id` = t1.id AND ISNULL(`user_activity`.`date_end`)) active_connections
                        FROM `users` t1
                        LEFT JOIN `bouquets` t2
                         ON t1.`bouquet` = t2.`id`
                        LEFT JOIN (
                          SELECT user_id, MAX(id) AS maxid FROM user_activity GROUP BY user_id
                        ) mostrecent
                         ON t1.id= mostrecent.user_id
                        LEFT JOIN user_activity
                         ON t1.id= user_activity.user_id AND user_activity.id = mostrecent.maxid
                        LEFT JOIN streams
                         ON user_activity.stream_id = streams.id
                         WHERE t1.member_id = '%d'
                        ORDER BY t1.id DESC", $member_id );


    $lines = array();
    if ( $ipTV_db->num_rows() > 0 )
    {
        $lines = $ipTV_db->get_rows();
    }
    return $lines;
}

/**
 * Get File List
 * 
 * @param $path
 * @return array $output
 */
function getFileList( $path, $extensions = array() )
{
    $arrFiles = scandir( $path );
    $arrFileList = array();
    $intCount = count( $arrFiles );

    for ( $i = 0; $i < $intCount; $i++ )
    {
        if ( $arrFiles[$i] != "." && $arrFiles[$i] != ".." )
        {
            if ( is_dir( $path . "/" . $arrFiles[$i] ) )
            {
                $arrFileList = array_merge( $arrFileList, getFileList( $path . "/" . $arrFiles[$i], $extensions ) );
            }
            else
            {

                $extension = trim( strtolower( pathinfo( $path . "/" . $arrFiles[$i], PATHINFO_EXTENSION ) ) );
                if ( empty( $extensions ) || in_array( $extension, $extensions ) )
                    $arrFileList[] = $path . "/" . $arrFiles[$i];
            }
        }
    }
    return ( $arrFileList );
}


function GetCategories( $type = null )
{
    global $ipTV_db;

    $query = "SELECT t1.id, t1.category_name,t1.category_type,COUNT(t2.id) as total_movies
                        FROM `stream_categories` t1
                        LEFT JOIN `streams` t2 ON t2.category_id = t1.id";

    switch ( $type )
    {
        case null:
            break;

        case 'live':
            $query .= " WHERE t1.category_type = 'live'";
            break;

        case 'movie':
            $query .= " WHERE t1.category_type = 'movie'";
            break;
    }
    $query .= " GROUP BY t1.category_name,t1.category_type
                ORDER BY t1.id DESC";


    $ipTV_db->query( $query );


    return ( $ipTV_db->num_rows() > 0 ) ? $ipTV_db->get_rows() : array();
}

function GenerateUniqueCode()
{
    return substr( md5( ipTV_lib::$settings['site_url'] ), 0, 15 );
}

function StreamWorking( $stream_id )
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT 1 FROM `streams` WHERE `id` = '%d' AND `problem_status` = 0 AND `pid` IS NOT NULL", $stream_id );

    return $ipTV_db->num_rows() > 0;
}

function CronJobRunning( $CronJob )
{
    if ( file_exists( '/tmp/' . $CronJob . GenerateUniqueCode() ) )
    {
        $pid = intval( trim( file_get_contents( '/tmp/' . $CronJob . GenerateUniqueCode() ) ) );
        return ps_running( $pid );
    }

    return false;
}

function Is_Running( $file_name )
{
    // Check if I'm already running and kill myself off if I am
    $pid_running = false;
    if ( file_exists( $file_name ) )
    {
        $data = file( $file_name );
        foreach ( $data as $pid )
        {
            $pid = ( int )$pid;
            if ( $pid > 0 && file_exists( '/proc/' . $pid ) )
            {
                $pid_running = $pid;
                break;
            }
        }
    }
    if ( $pid_running && $pid_running != getmypid() )
    {
        if ( file_exists( $file_name ) )
        {
            file_put_contents( $file_name, $pid );
        }
        return true;
    }
    else
    {
        file_put_contents( $file_name, getmypid() );
        return false;
    }
}

function ps_running( $pid )
{
    if ( empty( $pid ) )
    {
        return false;
    }

    return file_exists( "/proc/$pid" );
}


function GetConnections( $end = null, $limit = false, $from = 0, $to = 0 )
{
    global $ipTV_db;

    switch ( $end )
    {

        case 'open':
            $query = "SELECT t1.*,t2.username as member_name,t3.stream_display_name FROM `user_activity` t1,`users` t2,`streams` t3 WHERE ISNULL(t1.`date_end`) AND t2.id = t1.user_id AND t3.id = t1.stream_id ORDER BY id DESC ";
            break;

        case 'closed':
            $query = "SELECT t1.*,t2.username as member_name,t3.stream_display_name FROM `user_activity` t1,`users` t2,`streams` t3 WHERE t1.date_end IS NOT NULL AND t2.id = t1.user_id AND t3.id = t1.stream_id ORDER BY id DESC ";
            break;

        default:
            $query = "SELECT t1.*,t2.username as member_name,t3.stream_display_name,IF(t1.`date_end` IS NULL, 0, 1) AS status FROM `user_activity` t1,`users` t2,`streams` t3 WHERE t2.id = t1.user_id AND t3.id = t1.stream_id ORDER BY status ASC,id DESC ";
    }

    if ( $limit === true )
    {
        $query .= "LIMIT $from,$to";
    }

    $ipTV_db->query( $query );

    $activities = array();
    if ( $ipTV_db->num_rows() > 0 )
    {
        $activities = $ipTV_db->get_rows();
    }
    return $activities;
}

/** Download & Apply Update
 *
 * @param  none
 * @return bool
 */
function DownloadUpdate()
{
    global $ipTV_db;

    $licence_key = ipTV_lib::GetLicence();

    if ( empty( $licence_key ) )
    {
        return false;
    }

    $current_time = time();
    $random_number = rand( 1000, 90000 );


    $sendata = array(
        'current_time' => $current_time,
        'random_number' => $random_number,
        'software_version' => SCRIPT_VERSION,
        'software_key' => SOFTWARE,
        'domain_name' => ipTV_lib::$settings['site_url'],
        'copyrights_removed' => ipTV_lib::$settings['copyrights_removed'],
        'licence_key' => $licence_key );

    $postdata = http_build_query( $sendata );

    $opts = array( 'http' => array(
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => $postdata ) );

    $context = stream_context_create( $opts );

    $source = file_get_contents( "http://xtream-codes.com/licences/download_update.php", false, $context );

    $temp_dir = str_replace( "\\\\", "/", sys_get_temp_dir() );
    if ( substr( $temp_dir, -1 ) != '/' )
    {
        $temp_dir .= '/';
    }

    $file = $temp_dir . 'iptv_latest.zip'; #downloadFile( $url, $file );

    if ( ! empty( $source ) )
    {
        $temp_dir = str_replace( "\\\\", "/", sys_get_temp_dir() );
        if ( substr( $temp_dir, -1 ) != '/' )
            $temp_dir .= '/';

        $handle = fopen( $file, "w" );
        fwrite( $handle, $source );
        fclose( $handle );
        if ( class_exists( 'ZipArchive' ) )
        {
            $zip = new ZipArchive;
            if ( $zip->open( $file ) === true )
            {
                $zip->extractTo( IPTV_ROOT_PATH );
                $zip->close();
                if ( file_exists( IPTV_ROOT_PATH . 'sql_update.php' ) )
                {
                    //we have sql queries to run
                    require ( IPTV_ROOT_PATH . 'sql_update.php' );
                    if ( ! empty( $_QUERIES ) )
                    {
                        //find our version
                        foreach ( $_QUERIES as $version => $queries )
                        {
                            if ( version_compare( SCRIPT_VERSION, $version ) < 0 )
                            {
                                if ( is_array( $queries ) )
                                {
                                    foreach ( $queries as $query )
                                    {
                                        $ipTV_db->query( $query );
                                    }
                                }
                                else
                                {
                                    $ipTV_db->query( $queries );
                                }
                            }

                        }
                    }
                    @unlink( $file );
                }
                return true;
            }
        }
    }

    return false;
}


/** Check ipTV Licence
 *
 * @param  none
 * @return bool
 */
function CheckLicence()
{
    global $ipTV_db;

    $licence_key = ipTV_lib::GetLicence();

    if ( empty( $licence_key ) )
    {
        return false;
    }

    $current_time = time();
    $random_number = rand( 1000, 90000 );

    $sendata = array(
        'current_time' => $current_time,
        'random_number' => $random_number,
        'software_version' => SCRIPT_VERSION,
        'software_key' => SOFTWARE,
        'domain_name' => ipTV_lib::$settings['site_url'],
        'copyrights_removed' => ipTV_lib::$settings['copyrights_removed'],
        'licence_key' => $licence_key );

    $postdata = http_build_query( $sendata );

    $opts = array( 'http' => array(
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => $postdata ) );

    $context = stream_context_create( $opts );

    $licence_check = trim( file_get_contents( "http://xtream-codes.com/licences/licence.php", false, $context ) );

    if ( ! empty( $licence_check ) )
    {
        $encoded_string = unserialize( decode( $licence_check ) );

        if ( is_array( $encoded_string ) )
        {
            foreach ( $sendata as $key => $value )
            {
                if ( ! array_key_exists( $key, $encoded_string ) || $encoded_string[$key] != $value )
                {
                    $ipTV_db->query( "UPDATE `licence` SET `show_message` = 1 WHERE `id` = 1" );
                    return false;
                }
            }

            $ipTV_db->query( "UPDATE `licence` SET `show_message` = 0 WHERE `id` = 1" );
            return true;
        }
    }

    $ipTV_db->query( "UPDATE `licence` SET `show_message` = 1 WHERE `id` = 1" );
    return false;
}

function secondsToTime( $inputSeconds )
{

    $secondsInAMinute = 60;
    $secondsInAnHour = 60 * $secondsInAMinute;
    $secondsInADay = 24 * $secondsInAnHour;

    // extract days
    $days = ( int )floor( $inputSeconds / $secondsInADay );

    // extract hours
    $hourSeconds = $inputSeconds % $secondsInADay;
    $hours = ( int )floor( $hourSeconds / $secondsInAnHour );

    // extract minutes
    $minuteSeconds = $hourSeconds % $secondsInAnHour;
    $minutes = ( int )floor( $minuteSeconds / $secondsInAMinute );

    // extract the remaining seconds
    $remainingSeconds = $minuteSeconds % $secondsInAMinute;
    $seconds = ( int )ceil( $remainingSeconds );

    // return the final array
    $final = "$days days, $hours hours, $minutes minutes, $seconds seconds";

    return $final;
}

function get_boottime()
{
    if ( file_exists( '/proc/uptime' ) and is_readable( '/proc/uptime' ) )
    {
        $tmp = explode( ' ', file_get_contents( '/proc/uptime' ) );

        return secondsToTime( intval( $tmp[0] ) );
    }
}


function kick_user( $user_id )
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT `id` FROM `user_activity` WHERE `user_id` = '%d' AND ISNULL(`date_end`)", $user_id );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
        foreach ( $rows as $row )
        {
            kick_activity( $row['id'] );
        }
    }
}

function GetRegUsers()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT t1.*,t3.group_name,t3.group_color,COUNT(DISTINCT t2.`id`) as total_lines
                        FROM `reg_users` as t1
                        LEFT JOIN `users` as t2
                            ON t1.id = t2.member_id
                        LEFT JOIN `member_groups` t3
                            ON t1.member_group_id = t3.id
                        GROUP BY t1.id,t3.group_name,t3.group_color
                        ORDER BY t1.id DESC
                        " );
    $rows = array();

    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
    }

    return $rows;
}

function GetMemberGroups()
{
    global $ipTV_db;

    $ipTV_db->query( "
            SELECT t1.*,COUNT(DISTINCT t2.id) as total_users
            FROM `member_groups` t1
            LEFT JOIN `reg_users` t2
                ON t2.member_group_id = t1.id
            GROUP BY t1.id
            ORDER BY t1.id ASC
            " );
    $rows = array();

    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
    }

    return $rows;
}

function GetOutputFormats()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT * FROM `stream_output`" );
    $rows = array();

    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
    }

    return $rows;
}

function GetTranscodes( $output_format = null )
{
    global $ipTV_db;

    if ( is_null( $output_format ) )
    {
        $ipTV_db->query( "SELECT * FROM `streams_transcodes`" );
    }
    else
    {
        $ipTV_db->query( "SELECT * FROM `streams_transcodes` WHERE `output_format` = '%d'", $output_format );
    }

    $rows = array();

    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
    }

    return $rows;
}
function kill_all_activities()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT `id` FROM `user_activity` WHERE ISNULL(`date_end`)" );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $activities = $ipTV_db->get_rows();

        foreach ( $activities as $info )
        {
            kick_activity( $info['id'] );
        }
    }

    return true;
}

function kick_activity( $activity_id )
{
    global $ipTV_db;


    $ipTV_db->query( "SELECT * FROM `user_activity` WHERE `id` = '%d'", $activity_id );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $activity_info = $ipTV_db->get_row();

        if ( ! is_null( $activity_info['pid'] ) )
        {
            if ( ps_running( $activity_info['pid'] ) )
            {
                if ( posix_kill( $activity_info['pid'], 9 ) )
                {
                    $ipTV_db->query( "UPDATE `user_activity` SET `date_end` = '%d',`pid` = NULL WHERE `id` = '%d'", time(), $activity_id );
                }
                else
                {
                    return posix_strerror( posix_get_last_error() );
                }
            }
            else
            {
                $ipTV_db->query( "UPDATE `user_activity` SET `date_end` = '%d',`pid` = NULL WHERE `id` = '%d'", time(), $activity_id );
            }
        }
    }
    return true;
}

function decode( $string )
{
    $parts = explode( ":", $string );

    $length_key = count( $parts );
    $key = '';
    for ( $i = 1; $i < $length_key; $i++ )
    {
        $key .= substr( $parts[$i], 0, 1 );

    }

    $chars = str_split( $key );

    $junk_length_chars = substr( $string, 0, 1 );
    $junk_length_chars .= substr( $string, -1 );
    $string = substr( $string, 1 );
    $string = substr( $string, 0, -1 );

    preg_match_all( "/[0-9a-zA-Z]{{$junk_length_chars}}\\:./", $string, $matches );

    $string = str_replace( $matches[0], array(), $string );

    $data = str_replace( array( '-', '_' ), array( '+', '/' ), $string );
    $mod4 = strlen( $data ) % 4;
    if ( $mod4 )
    {
        $data .= substr( '====', $mod4 );
    }

    $crypttext = base64_decode( $data );
    $iv_size = mcrypt_get_iv_size( MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB );
    $iv = mcrypt_create_iv( $iv_size, MCRYPT_RAND );
    $decrypttext = mcrypt_decrypt( MCRYPT_RIJNDAEL_256, $key, $crypttext, MCRYPT_MODE_ECB, $iv );

    return $decrypttext;
}


/**
 * Crontab Manager, ADD/EDIT cronjob
 * 
 * @param none
 * @return void
 */
function crontab_refresh()
{
    global $ipTV_db;

    if ( ! function_exists( 'shell_exec' ) )
    {
        return false;
    }

    $ipTV_db->query( "SELECT * FROM `cronjobs` WHERE `enabled` = 1" );

    $rows = $ipTV_db->get_rows();

    $jobs = array();
    $php_bin = sys_var( 'PHP_BIN' );
    foreach ( $rows as $cronjob )
    {
        //Protect from command execution
        if ( ! is_file( IPTV_ROOT_PATH . $cronjob['filename'] ) )
        {
            continue;
        }

        $cronjob['run_per_mins'] = intval( $cronjob['run_per_mins'] );
        $full_path = IPTV_ROOT_PATH . $cronjob['filename'];
        $jobs[] = "*/{$cronjob['run_per_mins']} * * * * $php_bin " . $full_path . " # Xtream-Codes IPTV Panel";
    }

    $crontab = trim( shell_exec( "crontab -l" ) );
    if ( ! empty( $crontab ) )
    {

        $lines = explode( "\
", $crontab );
        $lines = array_map( "trim", $lines );
        $counter = count( $lines );

        for ( $i = 0; $i < $counter; $i++ )
        {
            if ( stripos( $lines[$i], IPTV_ROOT_PATH ) )
            {
                unset( $lines[$i] );
            }
        }

        foreach ( $jobs as $job )
        {
            array_push( $lines, $job );
        }

    }
    else
    {
        $lines = $jobs;
    }

    shell_exec( "crontab -r" );
    #make temporary file
    $tmpfname = tempnam( "/tmp", "crontab" );
    $handle = fopen( $tmpfname, "w" );
    fwrite( $handle, implode( "\\
", $lines ) . "\\
" );
    fclose( $handle );

    shell_exec( "crontab $tmpfname" );
    @unlink( $tmpfname );

}

function sys_var( $var )
{
    $output = "";
    switch ( $var )
    {
        case "PHP_BIN":
            if ( defined( 'PHP_BINDIR' ) )
            {
                $output = PHP_BINDIR . '/php';
            }
            elseif ( isset( $_SERVER['PATH'] ) )
            {
                $paths = explode( ":", $_SERVER['PATH'] );
                $paths = array_map( "trim", $paths );

                foreach ( $paths as $path )
                {
                    if ( file_exists( $path . '/php' ) && is_file( $path . '/php' ) )
                    {
                        $output = $path . '/php';
                        break;
                    }
                }
            }
            elseif ( function_exists( 'shell_exec' ) )
            {
                $php_bin = trim( shell_exec( "which php" ) );
                if ( empty( $php_bin ) )
                {
                    $whereis_php = trim( shell_exec( "whereis php" ) );
                    $d = explode( " ", $whereis_php );
                    if ( count( $d ) == 1 )
                    {
                        return false;
                    }
                    else
                    {
                        $php_bin = $d[1];
                    }
                }
                $output = $php_bin;
            }
            break;

    }

    return $output;
}
function GetMuxes()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT * FROM `stream_mux`" );
    $rows = array();

    if ( $ipTV_db->num_rows() > 0 )
    {
        $rows = $ipTV_db->get_rows();
    }

    return $rows;
}

/**
 * Check If Row exists in database
 * 
 * @param string $table
 * @param string $search_by
 * @param string $needle
 * @return bool
 */
function RowExists( $table, $search_by, $needle )
{
    global $ipTV_db;
    $ipTV_db->query( "SELECT * FROM `$table` WHERE `$search_by` = '%s'", $needle );
    if ( $ipTV_db->num_rows() > 0 )
    {
        return true;
    }

    return false;
}


function generateRandomString( $length = 8 )
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ( $i = 0; $i < $length; $i++ )
    {
        $randomString .= $characters[rand( 0, strlen( $characters ) - 1 )];
    }
    return $randomString;
}

function TopProcesses( $limit )
{
    $command = trim( shell_exec( "ps -auxc --sort=-pcpu | head -$limit" ) );
    $command = explode( "\
", $command );

    $columns = $command[0];
    $columns = explode( " ", $columns );
    $columns = array_values( array_filter( array_map( "trim", $columns ), 'strlen' ) );

    $output = "<table class='tablesorter' cellspacing='0'><thead><tr>";
    foreach ( $columns as $column )
    {
        $output .= "<td>" . $column . "</td>";
    }

    $output .= "</tr></thead><tbody>";
    array_shift( $command );
    if ( count( $command ) > 0 )
    {
        foreach ( $command as $ps )
        {
            $ps = explode( " ", $ps );
            $ps = array_values( array_filter( array_map( "trim", $ps ), 'strlen' ) );

            $output .= "<tr>";
            foreach ( $ps as $pcolumn )
            {
                $output .= "<td>" . $pcolumn . "</td>";
            }
            $output .= "</tr>";
        }
    }

    $output .= "</tbody></table>";

    return $output;
}
function memory_usage()
{
    $memory_usage = trim( shell_exec( "free -m" ) );
    if ( empty( $memory_usage ) )
    {
        return false;
    }

    $data = explode( "\
", $memory_usage );

    $memory_usage = array();
    $swap_usage = array();
    foreach ( $data as $line )
    {
        $output = preg_replace( '!\\s+!', ' ', str_replace( ":", "", $line ) );
        if ( ! strstr( $output, "Mem" ) and ! strstr( $output, "Swap" ) )
        {
            continue;
        }

        $info = explode( " ", $output );

        if ( $info[0] == "Mem" )
        {

            $memory_usage['total'] = $info[1];
            $memory_usage['used'] = $info[2] - $info[6];
            if ( $memory_usage['used'] < 0 )
                $memory_usage['used'] = $info[2];
            $memory_usage['free'] = $info[3];
            $memory_usage['percent'] = sprintf( "%0.2f", ( $memory_usage['used'] / $memory_usage['total'] ) * 100 );
        }
        else
        {
            $swap_usage['total'] = $info[1];
            $swap_usage['used'] = $info[2];
            $swap_usage['free'] = $info[3];
            $swap_usage['percent'] = sprintf( "%0.2f", ( $info[2] / $info[1] ) * 100 );
        }
    }

    return array( $memory_usage, $swap_usage );
}


function GetTotalCPUsage()
{
    $idle_old = 0;
    $total_old = 0;

    for ( $i = 0; $i < 2; $i++ )
    {
        $stats = @file_get_contents( "/proc/stat" );
        if ( empty( $stats ) )
        {
            return false;
        }

        $data = explode( "\
", $stats );
        foreach ( $data as $line )
        {
            if ( ! preg_match( "/cpu\\s/", $line ) )
            {
                continue;
            }

            $core_data = explode( " ", trim( $line ) );
            array_shift( $core_data );
            $core_data[0] = trim( $core_data[0] );
            if ( empty( $core_data[0] ) )
            {
                array_shift( $core_data );
            }

            $total = array_sum( $core_data );
            $idle = $core_data[3];
            $del_idle = $idle - $idle_old;
            $del_total = $total - $total_old;
            $total_usage = 100 * ( ( $del_total - $del_idle ) / $del_total );
            ;
            $idle_old = $idle;
            $total_old = $total;

        }
        if ( $i == 0 )
            sleep( 1 );
    }

    return $total_usage;
}
function cpuinfo()
{

    $file = @file_get_contents( "/proc/cpuinfo" );

    if ( empty( $file ) )
    {
        return false;
    }

    $data = explode( "\
", $file );
    $cpuinfo = array();
    foreach ( $data as $line )
    {
        if ( ! stristr( $line, ":" ) )
        {
            continue;
        }
        list( $key, $val ) = @explode( ":", $line );
        $cpuinfo[trim( $key )] = trim( $val );
    }

    $cpus = array();
    for ( $i = 0; $i <= $cpuinfo['processor']; $i++ )
    {
        $cpus['cores'][$i]['cpu_name'] = $cpuinfo['model name'];
        $cpus['cores'][$i]['speed'] = $cpuinfo['cpu MHz'];
    }

    $idle_old = array_fill( 0, ++$cpuinfo['processor'], 0 );
    $total_old = array_fill( 0, $cpuinfo['processor'], 0 );


    for ( $i = 0; $i < 3; $i++ )
    {
        $stats = @file_get_contents( "/proc/stat" );

        if ( empty( $stats ) )
        {
            return false;
        }

        $data = explode( "\
", $stats );
        $count = 0;
        $total_usage = 0;
        foreach ( $data as $line )
        {
            if ( ! preg_match( "/cpu[0-9]{1,}\\s/", $line ) )
            {
                continue;
            }

            $core_data = explode( " ", trim( $line ) );
            array_shift( $core_data );
            $total = array_sum( $core_data );
            $idle = $core_data[3];

            $del_idle = $idle - $idle_old[$count];
            $del_total = $total - $total_old[$count];

            $this_cpu_usage = 100 * ( ( $del_total - $del_idle ) / $del_total );
            $total_usage = $total_usage + $this_cpu_usage;

            $cpus['cores'][$count]['cpu_usage'] = sprintf( "%0.2f", $this_cpu_usage );

            $idle_old[$count] = $idle;
            $total_old[$count] = $total;

            $count++;

        }
        $total_cpu_usage = sprintf( "%0.2f", $total_usage / count( $cpus ) );
        $cpus['total_usage'] = $total_cpu_usage;
        sleep( 1 );
    }

    return $cpus;
}

function get_current_online_users()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT count(`id`) FROM `users` WHERE `online` = 1" );

    return $ipTV_db->get_col();
}

function GetTotalConnections( $type )
{
    global $ipTV_db;

    switch ( $type )
    {

        case "open":
            $ipTV_db->query( "SELECT count(`id`) FROM `user_activity` WHERE ISNULL(`date_end`)" );
            break;

        case "total_slots":
            $ipTV_db->query( "SELECT SUM(max_connections) FROM `users` WHERE  `exp_date` > " . time() . "" );
            break;
    }
    return $ipTV_db->get_col();
}

/** Check Update Of MultiCS_Panel
 *
 * @param  none
 * @return bool / array
 */
function UpdateCheck( $from_cache = false )
{
    global $ipTV_db;
    if ( @$from_cache )
    {
        $ipTV_db->query( "SELECT `update_available` FROM `licence` WHERE `id` = 1" );
        $value = intval( $ipTV_db->get_col() );
        return ( $value > 0 ) ? true : false;
    }

    $update_check = simplexml_load_file( "http://xtream-codes.com/licences/check_update.php?version=" . SCRIPT_VERSION . "&software_key=" . SOFTWARE );
    $output = array();
    if ( $update_check->request == "true" )
    {
        if ( $update_check->latest == "true" )
        {
            return true;
        }
        else
        {

            $output['latest_version'] = ( string )$update_check->latest_version;
            foreach ( $update_check->version_changelog as $cl )
            {
                $info = ( array )$cl;
                $output['change_log'][$info['version']] = array( $info['change_log'], @$info['description'] );
            }


            return $output;
        }
    }

    return false;
}


/**
 * Shows a message. There are 3 different types of message. warning, ok , and error.
 *
 * @param string $type Type of the error we want to show
 * @param string $message
 * @return string [ HTML Styled ]
 */
function show_message( $type = 'ok', $message )
{

    switch ( $type )
    {
        case "error":
            $class = 'alert_error';
            break;
        case "warning":
            $class = 'alert_warning';
            break;
        case "ok":
            $class = 'alert_success';
            break;
        default:
            $class = 'alert_info';
    }

    $output = "";
    if ( is_array( $message ) )
    {
        foreach ( $message as $msg )
        {
            $output .= '<h4 class="' . $class . '"> ' . $msg . '</h4>';
        }
    }
    else
    {
        $output .= '<h4 class="' . $class . '">' . $message . '</h4>';
    }

    return $output;

}


function GenerateScript( $user_id, $type, $force_download = false )
{
    if ( ! RowExists( "users", "id", $user_id ) )
    {
        return false;
    }

    $user_info = GetUserInfo( $user_id );
    $data = "";
    switch ( $type )
    {
        case "enigma16":
            $file_name = "iptv.sh";
            $script = base64_decode( "VVNFUk5BTUU9IntVU0VSTkFNRX0iO1BBU1NXT1JEPSJ7UEFTU1dPUkR9Ijtib3VxdWV0PSJ7Qk9VUVVFVH0iO2RpcmVjdG9yeT0iL2V0Yy9lbmlnbWEyL2lwdHYuc2giO3VybD0ie1VSTH1nZXQucGhwP3VzZXJuYW1lPSRVU0VSTkFNRSZwYXNzd29yZD0kUEFTU1dPUkQmdHlwZT1lbmlnbWExNiI7cm0gL2V0Yy9lbmlnbWEyL3VzZXJib3VxdWV0LiIkYm91cXVldCJfX3R2Xy50djt3Z2V0IC1PIC9ldGMvZW5pZ21hMi91c2VyYm91cXVldC4iJGJvdXF1ZXQiX190dl8udHYgJHVybDtpZiAhIGNhdCAvZXRjL2VuaWdtYTIvYm91cXVldHMudHYgfCBncmVwIC12IGdyZXAgfCBncmVwIC1jICRib3VxdWV0ID4gL2Rldi9udWxsO3RoZW4gZWNobyAiWytdQ3JlYXRpbmcgRm9sZGVyIGZvciBpcHR2IGFuZCByZWhhc2hpbmcuLi4iO2NhdCAvZXRjL2VuaWdtYTIvYm91cXVldHMudHYgfCBzZWQgLW4gMXAgPiAvZXRjL2VuaWdtYTIvbmV3X2JvdXF1ZXRzLnR2O2VjaG8gJyNTRVJWSUNFIDE6NzoxOjA6MDowOjA6MDowOjA6RlJPTSBCT1VRVUVUICJ1c2VyYm91cXVldC4nJGJvdXF1ZXQnX190dl8udHYiIE9SREVSIEJZIGJvdXF1ZXQnID4+IC9ldGMvZW5pZ21hMi9uZXdfYm91cXVldHMudHY7IGNhdCAvZXRjL2VuaWdtYTIvYm91cXVldHMudHYgfCBzZWQgLW4gJzIsJHAnID4+IC9ldGMvZW5pZ21hMi9uZXdfYm91cXVldHMudHY7cm0gL2V0Yy9lbmlnbWEyL2JvdXF1ZXRzLnR2O212IC9ldGMvZW5pZ21hMi9uZXdfYm91cXVldHMudHYgL2V0Yy9lbmlnbWEyL2JvdXF1ZXRzLnR2O2ZpO3JtIC91c3IvYmluL2VuaWdtYTJfcHJlX3N0YXJ0LnNoO2VjaG8gIndyaXRpbmcgdG8gdGhlIGZpbGUuLiBOTyBORUVEIEZPUiBSRUJPT1QiO2VjaG8gIi9iaW4vc2ggIiRkaXJlY3RvcnkiID4gL2Rldi9udWxsIDI+JjEgJiIgPiAvdXNyL2Jpbi9lbmlnbWEyX3ByZV9zdGFydC5zaDtjaG1vZCA3NzcgL3Vzci9iaW4vZW5pZ21hMl9wcmVfc3RhcnQuc2g7d2dldCAtcU8gLSAiaHR0cDovLzEyNy4wLjAuMS93ZWIvc2VydmljZWxpc3RyZWxvYWQ/bW9kZT0yIjt3Z2V0IC1xTyAtICJodHRwOi8vMTI3LjAuMC4xL3dlYi9zZXJ2aWNlbGlzdHJlbG9hZD9tb2RlPTIiOw==" );

            $data .= str_replace( array(
                "{USERNAME}",
                "{PASSWORD}",
                "{BOUQUET}",
                "{URL}" ), array(
                $user_info['username'],
                $user_info['password'],
                ipTV_lib::$settings['bouquet_name'],
                "http://" . ipTV_lib::$settings['site_url'] . "/" ), $script );

            break;

        case "dreambox":
            $file_name = "iptv.sh";
            $script = base64_decode( "VVNFUk5BTUU9IntVU0VSTkFNRX0iO1BBU1NXT1JEPSJ7UEFTU1dPUkR9Ijtib3VxdWV0PSJ7Qk9VUVVFVH0iO2RpcmVjdG9yeT0iL2V0Yy9lbmlnbWEyL2lwdHYuc2giO3VybD0ie1VSTH1nZXQucGhwP3VzZXJuYW1lPSRVU0VSTkFNRSZwYXNzd29yZD0kUEFTU1dPUkQmdHlwZT1kcmVhbWJveCI7cm0gL2V0Yy9lbmlnbWEyL3VzZXJib3VxdWV0LiIkYm91cXVldCJfX3R2Xy50djt3Z2V0IC1PIC9ldGMvZW5pZ21hMi91c2VyYm91cXVldC4iJGJvdXF1ZXQiX190dl8udHYgJHVybDtpZiAhIGNhdCAvZXRjL2VuaWdtYTIvYm91cXVldHMudHYgfCBncmVwIC12IGdyZXAgfCBncmVwIC1jICRib3VxdWV0ID4gL2Rldi9udWxsO3RoZW4gZWNobyAiWytdQ3JlYXRpbmcgRm9sZGVyIGZvciBpcHR2IGFuZCByZWhhc2hpbmcuLi4iO2NhdCAvZXRjL2VuaWdtYTIvYm91cXVldHMudHYgfCBzZWQgLW4gMXAgPiAvZXRjL2VuaWdtYTIvbmV3X2JvdXF1ZXRzLnR2O2VjaG8gJyNTRVJWSUNFIDE6NzoxOjA6MDowOjA6MDowOjA6RlJPTSBCT1VRVUVUICJ1c2VyYm91cXVldC4nJGJvdXF1ZXQnX190dl8udHYiIE9SREVSIEJZIGJvdXF1ZXQnID4+IC9ldGMvZW5pZ21hMi9uZXdfYm91cXVldHMudHY7IGNhdCAvZXRjL2VuaWdtYTIvYm91cXVldHMudHYgfCBzZWQgLW4gJzIsJHAnID4+IC9ldGMvZW5pZ21hMi9uZXdfYm91cXVldHMudHY7cm0gL2V0Yy9lbmlnbWEyL2JvdXF1ZXRzLnR2O212IC9ldGMvZW5pZ21hMi9uZXdfYm91cXVldHMudHYgL2V0Yy9lbmlnbWEyL2JvdXF1ZXRzLnR2O2ZpO3JtIC91c3IvYmluL2VuaWdtYTJfcHJlX3N0YXJ0LnNoO2VjaG8gIndyaXRpbmcgdG8gdGhlIGZpbGUuLiBOTyBORUVEIEZPUiBSRUJPT1QiO2VjaG8gIi9iaW4vc2ggIiRkaXJlY3RvcnkiID4gL2Rldi9udWxsIDI+JjEgJiIgPiAvdXNyL2Jpbi9lbmlnbWEyX3ByZV9zdGFydC5zaDtjaG1vZCA3NzcgL3Vzci9iaW4vZW5pZ21hMl9wcmVfc3RhcnQuc2g7d2dldCAtcU8gLSAiaHR0cDovLzEyNy4wLjAuMS93ZWIvc2VydmljZWxpc3RyZWxvYWQ/bW9kZT0yIjt3Z2V0IC1xTyAtICJodHRwOi8vMTI3LjAuMC4xL3dlYi9zZXJ2aWNlbGlzdHJlbG9hZD9tb2RlPTIiOw==" );

            $data .= str_replace( array(
                "{USERNAME}",
                "{PASSWORD}",
                "{BOUQUET}",
                "{URL}" ), array(
                $user_info['username'],
                $user_info['password'],
                ipTV_lib::$settings['bouquet_name'],
                "http://" . ipTV_lib::$settings['site_url'] . "/" ), $script );

            break;
    }

    if ( $force_download === true )
    {
        header( "Content-Type: text/plain" );
        header( 'Content-Disposition: attachment; filename="' . $file_name . '"' );
        header( "Content-Length: " . strlen( $data ) );
        echo $data;
        exit;
    }

    return $data;
}

function GenerateList( $user_id, $type, $force_download = false )
{
    if ( ! RowExists( "users", "id", $user_id ) )
    {
        return false;
    }

    $user_info = GetUserInfo( $user_id );
    $bouquet_info = GetBouquetInfo( $user_info['bouquet'] );
    $streams = $bouquet_info['streams'];

    $streaming_url = $movies_url = ipTV_lib::$settings['site_url'];

    if ( stristr( ipTV_lib::$settings['site_url'], ':' ) )
    {
        list( $movies_url, $port ) = explode( ':', ipTV_lib::$settings['site_url'] );
    }

    $data = "";
    switch ( $type )
    {

        case "simple":
            $file_name = "simple_{$user_info['username']}.txt";
            foreach ( $streams as $stream_id => $stream_info )
            {
                if ( $stream_info['type'] == 'live' )
                    $data .= "http://" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch #Channel: " . $stream_info['stream_display_name'] . "
";
                else
                    $data .= "http://" . $movies_url . ":88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch #Movie: " . $stream_info['stream_display_name'] . "
";
            }
            break;

        case "gigablue":
            $streaming_url = str_replace( ":", "%3a", $streaming_url );
            $file_name = "userbouquet.favourites.tv";
            $data = "#NAME" . " " . ipTV_lib::$settings['bouquet_name'] . "
";
            foreach ( $streams as $stream_id => $stream_info )
            {
                if ( $stream_info['type'] == 'live' )
                    $data .= "#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a//" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
                else
                    $data .= "#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a//" . $movies_url . "%3a88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";

                $data .= "#DESCRIPTION " . $stream_info['stream_display_name'] . "
";
            }
            break;

        case "enigma16":
            $streaming_url = str_replace( ":", "%3a", $streaming_url );
            $file_name = "userbouquet.favourites.tv";
            $data = "#NAME" . " " . ipTV_lib::$settings['bouquet_name'] . "
";
            foreach ( $streams as $stream_id => $stream_info )
            {
                if ( $stream_info['type'] == 'live' )
                    $data .= "#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a//" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
                else
                    $data .= "#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a//" . $movies_url . "%3a88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
                $data .= "#DESCRIPTION " . $stream_info['stream_display_name'] . "
";
            }
            break;


        case "octagon":
            $file_name = "octagon.txt";
            foreach ( $streams as $stream_id => $stream_info )
            {
                if ( $stream_info['type'] == 'live' )
                    $data .= "[TITLE]
{$stream_info['stream_display_name']}
[URL]
http://" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
[DESCRIPTION]
IPTV
[TYPE]
Live
";
                else
                    $data .= "[TITLE]
{$stream_info['stream_display_name']}
[URL]
http://" . $movies_url . ":88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
[DESCRIPTION]
IPTV
[TYPE]
Live
";

            }
            break;

        case "starlivev3":
            $file_name = "iptvlist.txt";
            foreach ( $streams as $stream_id => $stream_info )
            {
                $stream_name = str_replace( " ", "_", $stream_info['stream_display_name'] );
                if ( $stream_info['type'] == 'live' )
                    $data .= $stream_name . ",http://" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
                else
                    $data .= $stream_name . ",http://" . $movies_url . ":88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
            }
            break;

        case "starlivev5":
            $file_name = "channel.jason";
            $output_array = array();
            $output_array['iptvstreams_list'] = array();
            $output_array['iptvstreams_list']['@version'] = 1;
            $output_array['iptvstreams_list']['group'] = array();
            $output_array['iptvstreams_list']['group']['name'] = "IPTV";
            $output_array['iptvstreams_list']['group']['channel'] = array();
            foreach ( $streams as $stream_id => $stream_info )
            {
                $channel = array();
                $channel['name'] = $stream_info['stream_display_name'];
                $channel['icon'] = "";
                if ( $stream_info['type'] == 'live' )
                    $channel['stream_url'] = "http://" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch";
                else
                    $channel['stream_url'] = "http://" . $movies_url . ":88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch";
                $channel['stream_type'] = 0;

                $output_array['iptvstreams_list']['group']['channel'][] = $channel;
            }

            $data = json_encode( ( object )$output_array );
            break;

        case "mediastar":
            $file_name = "tvlist.txt";
            foreach ( $streams as $stream_id => $stream_info )
            {
                $stream_name = str_replace( " ", "_", $stream_info['stream_display_name'] );

                if ( $stream_info['type'] == 'live' )
                    $data .= $stream_name . " http://" .$streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch\\
";
                else
                    $data .= $stream_name . " http://" . $movies_url . ":88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch\\
";
            }
            break;

        case "dreambox":
            $streaming_url = str_replace( ":", "%3a", $streaming_url );
            $file_name = "userbouquet.favourites.tv";
            $data = "#NAME" . " " . ipTV_lib::$settings['bouquet_name'] . "
";
            foreach ( $streams as $stream_id => $stream_info )
            {
                if ( $stream_info['type'] == 'live' )
                    $data .= "#SERVICE 1:0:1:0:0:0:0:0:0:0:http%3a//" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
                else
                    $data .= "#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a//" . $movies_url . "%3a88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";

                $data .= "#DESCRIPTION " . $stream_info['stream_display_name'] . "
";
            }
            break;

        case "pcm3u":
            $file_name = "tv_channels_{$user_info['username']}.m3u";
            $data = "http://" . $streaming_url . "/get.php?username={$user_info['username']}&password={$user_info['password']}&type=m3u";
            break;

        default:
            $file_name = "tv_channels_{$user_info['username']}.m3u";
            $data = "#EXTM3U
";
            foreach ( $streams as $stream_id => $stream_info )
            {
                $data .= "#EXTINF:-1," . $stream_info['stream_display_name'] . "
";

                if ( $stream_info['type'] == 'live' )
                    $data .= "http://" . $streaming_url . "/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
                else
                    $data .= "http://" . $movies_url . ":88/{$user_info['username']}/{$user_info['password']}/{$stream_id}.ch
";
            }
    }

    if ( $force_download === true )
    {
        header( "Content-Type: text/plain" );
        header( 'Content-Disposition: attachment; filename="' . $file_name . '"' );
        header( "Content-Length: " . strlen( $data ) );
        echo $data;
        exit;
    }

    return $data;
}

function formatBytes( $bytes, $precision = 2 )
{
    $units = array(
        'B',
        'KB',
        'MB',
        'GB',
        'TB' );

    $bytes = max( $bytes, 0 );
    $pow = floor( ( $bytes ? log( $bytes ) : 0 ) / log( 1024 ) );
    $pow = min( $pow, count( $units ) - 1 );

    // Uncomment one of the following alternatives
    $bytes /= pow( 1024, $pow );
    // $bytes /= (1 << (10 * $pow));

    return round( $bytes, $precision ) . ' ' . $units[$pow];
}


function GetUsers( $show )
{
    global $ipTV_db;


    $users = array();
    $query = "SELECT t1.*,t3.username as owner, t2.`bouquet_name`, user_activity.stream_id, streams.stream_display_name as last_seen,(SELECT count(`user_activity`.`id`) FROM `user_activity` WHERE `user_activity`.`user_id` = t1.id AND ISNULL(`user_activity`.`date_end`)) active_connections
                        FROM `users` t1
                        LEFT JOIN `bouquets` t2
                         ON t1.`bouquet` = t2.`id`
                        LEFT JOIN (
                          SELECT user_id, MAX(id) AS maxid FROM user_activity GROUP BY user_id
                        ) mostrecent
                         ON t1.id= mostrecent.user_id
                        LEFT JOIN user_activity
                         ON t1.id= user_activity.user_id AND user_activity.id = mostrecent.maxid
                        LEFT JOIN streams
                         ON user_activity.stream_id = streams.id
                        LEFT JOIN reg_users t3
                         ON t1.member_id = t3.id                         
                        %REPLACE
                        ORDER BY t1.id DESC";


    switch ( $show )
    {
        case "show_all":
            $query = str_replace( "%REPLACE", "", $query );
            break;

        case "restreamers":
            $query = str_replace( "%REPLACE", "WHERE t1.`is_restreamer` = 1", $query );
            break;

        case "streamers":
            $query = str_replace( "%REPLACE", "WHERE t1.`is_restreamer` = 0", $query );
            break;
    }


    $ipTV_db->query( $query );
    $output = array();
    if ( $ipTV_db->num_rows() > 0 )
    {
        $output = $ipTV_db->get_rows();


    }

    return $output;
}


function GetCronjobs()
{
    global $ipTV_db;

    $cronjobs = array();
    $ipTV_db->query( "SELECT * FROM `cronjobs`" );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $cronjobs = $ipTV_db->get_rows();
    }

    return $cronjobs;
}

function GetStreams( $type = null, $order_by = 'id', $by = 'DESC' )
{
    global $ipTV_db;
    $streams = array();
    switch ( $type )
    {
        case null:
            $type_statement = '';
            break;
        case 'movie':
            $type_statement = "WHERE t1.type = 'movie'";
            break;
        default:
            $type_statement = "WHERE t1.type = 'live'";
    }

    $ipTV_db->query( "SELECT t1.*,t4.category_name, COUNT(DISTINCT t2.`id`) as total_online_clients,
                                         COUNT(DISTINCT t3.`id`) as total_logs
                       FROM `streams` t1
                       LEFT JOIN `user_activity` t2
                                ON t1.`id` = t2.`stream_id` AND ISNULL(t2.`date_end`)
                       LEFT JOIN `logs` t3
                                ON t3.`stream_id` = t1.`id` AND t3.status = 'Restart'
                       LEFT JOIN `stream_categories` t4
                                ON t4.`id` = t1.`category_id`                                 
                       $type_statement                                     
                       GROUP BY t1.id
                       ORDER BY t1.$order_by $by" );

    if ( $ipTV_db->num_rows() > 0 )
    {
        $streams = $ipTV_db->get_rows();
    }

    return $streams;
}

function TotalStreams()
{
    global $ipTV_db;

    $ipTV_db->query( "SELECT COUNT(`id`) FROM `streams`" );
    return $ipTV_db->get_col();
}

function GetLogs( $limit = false, $from, $to )
{
    global $ipTV_db;

    $logs = array();
    $query = "SELECT t1.*,t2.stream_display_name
              FROM `logs` t1
              INNER JOIN `streams` t2 
                ON t1.stream_id = t2.id 
              ORDER BY t1.id DESC ";

    if ( $limit === true )
    {
        $query .= "LIMIT $from,$to";
    }

    $ipTV_db->query( $query );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $logs = $ipTV_db->get_rows();
    }

    return $logs;
}

function GetBlockedUserAgents()
{
    global $ipTV_db;

    $user_agents = array();
    $ipTV_db->query( "SELECT * FROM `blocked_user_agents` ORDER BY id DESC" );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $user_agents = $ipTV_db->get_rows();
    }

    return $user_agents;
}

function GetBlockedIPs()
{
    global $ipTV_db;

    $blocked_ips = array();
    $ipTV_db->query( "SELECT * FROM `blocked_ips` ORDER BY id DESC" );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $blocked_ips = $ipTV_db->get_rows();
    }

    return $blocked_ips;
}


function GetBouquets()
{
    global $ipTV_db;

    $bouquets = array();
    $ipTV_db->query( "SELECT * FROM `bouquets` ORDER BY id DESC" );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $bouquets = $ipTV_db->get_rows();
    }

    return $bouquets;
}

function SetStreamStatus( $stream_id, $status )
{
    global $ipTV_db;

    $ipTV_db->query( "UPDATE `streams` set `status` = '%d' WHERE `id` = '%d'", $status, $stream_id );
    if ( $ipTV_db->affected_rows() > 0 )
    {
        return true;
    }
    return false;
}

function GetRegUserInfo( $user_id )
{
    global $ipTV_db;

    $row = array();
    $ipTV_db->query( "SELECT t1.* FROM `reg_users` t1,`member_groups` t2 WHERE t1.member_group_id = t2.id AND t1.`id` = '%d'", $user_id );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $row = $ipTV_db->get_row();
    }

    return $row;
}


/**
 * Send An E-mails
 * 
 * @param string $email
 * @param string subject 
 * @param string $content email content
 * @return bool
 */
function send_email( $to, $subject, $content )
{
    if ( ipTV_lib::$settings['use_remote_smtp'] == 0 )
    {
        //we will use server's smtp to send the e-mail

        $headers = 'MIME-Version: 1.0' . "\\
";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\\
";
        $headers .= 'From: ' . ipTV_lib::$settings['server_name'] . ' <' . ipTV_lib::$settings['email_from'] . '>' . "\\
";
        $headers .= 'X-Mailer: PHP/' . phpversion() . "\\
";
        if ( @mail( $to, $subject, $content, $headers ) )
        {
            return true;
        }
        return false;
    }
    else
    {
        require_once ( IPTV_INCLUDES_PATH . "class.phpmailer.php" );
        $mail = new PHPMailer();
        $mail->IsSMTP(); // telling the class to use SMTP

        $mail->SMTPAuth = true;
        $mail->SMTPSecure = ipTV_lib::$settings['smtp_encryption'];
        $mail->Host = ipTV_lib::$settings['smtp_host'];
        $mail->Port = intval( ipTV_lib::$settings['smtp_port'] );
        $mail->Username = ipTV_lib::$settings['smtp_username'];
        $mail->Password = ipTV_lib::$settings['smtp_password'];
        $mail->SetFrom( ipTV_lib::$settings['smtp_username'], ipTV_lib::$settings['smtp_from_name'] );
        $mail->AddAddress( $to );
        $mail->Subject = $subject;
        $mail->Body = $content;
        $mail->SMTPDebug = 0;
        $mail->WordWrap = 250;
        $mail->IsHTML( true );

        if ( $mail->Send() )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}


function GetUserInfo( $user_id )
{
    global $ipTV_db;

    $row = array();
    $ipTV_db->query( "SELECT * FROM `users` WHERE `id` = '%d'", $user_id );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $row = $ipTV_db->get_row();
    }

    return $row;
}


function GetBouquetInfo( $bouquet_id )
{
    global $ipTV_db;

    $rows = array();
    $ipTV_db->query( "SELECT * FROM `bouquets` WHERE `id` = '%d'", $bouquet_id );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $row = $ipTV_db->get_row();


        $rows['bouquet_name'] = $row['bouquet_name'];
        $rows['streams'] = array();
        $rows['id'] = $row['id'];
        $channels_array = unserialize( $row['bouquet_channels'] );
        $channels_array = array_map( "intval", $channels_array );
        $channels = array();
        if ( ! empty( $channels_array ) )
        {
            $ipTV_db->query( "SELECT * FROM `streams` WHERE `id` IN(" . implode( ",", $channels_array ) . ") ORDER BY FIELD(id, " . implode( ",", $channels_array ) . ");" );

            if ( $ipTV_db->num_rows() > 0 )
            {
                $streams = $ipTV_db->get_rows();
                foreach ( $streams as $stream )
                {
                    $rows['streams'][$stream['id']] = $stream;
                }
            }
        }
    }

    return $rows;
}

function GetStreamArguments( $stream_id )
{
    global $ipTV_db;
    $ipTV_db->query( "SELECT t1.argument_id,t1.value FROM `streams_options` t1,`vlc_arguments` t2 WHERE t1.stream_id = '%d' AND t1.argument_id = t2.id", $stream_id );
    $rows = array();
    if ( $ipTV_db->num_rows() > 0 )
    {
        $arguments = $ipTV_db->get_rows();

        foreach ( $arguments as $argument )
        {
            $rows[$argument['argument_id']] = $argument['value'];
        }
    }

    return $rows;
}

function GetStreamInfo( $stream_id )
{
    global $ipTV_db;

    $row = array();
    $ipTV_db->query( "SELECT * FROM `streams` WHERE `id` = '%d'", $stream_id );
    if ( $ipTV_db->num_rows() > 0 )
    {
        $row = $ipTV_db->get_row();
    }

    return $row;

}

function BouquetDel( $bouquet_id )
{
    global $ipTV_db;
    $ipTV_db->query( "DELETE FROM `bouquets` WHERE `id` = '%d'", $bouquet_id );

    if ( $ipTV_db->affected_rows() > 0 )
    {
        return true;
    }

    return false;
}

function DeleteStream( $stream_id )
{
    global $ipTV_db;

    if ( RowExists( "streams", "id", $stream_id ) )
    {
        $stream_info = GetStreamInfo( $stream_id );

        $stream_name = ipTV_Stream::GetFixedStreamName( $stream_info['stream_display_name'] );


        switch ( $stream_info['type'] )
        {
            case 'live':
                if ( ! is_null( $stream_info['pid'] ) && ps_running( $stream_info['pid'] ) )
                {
                    if ( ! posix_kill( $stream_info['pid'], 9 ) )
                    {
                        return false;
                    }
                }
                break;

            case 'movie':
                if ( ! is_null( $stream_info['pid'] ) && ps_running( $stream_info['pid'] ) )
                {
                    posix_kill( $stream_info['pid'], 9 );
                    posix_kill( $stream_info['pid'] + 1, 9 );
                }
                exec( "rm -rf " . MOVIES_PATH . $stream_name );

                break;
        }


        $ipTV_db->query( "DELETE FROM `logs` WHERE `stream_id` = '%d'", $stream_id );
        $ipTV_db->query( "DELETE FROM `user_activity` WHERE `stream_id` = '%d'", $stream_id );
        $ipTV_db->query( "DELETE FROM `streams` WHERE `id` = '%d'", $stream_id );

        return true;
    }

    return false;
}

function write( $dir, $data )
{
    $fp = fopen( $dir, "w" );
    fwrite( $fp, str_replace( "\\
", "\
", $data ) );
    fclose( $fp );
}

?>
