<?php

class ipTV_lib
{
    /**
     * Input parameters
     *
     * @var\t\tarray
     */
    static public $request = array();

    /**
     * Database Instance
     *
     * @var\t\tinstance
     */
    static public $ipTV_db;

    /**
     * Settings
     *
     * @var\t\tarray
     */
    static public $settings = array();

    /**
     * Settings for multiCS
     *
     * @var\t\tarray
     */
    static public $licence = "";


    /**
     * Contructor
     */
    static public function init()
    {
        #clean global vars
        if ( ! empty( $_GET ) )
            self::cleanGlobals( $_GET );
        if ( ! empty( $_POST ) )
            self::cleanGlobals( $_POST );
        if ( ! empty( $_SESSION ) )
            self::cleanGlobals( $_SESSION );
        if ( ! empty( $_COOKIE ) )
            self::cleanGlobals( $_COOKIE );

        # GET first
        $input = @ipTV_lib::parseIncomingRecursively( $_GET, array() );

        # Then overwrite with POST
        self::$request = @ipTV_lib::parseIncomingRecursively( $_POST, $input );

        #Get Settings
        ipTV_lib::GetSettings();

        ipTV_lib::GetLicence();


    }

    /**
     * Get All Settings
     *
     * @param\tNone
     */
    static public function GetSettings()
    {

        self::$ipTV_db->query( "SELECT * FROM `settings`" );
        $rows = self::$ipTV_db->get_row();

        foreach ( $rows as $key => $val )
        {

            self::$settings[$key] = $val;
        }

        //Fix bouquet
        if ( array_key_exists( 'bouquet_name', self::$settings ) )
        {
            self::$settings['bouquet_name'] = str_replace( " ", "_", self::$settings['bouquet_name'] );
        }
    }

    /**
     * nGinxConfigContain
     *
     * @param string $string
     * @return bool 
     */
    static public function nGinxConfigContain( $string )
    {
        if ( file_exists( "/etc/nginx/conf.d/default.conf" ) )
        {
            $source = file_get_contents( "/etc/nginx/conf.d/default.conf" );

            if ( stristr( $source, $string) )
            {
                return true;
            }
        }

        return false;
    }

    /**
     * phpFPMConfigContain
     *
     * @param string $string
     * @return bool 
     */
    static public function phpFPMConfigContain( $string )
    {
        $php_fpms = array( "/etc/php5/fpm/pool.d/www.conf", "/etc/php-fpm.d/www.conf" );

        foreach ( $php_fpms as $fpm )
        {
            if ( ! file_exists( $fpm ) )
            {
                continue;
            }

            $source = file_get_contents( $fpm );

            if ( stristr( $source, $string ) )
            {
                return true;
            }

        }
        
        return false;
    }
    
    /**
     * Get NEW Port
     *
     * @param none
     * @return int 
     */
    static public function GetNewPort()
    {
        $port = 0;
        $times = 0;
        do
        {

            if ( $time_in_loop - $time_now >= 10 )
            {
                break;
            }

            $temp_port = mt_rand( 20000, 30000 );

            if ( ! self::PortInUse( $temp_port ) )
            {
                $port = $temp_port;
            }

            ++$times;
        } while ( $port == 0 && $times < 100 );


        return ( $port != 0 ) ? $port : false;
    }

    static public function PortInUse( $port, $exclude = null )
    {
        $port_in_use = false;

        $socket = socket_create( AF_INET, SOCK_STREAM, 0 );
        $bind = socket_bind( $socket, "127.0.0.1", $port );
        if ( $bind === false )
        {
            $port_in_use = true;
        }

        @socket_close( $socket );

        //Check if port is in db
        if ( $port_in_use === true )
        {
            return true;
        }

        return self::PortUsedinDB( $port, $exclude );
    }

    static public function PortUsedinDB( $port, $exclude = null )
    {
        if ( $exclude != null )
        {
            self::$ipTV_db->query( "SELECT 1 FROM `streams` WHERE `dest_stream_port` = '%d' AND `id` <> '%d' ", $port, $exclude );
        }
        else
            self::$ipTV_db->query( "SELECT 1 FROM `streams` WHERE `dest_stream_port` = '%d'", $port );

        if ( self::$ipTV_db->num_rows() > 0 )
        {
            return true;
        }

        return false;
    }

    /**
     * Performs basic cleaning, Null characters, etc
     *
     * @param\tarray \tInput data
     * @return\tarray \tCleaned data
     */
    static public function cleanGlobals( &$data, $iteration = 0 )
    {
        // Crafty hacker could send something like &foo[][][][][][]....to kill Apache process
        // We should never have an input array deeper than 10..

        if ( $iteration >= 10 )
        {
            return;
        }

        foreach ( $data as $k => $v )
        {
            if ( is_array( $v ) )
            {
                self::cleanGlobals( $data[$k], ++$iteration );
            }
            else
            {
                # Null byte characters
                $v = str_replace( chr( '0' ), '', $v );
                $v = str_replace( "\\0", '', $v );
                $v = str_replace( "\\x00", '', $v );
                $v = str_replace( "../", "&#46;&#46;/", $v );
                $v = str_replace( '&#8238;', '', $v );
                $data[$k] = $v;
            }
        }
    }

    /**
     * Check if all Panel Files are writeable
     *
     * @param\tnone
     * @return void
     */
    static public function CanUpdate()
    {
        $source = @simplexml_load_file( "http://xtream-codes.com/softwares/iptv_panel/FileList.xml" );

        if ( ! empty( $source ) )
        {
            foreach ( $source->file as $info )
            {
                if ( file_exists( IPTV_ROOT_PATH . $info->filename ) )
                {
                    if ( ! is_writeable( IPTV_ROOT_PATH . $info->filename ) )
                    {
                        return false;
                    }
                }
            }

            return is_writeable( IPTV_ROOT_PATH );
        }

        return true;
    }

    /**
     * Recursively cleans keys and values and
     * inserts them into the input array
     *
     * @param\tmixed\t\tInput data
     * @param\tarray\t\tStorage array for cleaned data
     * @param\tinteger\t\tCurrent iteration
     * @return\tarray \t\tCleaned data
     */
    static public function parseIncomingRecursively( &$data, $input = array(), $iteration = 0 )
    {
        // Crafty hacker could send something like &foo[][][][][][]....to kill Apache process
        // We should never have an input array deeper than 20..

        if ( $iteration >= 20 )
        {
            return $input;
        }

        if ( ! is_array( $data ) )
        {
            return $input;
        }

        foreach ( $data as $k => $v )
        {
            if ( is_array( $v ) )
            {
                $input[$k] = self::parseIncomingRecursively( $data[$k], array(), $iteration + 1 );
            }
            else
            {
                $k = self::parseCleanKey( $k );
                $v = self::parseCleanValue( $v );

                $input[$k] = $v;
            }
        }

        return $input;
    }

    /**
     * Clean _GET _POST key
     *
     * @param\tstring\t\tKey name
     * @return\tstring\t\tCleaned key name
     */
    static public function parseCleanKey( $key )
    {
        if ( $key === "" )
        {
            return "";
        }

        $key = htmlspecialchars( urldecode( $key ) );
        $key = str_replace( "..", "", $key );
        $key = preg_replace( '/\\_\\_(.+?)\\_\\_/', "", $key );
        $key = preg_replace( '/^([\\w\\.\\-\\_]+)$/', "$1", $key );

        return $key;
    }

    /**
     * Clean _GET _POST value
     *
     * @param\tstring\t\tInput
     * @param\tbool\t\tAlso run postParseCleanValue
     * @return\tstring\t\tCleaned Input
     */
    static public function parseCleanValue( $val )
    {
        if ( $val == "" )
        {
            return "";
        }

        $val = str_replace( "&#032;", " ", stripslashes( $val ) );

        # Convert all carriage return combos
        $val = str_replace( array(
            "\\r\\n",
            "\\n\\r",
            "\\r" ),
            "\\n", $val );

        $val = str_replace( "<!--", "&#60;&#33;--", $val );
        $val = str_replace( "-->", "--&#62;", $val );
        $val = str_ireplace( "<script", "&#60;script", $val );
        $val = preg_replace( "/&amp;#([0-9]+);/s", "&#\\\\1;", $val );
        $val = preg_replace( '/&#(\\d+?)([^\\d;])/i', "&#\\\\1;\\\\2", $val );

        return trim( $val );
    }

    /**
     * Get ipTV Licence
     *
     * @param none
     */
    static public function IsDemo()
    {
        return file_exists( IPTV_ROOT_PATH . 'demo.iptv' );
    }

    /**
     * Get ipTV Licence
     *
     * @param none
     */
    static public function GetLicence()
    {
        self::$ipTV_db->query( "SELECT * from `licence` WHERE `id` = 1" );
        if ( self::$ipTV_db->num_rows() > 0 )
        {

            $row = self::$ipTV_db->get_row();
            self::$licence = $row;
            return $row['licence_key'];

        }
        return false;
    }

    /**
     * Check If Given E-mail Is Valid
     *
     * @param string Email
     * @return bool
     */
    static public function IsEmail( $email )
    {
        $isValid = true;
        $atIndex = strrpos( $email, "@" );
        if ( is_bool( $atIndex ) && ! $atIndex )
        {
            $isValid = false;
        }
        else
        {
            $domain = substr( $email, $atIndex + 1 );
            $local = substr( $email, 0, $atIndex );
            $localLen = strlen( $local );
            $domainLen = strlen( $domain );
            if ( $localLen < 1 || $localLen > 64 )
            {
                // local part length exceeded
                $isValid = false;
            }
            else
                if ( $domainLen < 1 || $domainLen > 255 )
                {
                    // domain part length exceeded
                    $isValid = false;
                }
                else
                    if ( $local[0] == '.' || $local[$localLen - 1] == '.' )
                    {
                        // local part starts or ends with '.'
                        $isValid = false;
                    }
                    else
                        if ( preg_match( '/\\\\.\\\\./', $local ) )
                        {
                            // local part has two consecutive dots
                            $isValid = false;
                        }
                        else
                            if ( ! preg_match( '/^[A-Za-z0-9\\\\-\\\\.]+$/', $domain ) )
                            {
                                // character not valid in domain part
                                $isValid = false;
                            }
                            else
                                if ( preg_match( '/\\\\.\\\\./', $domain ) )
                                {
                                    // domain part has two consecutive dots
                                    $isValid = false;
                                }


            if ( $isValid && ! ( checkdnsrr( $domain, "MX" ) || checkdnsrr( $domain, "A" ) ) )
            {
                // domain not found in DNS
                $isValid = false;
            }
        }
        return $isValid;
    }
	
    /**
     * Save log MySQL
     *
     * @param none
     */
    static public function SaveLog($msg)
    {
        self::$ipTV_db->query('INSERT INTO `panel_logs` (`log_message`,`date`) VALUES(\'%s\',\'%d\')', $msg, time());
    }


    /**
     * Generate Random String
     *
     * @param string Email
     * @return bool
     */
    static public function GenerateString( $length = 10 )
    {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

        $str = '';
        $max = strlen( $chars ) - 1;

        for ( $i = 0; $i < $length; $i++ )
            $str .= $chars[rand( 0, $max )];

        return $str;
    }

    /**
     * array_values recursive
     *
     * @param array $array
     * @return array
     */
    static public function array_values_recursive( $array )
    {
        $arrayValues = array();

        foreach ( $array as $value )
        {
            if ( is_scalar( $value ) or is_resource( $value ) )
            {
                $arrayValues[] = $value;
            }
            elseif ( is_array( $value ) )
            {
                $arrayValues = array_merge( $arrayValues, self::array_values_recursive( $value ) );
            }
        }

        return $arrayValues;
    }
    /**
     * Configure Stream Name
     *
     * @param None
     * @return bool
     */
    static public function GetStreamName( $stream_name )
    {
        return str_replace( chr( 32 ), "_", "iptv_" . $stream_name );
    }

    /**
     * Generate a listing of page - pagination
     *
     * @param int The number of items
     * @param int The number of items to be shown per page
     * @param int The current page number
     * @param string The URL to have page numbers tacked on to (If {page} is specified, the value will be replaced with the page #)
     * @return string The generated pagination
     */
    static function getPaginationString( $page = 1, $total_pages, $limit = 15, $adjacents = 1, $targetpage = "/", $pagestring = "page=" )
    {
        //defaults
        if ( ! $adjacents )
            $adjacents = 1;
        if ( ! $limit )
            $limit = 15;
        if ( ! $page )
            $page = 1;
        if ( ! $targetpage )
            $targetpage = "/";

        //other vars
        $prev = $page - 1; //previous page is page - 1
        $next = $page + 1; //next page is page + 1
        $lastpage = $total_pages;

        $lpm1 = $lastpage - 1; //last page minus 1

        /*
        Now we apply our rules and draw the pagination object. 
        We're actually saving the code to a variable in case we want to draw it more than once.
        */
        $pagination = "";
        if ( $lastpage > 1 )
        {
            $pagination .= "<div class='pagination'>";
            $pagination .= ">";

            //previous button
            if ( $page > 1 )
                $pagination .= "<a href='$targetpage$pagestring$prev'><< prev</a>";
            else
                $pagination .= "<span class='disabled'><< prev</span>";

            //pages
            if ( $lastpage < 7 + ( $adjacents * 2 ) ) //not enough pages to bother breaking it up
            {
                for ( $counter = 1; $counter <= $lastpage; $counter++ )
                {
                    if ( $counter == $page )
                        $pagination .= "<span class='current'>$counter</span>";
                    else
                        $pagination .= "<a href='" . $targetpage . $pagestring . $counter . "'>$counter</a>";
                }
            }
            elseif ( $lastpage >= 7 + ( $adjacents * 2 ) ) //enough pages to hide some
            {
                //close to beginning; only hide later pages
                if ( $page < 1 + ( $adjacents * 3 ) )
                {
                    for ( $counter = 1; $counter < 4 + ( $adjacents * 2 ); $counter++ )
                    {
                        if ( $counter == $page )
                            $pagination .= "<span class='current'>$counter</span>";
                        else
                            $pagination .= "<a href='" . $targetpage . $pagestring . $counter . "'>$counter</a>";
                    }
                    $pagination .= "<span class='elipses'>...</span>";
                    $pagination .= "<a href='" . $targetpage . $pagestring . $lpm1 . "'>$lpm1</a>";
                    $pagination .= "<a href='" . $targetpage . $pagestring . $lastpage . "'>$lastpage</a>";
                }
                //in middle; hide some front and some back
                elseif ( $lastpage - ( $adjacents * 2 ) > $page && $page > ( $adjacents * 2 ) )
                {
                    $pagination .= "<a href='" . $targetpage . $pagestring . "1'>1</a>";
                    $pagination .= "<a href='" . $targetpage . $pagestring . "2'>2</a>";
                    $pagination .= "<span class='elipses'>...</span>";
                    for ( $counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++ )
                    {
                        if ( $counter == $page )
                            $pagination .= "<span class='current'>$counter</span>";
                        else
                            $pagination .= "<a href='" . $targetpage . $pagestring . $counter . "'>$counter</a>";
                    }
                    $pagination .= "...";
                    $pagination .= "<a href='" . $targetpage . $pagestring . $lpm1 . "'>$lpm1</a>";
                    $pagination .= "<a href='" . $targetpage . $pagestring . $lastpage . "'>$lastpage</a>";
                }
                //close to end; only hide early pages
                else
                {
                    $pagination .= "<a href='" . $targetpage . $pagestring . "1'>1</a>";
                    $pagination .= "<a href='" . $targetpage . $pagestring . "2'>2</a>";
                    $pagination .= "<span class='elipses'>...</span>";
                    for ( $counter = $lastpage - ( 1 + ( $adjacents * 3 ) ); $counter <= $lastpage; $counter++ )
                    {
                        if ( $counter == $page )
                            $pagination .= "<span class='current'>$counter</span>";
                        else
                            $pagination .= "<a href='" . $targetpage . $pagestring . $counter . "'>$counter</a>";
                    }
                }
            }

            //next button
            if ( $page < $counter - 1 )
                $pagination .= "<a href='" . $targetpage . $pagestring . $next . "'>next >></a>";
            else
                $pagination .= "<span class='disabled'>next >></span>";
            $pagination .= "</div>\
";
        }

        return $pagination;

    }
}

?>
