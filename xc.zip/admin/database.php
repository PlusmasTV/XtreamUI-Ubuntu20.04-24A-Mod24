<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

$all_tables = GetMySQLTables();

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    
    switch ( $action )
    {

        case "manage":
            if ( ! empty( ipTV_lib::$request['manage_click'] ) )
            {
                switch ( ipTV_lib::$request['manage_click'] )
                {
                    case $_LANG['backup_tables']:

                        header( "Content-Type: text/plain" );
                        header( 'Content-Disposition: attachment; filename="' . $_INFO['db_name'] . '_backup.sql"' );

                        echo "";
                        echo "-- <version>" . SCRIPT_VERSION . "</version>\
";
                        "--\
";
                        echo "-- Database Backup: Xtream-Codes ipTV Panel \
";
                        echo "--\
";
                        echo '-- Export created: ' . date( "Y/m/d" ) . ' on ' . date( "h:i" ) . "\
\
\
";
                        echo "--\
";
                        echo "-- Database : " . $_INFO['db_name'] . "\
";
                        echo "--\
";
                        echo 'SET AUTOCOMMIT = 0 ;' . "\
";
                        echo 'SET FOREIGN_KEY_CHECKS=0 ;' . "\
";
                        $tables = array();

                        $tables = ( array )ipTV_lib::$request['tables'];


                        foreach ( $tables as $table )
                        {
                            echo "--\
";
                            echo '-- Tabel structure for table `' . $table . '`' . "\
";
                            echo "--\
";
                            echo 'DROP TABLE IF EXISTS `' . $table . '`;' . "\
";
                            $ipTV_db->query( 'SHOW CREATE TABLE `' . $table . '`' );
                            $tableshema = $ipTV_db->get_row();
                            echo $tableshema['Create Table'] . ";" . "\
\
";


                            $ipTV_db->query( 'SELECT * FROM `' . $table . '`' );
                            $num_fields = $ipTV_db->num_fields();

                            while ( $row = mysql_fetch_array( $ipTV_db->result, MYSQL_ASSOC ) )
                            {

                                $columns = array_keys( $row );
                                // Prepare code that will insert data into table
                                $return = 'INSERT INTO `' . $table . '`  VALUES ( ';
                                // Extract data of each row
                                for ( $i = 0; $i < $num_fields; $i++ )
                                {
                                    if ( is_null( $row[$columns[$i]] ) )
                                    {
                                        $return .= 'NULL,';
                                    }
                                    else
                                    {
                                        $return .= '"' . addslashes( $row[$columns[$i]] ) . '';
                                    }
                                }
                                // Let's remove the last comma
                                $return = substr( "$return", 0, -1 );
                                $return .= ");" . "\
";

                                echo $return;
                            }
                        }

                        exit;
                        break;

                    case $_LANG['optimize_tables']:
                        $tables = ( array )ipTV_lib::$request['tables'];
                        foreach ( $tables as $table )
                        {
                            $ipTV_db->query( "OPTIMIZE TABLE `$table`" );
                        }
                        $ok_message = $_LANG['optimization_complete'];
                        break;
                }
            }
        case "restore":
            if ( ! empty( $_FILES ) and isset( $_FILES['db'] ) )
            {
                $error = $_FILES['db']['error'];
                if ( $error == 1 )
                {
                    $warn_message = $_LANG['upload_size'];
                }
                elseif ( $error == 3 )
                {
                    $warn_message = $_LANG['partially_upload'];
                }
                elseif ( $error == 6 )
                {
                    $warn_message = $_LANG['temp_missing'];
                }
                elseif ( $error == 7 )
                {
                    $warn_message = $_LANG['no_write'];
                }
                else
                {
                    if ( file_exists( IPTV_ROOT_PATH . 'sql_update.php' ) )
                    {
                        $file_info = pathinfo( $_FILES['db']['name'] );
                        $name = $file_info['filename'];
                        $ext = strtolower( trim( $file_info['extension'] ) );
                        if ( $ext == "sql" )
                        {
                            //grab <version> tag
                            $fp = fopen( $_FILES['db']['tmp_name'], "r" );
                            $version = fgets( $fp );
                            fclose( $fp );


                            if ( preg_match( "/<version>(.*?)<\\/version>/", $version, $matches ) )
                            {

                                $database_version = $matches[1];
                                $queries = DumpQueries( file( $_FILES['db']['tmp_name'] ) );
                                foreach ( $queries as $query )
                                {
                                    $ipTV_db->query( $query );
                                }

                                require ( IPTV_ROOT_PATH . 'sql_update.php' );
                                if ( ! empty( $_QUERIES ) )
                                {
                                    //find our version
                                    foreach ( $_QUERIES as $version => $queries )
                                    {
                                        if ( version_compare( $database_version, $version ) < 0 )
                                        {
                                            if ( is_array( $queries ) )
                                            {
                                                foreach ( $queries as $query )
                                                {
                                                    $ipTV_db->query( $query );
                                                }
                                            }
                                            else
                                            {
                                                $ipTV_db->query( $queries );
                                            }
                                        }

                                    }
                                }
                                
                                $ok_message = $_LANG['restore_done'];
                            }
                        }
                        else
                        {
                            $warn_message = $_LANG['no_sql_extension'];
                        }
                    }
                    else
                    {
                        $warn_message = $_LANG['sql_file_not_found'];
                    }
                }
            }
            break;
        case "run":
            if ( ! empty( ipTV_lib::$request['queries'] ) )
            {
                $queries = DumpQueries( ipTV_lib::$request['queries'] );
                foreach ( $queries as $query )
                {
                    $ipTV_db->query( $query );
                }

                $ok_message = $_LANG['queries_executed'];
            }
            break;
    }
}


$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'database.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
@eval( ' ?> ' . $template . ' <?php ' );

?>
