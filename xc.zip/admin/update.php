<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( ! is_writable( sys_get_temp_dir() ) )
{
    $er_message = str_replacr( "{DIR}", sys_get_temp_dir(), $_LANG['tmp_nwriteable'] );
}
elseif ( ! class_exists( 'ZipArchive' ) )
{
    $er_message = $_LANG['zip_missing'];
}
else
{
    $update = UpdateCheck();
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "download":
            if ( DownloadUpdate() )
            {
                $ipTV_db->query( "UPDATE `licence` SET `update_available` = 0 WHERE `id` = 1" );
                header( 'Location: ./index.php?msg=updated' );
                exit( 0 );
            }
            else
            {
                $er_message = $_LANG['cant_download_update'];
            }
            break;
    }
}

if ( is_array( $update ) )
{
    $warn_message = $_LANG['new_version_out'];
    $can_update = ipTV_lib::CanUpdate();
}
else
{
    $ok_message = $_LANG['latest_ver'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'update.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );

@eval( ' ?> ' . $template . ' <?php ' );

?>
