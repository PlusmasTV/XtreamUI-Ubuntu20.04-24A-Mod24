<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


$stream_id = false;
if ( ! empty( ipTV_lib::$request['stream_id'] ) && is_numeric( ipTV_lib::$request['stream_id'] ) )
{
    $stream_id = ipTV_lib::$request['stream_id'];

    if ( ! RowExists( "streams", "id", $stream_id ) )
    {
        $er_message = $_LANG['stream_id_nexists'];
    }
    else
    {
        $muxes = GetMuxes();
        $categories = ( empty( $categories ) ) ? GetCategories( 'live' ) : $categories;
        $arguments = GetVLCArguments();
        $stream_arguments = GetStreamArguments( $stream_id );
        $info = GetStreamInfo( $stream_id );
        $ffmpegs = ipTV_Stream::GetFFmpegBins();

        if ( isset( ipTV_lib::$request['action'] ) )
        {
            $action = ipTV_lib::$request['action'];
            unset( ipTV_lib::$request['action'] );
            switch ( $action )
            {
                case "edit_stream":
                    if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['mux_id'] ) && ! empty( ipTV_lib::$request['stream_source'] ) && ! empty( ipTV_lib::$request['stream_display_name'] ) && ! empty( ipTV_lib::$request['dest_stream_port'] ) )
                    {



                            $friendly_name = ipTV_lib::$request['stream_display_name'];
                            $stream_source = ipTV_lib::$request['stream_source'];
                            $notes = ( ! empty( ipTV_lib::$request['notes'] ) ) ? trim( ipTV_lib::$request['notes'] ) : "";
                            $category_id = ( ! empty( ipTV_lib::$request['category_id'] ) && RowExists( "stream_categories", "id", ipTV_lib::$request['category_id'] ) ) ? intval( ipTV_lib::$request['category_id'] ) : 'NULL';
                            $enable_ffmpeg = ( empty( ipTV_lib::$request['enable_ffmpeg'] ) ) ? false : true;
                            $ffmpeg_bin = ( $enable_ffmpeg ) ? ipTV_lib::$request['ffmpeg_bin'] : 'NULL';
                            $h264_filter = ( $enable_ffmpeg && ! empty( ipTV_lib::$request['h264_filter'] ) ) ? 1 : 0;
                            $dest_stream_port = ipTV_lib::$request['dest_stream_port'];
                            $enable_rtmpdump = ( empty( ipTV_lib::$request['enable_rtmpdump'] ) ) ? 0 : 1;

                            $selected_mux = intval( ipTV_lib::$request['mux_id'] );

                            if ( $info['stream_display_name'] == $friendly_name || ! RowExists( "streams", "stream_display_name", $friendly_name ) )
                            {
                                if ( RowExists( "stream_mux", "id", $selected_mux ) )
                                {

                                    if ( $dest_stream_port == $info['dest_stream_port'] || ! ipTV_lib::PortInUse( $dest_stream_port ) )
                                    {


                                        $ipTV_db->query( "UPDATE `streams` SET `stream_display_name` = '%s',
                                                                       `stream_source` = '%s',
                                                                       `dest_stream_port` = '%d',
                                                                       `mux_id` = '%d',
                                                                       `enable_ffmpeg` = '%d',
                                                                       `h264_filter` = '%d',
                                                                       `enable_rtmpdump` = '%d',
                                                                       `notes` = '%s' WHERE `id` = '%d'", $friendly_name, $stream_source, $dest_stream_port, $selected_mux, $enable_ffmpeg, $h264_filter, $enable_rtmpdump, $notes, $stream_id );

                                        if ( $enable_ffmpeg )
                                        {
                                            $ipTV_db->query( "UPDATE `streams` SET `ffmpeg_bin` = '%s' WHERE `id` = '%d'", $ffmpeg_bin, $stream_id );
                                        }

                                        if ( is_null( $category_id ) || ! RowExists( "stream_categories", "id", $category_id ) )
                                        {
                                            $ipTV_db->query( "UPDATE `streams` SET `category_id` = NULL WHERE `id` = '%d'", $stream_id );
                                        }
                                        else
                                        {
                                            $ipTV_db->query( "UPDATE `streams` SET `category_id` = '%d' WHERE `id` = '%d'", $category_id, $stream_id );
                                        }

                                        //do we have arguments to import?
                                        if ( ! empty( ipTV_lib::$request['arguments'] ) && ! ipTV_lib::IsDemo() )
                                        {
                                            $arguments_posted = ipTV_lib::$request['arguments'];
                                            if ( is_array( $arguments_posted ) )
                                            {
                                                $ipTV_db->query( "DELETE FROM `streams_options` WHERE `stream_id` = '%d'", $stream_id );
                                                foreach ( $arguments_posted as $argument_id => $argument_value )
                                                {
                                                    $argument_value = trim( $argument_value );
                                                    if ( empty( $argument_value ) )
                                                    {
                                                        continue;
                                                    }
                                                    if ( RowExists( "vlc_arguments", "id", $argument_id ) )
                                                    {
                                                        $ipTV_db->query( "INSERT INTO `streams_options` (`stream_id`,`argument_id`,`value`) VALUES('%d','%d','%s');", $stream_id, $argument_id, $argument_value );
                                                    }
                                                }
                                            }
                                        }


                                        $ok_message = str_replace( "{HERE}", "<a href='streams.php?action=str_restart&stream_id=$stream_id'>here</a>", $_LANG['click_restat_stream'] );
                                    }
                                    else
                                    {
                                        $warn_message = $_LANG['port_in_use'];
                                    }
                                }
                                else
                                {
                                    $warn_message = $_LANG['mux_nexists'];
                                }
                            }
                            else
                            {
                                $warn_message = str_replace( "{stream_name}", $stream_name, $_LANG['stream_exists'] );
                            }

                       
                    }
                    else
                    {
                        $warn_message = $_LANG['complete_fields'];
                    }

                    break;

            }
        }
        $stream_arguments = GetStreamArguments( $stream_id );
        $info = GetStreamInfo( $stream_id );
    }
}
else
{
    $er_message = $_LANG['select_stream_edit'];
}


$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'edit_stream.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
