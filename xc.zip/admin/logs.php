<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
    }
}

$ipTV_db->query( "SELECT count(`id`) FROM `logs`" );
$total_logs = $ipTV_db->get_col();

$per_page = 100;
$adjacents = 3;
if ( ! empty( ipTV_lib::$request['page'] ) )
{
    $page = intval( ipTV_lib::$request['page'] );
}
else
{
    $page = 1;
}


$logs = GetLogs( true, ( $page - 1 ) * $per_page, $per_page );
$total_page_logs = count( $logs );

$total_pages = ceil( $total_logs / $per_page );

$pagination = ipTV_lib::getPaginationString( $page, $total_pages, $per_page, $adjacents, "logs.php?" );

if ( $total_page_logs == 0 )
{
    $warn_message = $_LANG['no_logs'];
}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'logs.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
