<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "save":

            if ( ! empty( ipTV_lib::$request['streams'] ) && ! empty( ipTV_lib::$request['arguments'] ) )
            {

                $restart_streams = ( empty( ipTV_lib::$request['restart_streams'] ) ) ? 0 : 1;
                $selected_streams = ipTV_lib::$request['streams'];
                if ( is_array( $selected_streams ) )
                {
                    $selected_streams = array_map( "intval", $selected_streams );
                    $arguments_posted = ( ! is_array( ipTV_lib::$request['arguments'] ) ) ? array() : ipTV_lib::$request['arguments'];
                    $arguments_remove = ( ! is_array( @ipTV_lib::$request['arguments_remove'] ) ) ? array() : array_map( "intval", array_keys( ipTV_lib::$request['arguments_remove'] ) );

                    $category_id = intval( ipTV_lib::$request['category_id'] );
                    $enable_ffmpeg = intval( ipTV_lib::$request['enable_ffmpeg'] );
                    $enable_rtmpdump = intval( ipTV_lib::$request['enable_rtmpdump'] );

                    $ffmpeg_bin = ( $enable_ffmpeg > 0 ) ? ipTV_lib::$request['ffmpeg_bin'] : 'NULL';
                    $h264_filter = ( $enable_ffmpeg > 0 && ! empty( ipTV_lib::$request['h264_filter'] ) ) ? 1 : 0;

                    $mux_id = ( ! empty( ipTV_lib::$request['mux_id'] ) && RowExists( "stream_mux", "id", ipTV_lib::$request['mux_id'] ) ) ? intval( ipTV_lib::$request['mux_id'] ) : false;


                    //Remove Arguments
                    if ( ! empty( $arguments_remove ) )
                        $ipTV_db->query( "DELETE FROM `streams_options` WHERE `stream_id` IN(" . implode( ',', $selected_streams ) . ") AND `argument_id` IN(" . implode( ',', $arguments_remove ) . ")" );

                    foreach ( $selected_streams as $stream_id )
                    {

                        //Change mux?
                        if ( $mux_id !== false )
                        {
                            $ipTV_db->query( "UPDATE `streams` SET `mux_id` = '%d' WHERE `id` = '%d'", $mux_id, $stream_id );
                        }

                        if ( $category_id >= 0 )
                        {
                            if ( $category_id == 0 )
                                $ipTV_db->query( "UPDATE `streams` SET `category_id` = NULL WHERE `id` = '%d'", $stream_id );
                            else
                                $ipTV_db->query( "UPDATE `streams` SET `category_id` = '%d' WHERE `id` = '%d'", $category_id, $stream_id );
                        }

                        if ( $enable_rtmpdump > 0 )
                        {
                            $ipTV_db->query( "UPDATE `streams` SET `enable_rtmpdump` = 1 WHERE `id` = '%d'", $stream_id );
                        }
                        elseif ( $enable_rtmpdump == 0 )
                        {
                            $ipTV_db->query( "UPDATE `streams` SET `enable_rtmpdump` = 0 WHERE `id` = '%d'", $stream_id );
                        }


                        if ( $enable_ffmpeg > 0 )
                        {
                            $ipTV_db->query( "UPDATE `streams` SET `enable_ffmpeg` = '%d',`ffmpeg_bin` = '%s',`h264_filter` = '%d' WHERE `id` = '%d'", $enable_ffmpeg, $ffmpeg_bin, $h264_filter, $stream_id );
                        }
                        elseif ( $enable_ffmpeg == 0 )
                        {
                            $ipTV_db->query( "UPDATE `streams` SET `enable_ffmpeg` = 0,`ffmpeg_bin` = NULL,`h264_filter` = 0 WHERE `id` = '%d'", $stream_id );
                        }

                        foreach ( $arguments_posted as $argument_id => $argument_value )
                        {
                            $argument_value = trim( $argument_value );

                            if ( in_array( $argument_id, $arguments_remove ) || empty( $argument_value ) )
                            {
                                continue;
                            }

                            if ( RowExists( "vlc_arguments", "id", $argument_id ) )
                            {
                                $ipTV_db->query( "DELETE FROM `streams_options` WHERE `stream_id` = '%d' AND `argument_id` = '%d'", $stream_id, $argument_id );
                                $ipTV_db->query( "INSERT INTO `streams_options` (`stream_id`,`argument_id`,`value`) VALUES('%d','%d','%s');", $stream_id, $argument_id, $argument_value );
                            }
                        }

                        if ( $restart_streams == 1 )
                            ipTV_Stream::StartStream( $stream_id );
                    }

                    if ( $restart_streams == 0 )
                    {
                        $ok_message = $_LANG['no_restart_found'];
                    }
                    else
                    {
                        $ok_message = $_LANG['stream_edited'];
                    }
                }
            }
            break;
    }
}

$streams = GetStreams( 'live' );
$categories = ( empty( $categories ) ) ? GetCategories( 'live' ) : $categories;
if ( empty( $streams ) )
{
    $er_message = $_LANG['create_stream_first_mass'];
}
$muxes = GetMuxes();
$ffmpegs = ipTV_Stream::GetFFmpegBins();
$arguments = GetVLCArguments();
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'mass_sedits.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>