<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "save":
            if ( ! empty( ipTV_lib::$request ) )
            {

                foreach ( ipTV_lib::$request as $key => $value )
                {
                    $ipTV_db->query( "UPDATE `settings` SET `%s` = '%s' WHERE `id` = 1", $key,$value );
                }

                ipTV_lib::GetSettings();

                $ok_message = $_LANG['action_done'];
            }
            break;
    }
}


$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'emailmsg.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
@eval( ' ?> ' . $template . ' <?php ' );

?>
