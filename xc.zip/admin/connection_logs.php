<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}



$show = array(
    "closed",
    "open",
    "show_all" );

$selected_show = "show_all";

if ( ! empty( ipTV_lib::$request['show'] ) )
{
    if ( in_array( ipTV_lib::$request['show'], $show ) )
    {
        $selected_show = ipTV_lib::$request['show'];

    }
}

switch ( $selected_show )
{
    case "open":

        $ipTV_db->query( "SELECT count(`id`) FROM `user_activity` WHERE ISNULL(`date_end`)" );
        break;

    case "closed":
        $ipTV_db->query( "SELECT count(`id`) FROM `user_activity` WHERE ISNULL(`pid`)" );
        break;

    default:
        $ipTV_db->query( "SELECT count(`id`) FROM `user_activity`" );
        break;
}
$total_activities = $ipTV_db->get_col();


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "kill_activity":
            if ( ! empty( ipTV_lib::$request['activity_id'] ) )
            {
                $activity_id = intval( ipTV_lib::$request['activity_id'] );
                $status = kick_activity( $activity_id );

                if ( is_bool( $status ) )
                {
                    $ok_message = $_LANG['connection_killed'];
                }
                else
                {
                    $warn_message = $status;
                }
            }
            break;

        case "del_activity":
            if ( ! empty( ipTV_lib::$request['activity_id'] ) )
            {
                $activity_id = intval( ipTV_lib::$request['activity_id'] );
                $status = kick_activity( $activity_id );

                if ( is_bool( $status ) )
                {
                    $ipTV_db->query( "DELETE FROM `user_activity` WHERE `id` = '%d'", $activity_id );
                    $ok_message = $_LANG['connection_deleted'];
                }
                else
                {
                    $warn_message = $status;
                }

            }
            break;
    }
}
$per_page = 100;
$adjacents = 3;

if ( ! empty( ipTV_lib::$request['page'] ) )
{
    $page = intval( ipTV_lib::$request['page'] );
}
else
{
    $page = 1;
}

$activities = GetConnections( $selected_show, true, ( $page - 1 ) * $per_page, $per_page );
$total_page_activities = count( $activities );


$total_pages = ceil( $total_activities / $per_page );

$pagination = ipTV_lib::getPaginationString($page,$total_pages,$per_page,$adjacents,"connection_logs.php?show=$selected_show&");


if ( $total_page_activities == 0 )
{
    $warn_message = $_LANG['no_connections_found'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'connection_logs.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
