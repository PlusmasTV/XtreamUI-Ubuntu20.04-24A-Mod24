<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "str_start":
            if ( ! empty( ipTV_lib::$request['stream_id'] ) )
            {
                $stream_id = intval( ipTV_lib::$request['stream_id'] );
                if ( ipTV_Stream::StartStream( $stream_id ) )
                {
                    $ok_message = $_LANG['stream_started'];
                }
                else
                    $warn_message = $_LANG['stream_start_error'];
            }
            break;

        case "open_stream":
            if ( ! empty( ipTV_lib::$request['stream_id'] ) )
            {
                $stream_id = intval( ipTV_lib::$request['stream_id'] );
                $output = '<html>
                <div id="header">
                <center>
                <object id="LivePlayer" 
                \twidth="1020" height="700" 
                \tclassid="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" 
                \ttype="application/x-oleobject"> <param name="URL" value="http://' . ipTV_lib::$settings['site_url'] . '/super_streaming.php?password=' . ipTV_lib::$settings['live_streaming_pass'] . '&stream=' . $stream_id . '" />
                    <param name="src" value="http://' . ipTV_lib::$settings['site_url'] . '/super_streaming.php?password=' . ipTV_lib::$settings['live_streaming_pass'] . '&stream=' . $stream_id . '" />
                    <param name="SendPlayStateChangeEvents" value="True" />
                  <param name="AutoStart" value="True" />
                  <param name="AutoLoop" value="False" />
                  <param name="uiMode" value="full" />
                  <param name="PlayCount" value="9999" />
                  <param name="stretchtofit" value="true" />
                  <embed
                \t\ttype="application/x-mplayer2"
                \t\tPluginsPage="http://www.microsoft.com/Windows/Downloads/Contents/Products/MediaPlayer/"
                \t\tsrc="http://' . ipTV_lib::$settings['site_url'] . '/super_streaming.php?password=' . ipTV_lib::$settings['live_streaming_pass'] . '&stream=' . $stream_id . '"
                \t\tname="LivePlayer"
                \t\tWidth="980"
                \t\tHeight="630"
                \t\tTransparentAtStart="1"
                \t\tAutoStart="1"
                \t\tAnimationAtStart="0"
                \t\tSendPlayStateChangeEvents="1"
                \t\tShowPositionControls="0"
                \t\tShowDisplay="0"
                \t\tShowStatusBar="1"
                \t\tShowControls="1"
                \t\tShowCaptioning="0"
                \t\tShowGotoBar="0">
                \t</embed>
                </object>
                </center>';
            }
            echo $output;
            exit;
            break;

        case "str_stop":

            if ( ! empty( ipTV_lib::$request['stream_id'] ) )
            {
                $stream_id = intval( ipTV_lib::$request['stream_id'] );
                ipTV_Stream::StopStream( $stream_id );
                $ok_message = $_LANG['stream_stopped'];

            }
            break;

        case "stop_all":
            $ipTV_db->query( "SELECT `id` FROM `streams` WHERE `type` = 'live'" );
            if ( $ipTV_db->num_rows() > 0 )
            {
                $streams_ids = ipTV_lib::array_values_recursive( $ipTV_db->get_rows() );

                foreach ( $streams_ids as $stream_id )
                {
                    ipTV_Stream::StopStream( $stream_id );
                }

                $ok_message = $_LANG['streams_stoped_success'];
            }
            break;

        case "start_all":
            $ipTV_db->query( "SELECT `id` FROM `streams` WHERE `type` = 'live'" );
            if ( $ipTV_db->num_rows() > 0 )
            {
                $streams_ids = ipTV_lib::array_values_recursive( $ipTV_db->get_rows() );

                $error = false;
                foreach ( $streams_ids as $stream_id )
                {
                    ipTV_Stream::StartStream( $stream_id );
                }

                $ok_message = $_LANG['streams_started'];
            }
            break;

        case "debug":
            if ( ! empty( ipTV_lib::$request['stream_id'] ) )
            {
                $stream_id = intval( ipTV_lib::$request['stream_id'] );
                if ( RowExists( "streams", "id", $stream_id ) )
                {
                    echo "<textarea style='width:100%;background-color: black;color: white;' rows='50' cols='50'>";
                    ipTV_Stream::DebugStream( $stream_id );
                    echo "</textarea>";
                    exit;
                }
            }
            break;

        case "str_restart":
            if ( ! empty( ipTV_lib::$request['stream_id'] ) )
            {
                $stream_id = intval( ipTV_lib::$request['stream_id'] );
                if ( ipTV_Stream::StartStream( $stream_id ) )
                {
                    $ok_message = $_LANG['stream_restarted'];
                }
                else
                    $warn_message = $_LANG['stream_restart_error'];
            }
            break;

        case "str_delete":
            if ( ! empty( ipTV_lib::$request['stream_id'] ) )
            {

                $stream_id = intval( ipTV_lib::$request['stream_id'] );

                if ( DeleteStream( $stream_id ) )
                {
                    $ok_message = $_LANG['stream_deleted'];
                }
                else
                {
                    $warn_message = $_LANG['cant_stop_stream'];
                }
            }

            break;
    }
}


$streams = GetStreams( 'live' );
if ( empty( $streams ) )
{
    $er_message = $_LANG['add_some_streams'];
}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'streams.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
