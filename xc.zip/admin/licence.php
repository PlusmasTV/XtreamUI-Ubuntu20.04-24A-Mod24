<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "save":
            if ( isset( ipTV_lib::$request['licence_key'] ) )
            {
                $licence_key = ipTV_lib::$request['licence_key'];

                $ipTV_db->query( "UPDATE `licence` SET `licence_key` = '%s' WHERE `id` = 1", $licence_key );
                CheckLicence();
                $ok_message = $_LANG['licence_changed'];
                ipTV_lib::GetLicence();
            }
            break;

    }
}

if ( isset(ipTV_lib::$licence['show_message']) AND ipTV_lib::$licence['show_message'] == 1 )
{
    $ok_message = $_LANG['licence_valid'];
}
else
{
    $ok_message = $_LANG['licence_valid'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'licence.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );

@eval( ' ?> ' . $template . ' <?php ' );

?>
