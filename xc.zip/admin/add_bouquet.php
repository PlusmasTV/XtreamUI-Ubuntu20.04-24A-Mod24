<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "add_bouquet":
            if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['bouquet_name'] ) && ! empty( ipTV_lib::$request['bouquet_selection'] ) )
            {
                

                    $bouquet_name = ipTV_lib::$request['bouquet_name'];

                    if ( ! RowExists( "bouquets", "bouquet_name", $bouquet_name ) )
                    {
                        $bouquet = ipTV_lib::$request['bouquet_selection'];

                        $bouquet_import = array();
                        foreach ( $bouquet as $key => $id )
                        {
                            if ( ! is_numeric( $id ) )
                            {
                                continue;
                            }

                            if ( RowExists( "streams", "id", $id ) && ! in_array( $bouquet_import, $id ) )
                            {
                                array_push( $bouquet_import, $id );
                            }
                        }


                        $ipTV_db->query( "INSERT INTO `bouquets` (`bouquet_name`,`bouquet_channels`) VALUES('%s','%s')", $bouquet_name, serialize( $bouquet_import ) );

                        $ok_message = $_LANG['bouquet_added'];

                    }
                    else
                    {
                        $warn_message = $_LANG['bouquet_exists'];
                    }
                
            }
            else
            {
                $warn_message = $_LANG['complete_fields'];
            }

            break;

    }
}

$streams = GetStreams( null, 'stream_display_name', 'ASC' );

if ( empty( $streams ) )
{
    $er_message = $_LANG['make_streams_first'];
}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'add_bouquet.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
