<?php

/**
 * @package ipTV Panel
 * @authors Xtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {

        case "checkCodecs":
            if ( ! empty( ipTV_lib::$request['url'] ) )
            {
                $url = urldecode( base64_decode( ipTV_lib::$request['url'] ) );
                if ( $codecs = ipTV_Stream::GetCodecs( $url ) )
                {
                    echo json_encode( $codecs );
                }
                else
                    echo json_encode( array() );


                exit;

            }
            break;

        case "add_stream":
            if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['mux_id'] ) && ! empty( ipTV_lib::$request['type'] ) )
            {
                if ( ipTV_lib::IsDemo() && TotalStreams() >= DEMO_STREAMS )
                {
                    $warn_message = $_LANG['demo_stream_max'];
                }
                else
                {
                    
                        $warn_message = array();
                        $ok_message = array();

                        $auto_set = ( empty( ipTV_lib::$request['auto_set'] ) ) ? false : true;
                        $notes = ( ! empty( ipTV_lib::$request['notes'] ) ) ? trim( ipTV_lib::$request['notes'] ) : "";
                        $selected_mux = intval( ipTV_lib::$request['mux_id'] );
                        $category_id = ( ! empty( ipTV_lib::$request['category_id'] ) && RowExists( "stream_categories", "id", ipTV_lib::$request['category_id'] ) ) ? intval( ipTV_lib::$request['category_id'] ) : 'NULL';
                        $enable_ffmpeg = ( empty( ipTV_lib::$request['enable_ffmpeg'] ) ) ? false : true;
                        $ffmpeg_bin = ( $enable_ffmpeg ) ? ipTV_lib::$request['ffmpeg_bin'] : 'NULL';
                        $h264_filter = ( $enable_ffmpeg && ! empty( ipTV_lib::$request['h264_filter'] ) ) ? 1 : 0;
                        $type = intval( ipTV_lib::$request['type'] );
                        $enable_rtmpdump = ( empty( ipTV_lib::$request['enable_rtmpdump'] ) ) ? 0 : 1;
                        $streams = array();

                        switch ( $type )
                        {
                            case 1:
                                if ( ! empty( ipTV_lib::$request['stream_source'] ) && ! empty( ipTV_lib::$request['stream_display_name'] ) )
                                {

                                    $stream_name = ipTV_lib::$request['stream_display_name'];
                                    $stream_source = ipTV_lib::$request['stream_source'];

                                    $streams[$stream_name] = $stream_source;

                                }
                                break;


                            case 2:
                                if ( ! empty( $_FILES ) and isset( $_FILES['stream_list'] ) )
                                {
                                    $error = $_FILES['stream_list']['error'];
                                    if ( $error == 1 )
                                    {
                                        $warn_message = $_LANG['upload_size'];
                                    }
                                    elseif ( $error == 3 )
                                    {
                                        $warn_message = $_LANG['partially_upload'];
                                    }
                                    elseif ( $error == 6 )
                                    {
                                        $warn_message = $_LANG['temp_missing'];
                                    }
                                    elseif ( $error == 7 )
                                    {
                                        $warn_message = $_LANG['no_write'];
                                    }
                                    else
                                    {
                                        $streams = ipTV_Stream::FileParser( $_FILES['stream_list']['tmp_name'] );

                                    }
                                }
                                break;
                        }

                        if ( ! empty( $streams ) )
                        {
                            if ( RowExists( "stream_mux", "id", $selected_mux ) )
                            {
                                foreach ( $streams as $stream_name => $stream_source )
                                {
                                    if ( ! RowExists( "streams", "stream_display_name", $stream_name ) )
                                    {
                                        if ( ipTV_lib::IsDemo() && TotalStreams() >= DEMO_STREAMS )
                                        {
                                            continue;
                                        }

                                        if ( $auto_set === true )
                                            $port = ipTV_lib::GetNewPort();
                                        else
                                            $port = ( ! ipTV_lib::PortInUse( ipTV_lib::$request['dest_stream_port'] ) ) ? ipTV_lib::$request['dest_stream_port'] : false;

                                        if ( $port !== false )
                                        {
                                            if ( $enable_ffmpeg )
                                            {
                                                $ipTV_db->query( "INSERT INTO `streams` (`type`,`category_id`,`stream_display_name`,`stream_source`,`dest_stream_port`,`notes`,`mux_id`,`enable_ffmpeg`,`ffmpeg_bin`,`h264_filter`,`enable_rtmpdump`) VALUES('live',%s,'%s','%s','%d','%s','%d','%d','%s','%d','%d')", $category_id, $stream_name, $stream_source, $port, $notes, $selected_mux, $enable_ffmpeg, $ffmpeg_bin, $h264_filter, $enable_rtmpdump );
                                            }
                                            else
                                            {
                                                $ipTV_db->query( "INSERT INTO `streams` (`type`,`category_id`,`stream_display_name`,`stream_source`,`dest_stream_port`,`notes`,`mux_id`,`enable_ffmpeg`,`enable_rtmpdump`) VALUES('live',%s,'%s','%s','%d','%s','%d',0,'%d')", $category_id, $stream_name, $stream_source, $port, $notes, $selected_mux, $enable_rtmpdump );
                                            }

                                            //do we have arguments to import?
                                            if ( ! empty( ipTV_lib::$request['arguments'] ) && ! ipTV_lib::IsDemo() )
                                            {
                                                $arguments_posted = ipTV_lib::$request['arguments'];
                                                if ( is_array( $arguments_posted ) )
                                                {
                                                    $stream_new_id = $ipTV_db->last_insert_id();
                                                    foreach ( $arguments_posted as $argument_id => $argument_value )
                                                    {
                                                        $argument_value = trim( $argument_value );
                                                        if ( empty( $argument_value ) )
                                                        {
                                                            continue;
                                                        }
                                                        if ( RowExists( "vlc_arguments", "id", $argument_id ) )
                                                        {
                                                            $ipTV_db->query( "INSERT INTO `streams_options` (`stream_id`,`argument_id`,`value`) VALUES('%d','%d','%s');", $stream_new_id, $argument_id, $argument_value );
                                                        }
                                                    }
                                                }
                                            }

                                            $ok_message[] = str_replace( "{stream_name}", $stream_name, $_LANG['stream_added'] );
                                        }
                                        else
                                        {
                                            $warn_message[] = str_replace( "{number}", $port, $_LANG['port_error'] );
                                        }
                                    }
                                    else
                                    {
                                        $warn_message[] = str_replace( "{stream_name}", $stream_name, $_LANG['stream_exists'] );
                                    }
                                }
                            }
                            else
                            {
                                $warn_message = $_LANG['mux_nexists'];
                            }
                        }
                        else
                        {
                            $warn_message = $_LANG['no_stream_import'];
                        }
                    
                }

            }
            else
            {

                $warn_message = $_LANG['complete_fields'];
            }
            break;
    }
}

$categories = ( empty( $categories ) ) ? GetCategories( 'live' ) : $categories;
$arguments = ( empty( $arguments ) ) ? GetVLCArguments() : $arguments;
$muxes = GetMuxes();

$ffmpegs = ipTV_Stream::GetFFmpegBins();

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'add_stream.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
