<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {

        case "delete":
            if ( ! empty( ipTV_lib::$request['id'] ) )
            {
                $group_id = intval( ipTV_lib::$request['id'] );

                $ipTV_db->query( "DELETE FROM `member_groups` WHERE `id` = '%d' AND `can_delete` = 1", $group_id );
                if ( $ipTV_db->affected_rows() > 0 )
                {

                    $ipTV_db->query( "DELETE FROM `users` WHERE `member_id` IN (SELECT `id` FROM `reg_users` WHERE `member_group_id` = '%d')", $group_id );
                    $ipTV_db->query( "DELETE FROM `reg_users` WHERE `member_group_id` = '%d'", $group_id );
                    $ok_message = "Selected Group completely removed!";
                }
                else
                {
                    $warn_message = $_LANG['cant_delete_group'];
                }
            }
            break;

        case "new":
            if ( ! empty( ipTV_lib::$request['group_name'] ) && ! empty( ipTV_lib::$request['group_color'] ) )
            {
                $group_name = ipTV_lib::$request['group_name'];
                $group_color = ipTV_lib::$request['group_color'];

                $is_admin = ( empty( ipTV_lib::$request['is_admin'] ) || ipTV_lib::$request['is_admin'] <= 0 ) ? 0 : 1;
                $is_banned = ( empty( ipTV_lib::$request['is_banned'] ) || ipTV_lib::$request['is_banned'] <= 0 ) ? 0 : 1;

                if ( ! RowExists( "member_groups", "group_name", $group_name ) )
                {
                    $ipTV_db->query( "INSERT INTO `member_groups` (`group_name`,`group_color`,`is_banned`,`is_admin`,`can_delete`) VALUES('%s','%s','%d','%d',1)", $group_name, $group_color, $is_banned, $is_admin );

                    $ok_message = $_LANG['group_added'];
                }
                else
                {
                    $warn_message = $_LANG['group_exists'];
                }
            }
            else
            {
                $warn_message = $_LANG['complete_fields'];
            }
            break;

    }
}

$member_groups = GetMemberGroups();

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'mng_groups.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
