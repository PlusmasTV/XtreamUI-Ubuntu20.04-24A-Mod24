<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

$bouquet_id = false;
if ( ! empty( ipTV_lib::$request['bouquet_id'] ) && is_numeric( ipTV_lib::$request['bouquet_id'] ) )
{
    $bouquet_id = ipTV_lib::$request['bouquet_id'];

    if ( ! RowExists( "bouquets", "id", $bouquet_id ) )
    {
        $er_message = $_LANG['bouquet_id_nexists'];
    }
    else
    {
        $info = GetBouquetInfo( $bouquet_id );
        if ( isset( ipTV_lib::$request['action'] ) )
        {
            $action = ipTV_lib::$request['action'];
            unset( ipTV_lib::$request['action'] );
            switch ( $action )
            {
                case "edit_bouquet":
                    if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['bouquet_name'] ) && ! empty( ipTV_lib::$request['bouquet_selection'] ) )
                    {

                            $bouquet_name = ipTV_lib::$request['bouquet_name'];
                            $bouquet = ipTV_lib::$request['bouquet_selection'];

                            if ( $info['bouquet_name'] == $bouquet_name || ! RowExists( "bouquets", "bouquet_name", $bouquet_name ) )
                            {
                                $bouquet = array_unique( $bouquet );

                                $bouquet_import = array();
                                foreach ( $bouquet as $key => $id )
                                {
                                    if ( ! is_numeric( $id ) )
                                    {
                                        continue;
                                    }

                                    if ( RowExists( "streams", "id", $id ) && ! in_array( $bouquet_import, $id ) )
                                    {
                                        array_push( $bouquet_import, $id );
                                    }
                                }

                                $ipTV_db->query( "UPDATE `bouquets` SET `bouquet_name` = '%s',`bouquet_channels` = '%s' WHERE `id` = '%d'", $bouquet_name, serialize( $bouquet_import ), $bouquet_id );
                                $ok_message = $_LANG['bouquet_edited'];

                            }
                            else
                            {
                                $warn_message = $_LANG['bouquet_exists'];
                            }
                        
                    }
                    else
                    {
                        $warn_message = $_LANG['complete_fields'];
                    }

                    break;

            }
        }

        $info = GetBouquetInfo( $bouquet_id );
        $streams = GetStreams( null, 'stream_display_name', 'ASC' );
    }
}
else
{
    $er_message = $_LANG['select_bouquet_page'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'edit_bouquet.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>