<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}
if ( ipTV_lib::IsDemo() )
{
    $er_message = "You can't add Movies to DEMO Version";
}
else
{
    if ( isset( ipTV_lib::$request['action'] ) )
    {
        $action = ipTV_lib::$request['action'];
        unset( ipTV_lib::$request['action'] );
        switch ( $action )
        {
            case "import_movies":

                if ( count( ipTV_lib::$request ) > 0 )
                {
                    
                        $movie_location = ( ipTV_lib::$request['movie_location'] == "local" ) ? "local" : "remote";
                        $movie_source = ( $movie_location == 'local' ) ? ipTV_lib::$request['movie_source_local'] : ipTV_lib::$request['movie_source_remote'];

                        $movie_extensions = array(
                            'mkv',
                            'flv',
                            'mov',
                            'qt',
                            'mpg',
                            'mpeg',
                            'mpv2',
                            'mpe',
                            'mpa',
                            'mp2',
                            'mp4',
                            'asf',
                            'asr',
                            'asx',
                            'avi' );

                        if ( ! empty( $movie_source ) )
                        {
                            set_time_limit( 0 );

                            if ( $movie_location == 'local' )
                            {

                                if ( is_dir( $movie_source ) )
                                {


                                    $movies = getFileList( $movie_source, $movie_extensions );

                                    $added = array();
                                    $failed = array();
                                    $movies_no_permissions = array();
                                    foreach ( $movies as $movie )
                                    {
                                        $movie = str_replace( '//', '/', $movie );

                                        if ( is_writeable( $movie ) )
                                        {
                                            $return = ipTV_Stream::StartMovie( pathinfo( $movie, PATHINFO_FILENAME ), $movie, null, false, 'local', false );

                                            if ( is_bool( $return ) )
                                            {
                                                $added[] = $movie;
                                            }
                                            else
                                            {
                                                $failed[] = $movie;
                                            }
                                        }
                                        else
                                        {
                                            $movies_no_permissions[] = $movie;
                                        }
                                    }


                                    $ok_message = str_replace( array(
                                        '{added}',
                                        '{failed}',
                                        '{no_perm}' ), array(
                                        count( $added ),
                                        count( $failed ),
                                        count( $movies_no_permissions ) ), $_LANG['movies_multiple_imported'] );
                                }
                                else
                                {
                                    $warn_message = $_LANG['its_not_dir'];
                                }
                            }
                            else
                            {
                                $source = @file_get_contents( $movie_source );

                                if ( ! empty( $source ) )
                                {
                                    if ( preg_match_all( "<a href='(.*?)'>", $source, $matches ) )
                                    {
                                        $added = array();
                                        $failed = array();

                                        foreach ( $matches[1] as $movie_file )
                                        {
                                            $extension = strtolower( pathinfo( $movie_file, PATHINFO_EXTENSION ) );

                                            if ( ! in_array( $extension, $movie_extensions ) )
                                            {
                                                continue;
                                            }

                                            $return = ipTV_Stream::StartMovie( pathinfo( $movie_file, PATHINFO_FILENAME ), $movie_source . '/' . $movie_file, null, false, 'remote', false, null );

                                            if ( is_bool( $return ) )
                                            {
                                                $added[] = $movie_source . '/' . $movie_file;
                                            }
                                            else
                                            {
                                                $failed[] = $movie_source . '/' . $movie_file;
                                            }
                                        }

                                        if ( ! empty( $added ) || ! empty( $failed ) )
                                        {
                                            $ok_message = str_replace( array(
                                                '{added}',
                                                '{failed}',
                                                '{no_perm}' ), array(
                                                count( $added ),
                                                count( $failed ),
                                                0 ), $_LANG['movies_multiple_imported'] );
                                        }
                                        else
                                        {
                                            $warn_message = $_LANG['no_remote_movies_found'];
                                        }

                                    }
                                    else
                                    {
                                        $warn_message = $_LANG['no_remote_movies_found'];
                                    }
                                }
                                else
                                {
                                    $warn_message = $_LANG['unable_open_url'];
                                }
                            }
                        }
                        else
                        {

                            $warn_message = $_LANG['complete_fields'];
                        }
                    
                }
                else
                {
                    $warn_message = $_LANG['complete_fields'];
                }
                break;
        }
    }
}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'import_movies.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
