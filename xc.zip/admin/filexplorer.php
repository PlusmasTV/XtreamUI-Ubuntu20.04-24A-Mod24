<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( ipTV_lib::IsDemo() )
{
    exit;
}


$_POST['dir'] = urldecode( $_POST['dir'] );

if ( file_exists( $_POST['dir'] ) )
{
    $files = scandir( $_POST['dir'] );
    natcasesort( $files );
    if ( count( $files ) > 2 )
    { // The 2 accounts for . and ..
        echo "<ul class=\\"jqueryFileTree\\" style=\\"display: none;\\">";
        // All dirs
        foreach ( $files as $file )
        {
            if ( file_exists( $_POST['dir'] . $file ) && $file != '.' && $file != '..' && is_dir( $_POST['dir'] . $file ) )
            {
                echo "<li class=\\"directory collapsed\\"><a href=\\"#\\" rel=\\"" . htmlentities( $_POST['dir'] . $file ) . "/\\">" . htmlentities( $file ) . "</a></li>";
            }
        }
        // All files
        foreach ( $files as $file )
        {
            if ( file_exists( $_POST['dir'] . $file ) && $file != '.' && $file != '..' && ! is_dir( $_POST['dir'] . $file ) )
            {
                $ext = preg_replace( '/^.*\\./', '', $file );
                echo "<li class=\\"file ext_$ext\\"><a href=\\"#\\" rel=\\"" . htmlentities( $_POST['dir'] . $file ) . "\\">" . htmlentities( $file ) . "</a></li>";
            }
        }
        echo "</ul>";
    }
}

?>
