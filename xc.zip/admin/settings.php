<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "save":

            if ( count( ipTV_lib::$request ) > 1 )
            {
                if ( isset( ipTV_lib::$request['site_url'] ) )
                {
                    $url = ipTV_lib::$request['site_url'];
                    if ( stristr( $url, "http://" ) )
                    {
                        $url = str_ireplace( "http://", "", $url );
                    }

                    if ( substr( $url, -1 ) == '/' )
                    {
                        $url = substr( $url, 0, -1 );
                    }

                    ipTV_lib::$request['site_url'] = $url;
                }

                if ( isset( ipTV_lib::$request['movies_path'] ) )
                {
                    if ( substr( ipTV_lib::$request['movies_path'], -1 ) == '/' )
                    {
                        ipTV_lib::$request['movies_path'] = substr( ipTV_lib::$request['movies_path'], 0, -1 );
                    }

                    $movies_path = ipTV_lib::$request['movies_path'];

                    if ( $movies_path != ipTV_lib::$settings['movies_path'] )
                    {

                        //movie on progress
                        $ffmpeg_run = intval( trim( shell_exec( "ps aux | grep -v grep | grep -c " . FFMPEG_PATH ) ) );


                        if ( $ffmpeg_run > 0 )
                        {
                            $warn_message = $_LANG['movies_in_progress'];
                        }
                        else
                        {
                            if ( ! file_exists( $movies_path ) )
                            {
                                if ( ! mkdir( $movies_path ) )
                                {
                                    $warn_message = $_LANG['movies_path_mkdir_false'];
                                    ipTV_lib::$request['movies_path'] = ipTV_lib::$settings['movies_path'];
                                }
                            }
                            else
                            {
                                if ( is_file( $movies_path ) )
                                {
                                    $warn_message = $_LANG['movies_path_is_file'];
                                    ipTV_lib::$request['movies_path'] = ipTV_lib::$settings['movies_path'];
                                }
                            }

                            if ( empty( $warn_message ) )
                            {
                                exec( "mv " . ipTV_lib::$settings['movies_path'] . "/* " . ipTV_lib::$request['movies_path'] );
                            }
                        }
                    }

                }

                foreach ( ipTV_lib::$request as $setting_key => $setting_value )
                {
                    $ipTV_db->query( "UPDATE `settings` SET `%s` = '%s' WHERE `id` = 1", $setting_key, $setting_value );
                }

                $ok_message = $_LANG['settings_saved'];
            }
            break;
    }
}

ipTV_lib::GetSettings();

$network_interfaces = trim( shell_exec( "ls -1 /sys/class/net" ) );
$network_interfaces = explode( "\
", $network_interfaces );
$network_interfaces = array_map( "trim", $network_interfaces );

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'settings.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
@eval( ' ?> ' . $template . ' <?php ' );

?>
