<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "add":
            if ( ! empty( ipTV_lib::$request['category_name'] ) && ! empty( ipTV_lib::$request['category_type'] ) )
            {
                $category_name = ipTV_lib::$request['category_name'];
                $category_type = ipTV_lib::$request['category_type'];

                if ( ! RowExists( "stream_categories", "category_name", $category_name ) )
                {
                    $ipTV_db->query( "INSERT INTO `stream_categories` (`category_type`,`category_name`) VALUES('%s','%s')", $category_type, $category_name );

                    $ok_message = $_LANG['category_added'];

                }
                else
                {
                    $warn_message = $_LANG['category_exists'];
                }
            }
            break;

        case "delete":
            if ( ! empty( ipTV_lib::$request['id'] ) )
            {
                $category_id = intval( ipTV_lib::$request['id'] );

                if ( RowExists( "stream_categories", "id", $category_id ) )
                {
                    $ipTV_db->query( "DELETE FROM `stream_categories` WHERE `id` = '%d'", $category_id );
                    $ipTV_db->query( "UPDATE `streams` SET `category_id` = NULL WHERE `category_id` = '%d'", $category_id );
                    $ok_message = $_LANG['category_deleted'];
                }
            }
            break;

    }
}

$categories = GetCategories();

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'categories.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
