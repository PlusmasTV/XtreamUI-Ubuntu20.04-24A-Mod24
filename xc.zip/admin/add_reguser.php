<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "add_user":
            if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['username'] ) && ! empty( ipTV_lib::$request['password'] ) && ! empty( ipTV_lib::$request['email'] ) && ! empty( ipTV_lib::$request['member_group_id'] ) )
            {

                    $username = ipTV_lib::$request['username'];
                    $password = ipTV_lib::$request['password'];
                    $email = ipTV_lib::$request['email'];
                    $member_group_id = intval( ipTV_lib::$request['member_group_id'] );


                    if ( ! RowExists( "reg_users", "username", $username ) )
                    {
                        if ( ! RowExists( "reg_users", "email", $email ) )
                        {
                            if ( RowExists( "member_groups", "id", $member_group_id ) )
                            {

                                $ipTV_db->query( "INSERT INTO `reg_users` (`username`,`password`,`email`,`date_registered`,`member_group_id`,`verified`) VALUES ('%s','%s','%s','%d','%d',1)", $username, md5( $password ), $email, time(), $member_group_id );

                                $ok_message = $_LANG['new_regadded'];

                            }
                            else
                            {
                                $warn_message = $_LANG['group_not_exists'];
                            }

                        }
                        else
                        {
                            $warn_message = $_LANG['email_in_use'];
                        }

                    }
                    else
                    {
                        $warn_message = $_LANG['username_exists'];
                    }

                
            }
            else
            {
                $warn_message = $_LANG['complete_fields'];
            }

            break;

    }
}

$member_groups = GetMemberGroups();


$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'add_reguser.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
