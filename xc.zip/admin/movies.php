<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "delete":
            if ( ! ipTV_lib::IsDemo() )
            {
                if ( ! empty( ipTV_lib::$request['movie_id'] ) )
                {

                    $movie_id = intval( ipTV_lib::$request['movie_id'] );

                    if ( DeleteStream( $movie_id ) )
                    {
                        $ok_message = $_LANG['movie_deleted'];
                    }
                    else
                    {
                        $warn_message = $_LANG['cant_stop_stream'];
                    }
                }
            }
            else
            {
                $er_message = "You can't add new Movies to DEMO Version";
            }
            break;
    }
}


$movies = GetStreams( 'movie' );
if ( empty( $movies ) )
{
    $er_message = $_LANG['add_some_movies'];
}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'movies.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
