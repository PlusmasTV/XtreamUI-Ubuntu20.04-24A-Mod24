<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "enable":
            if ( ! empty( ipTV_lib::$request['id'] ) )
            {
                $ipTV_db->query( "UPDATE `cronjobs` SET `enabled` = 1 WHERE id = '%d' ", ipTV_lib::$request['id'] );
                crontab_refresh();
                $ok_message = $_LANG['task_enabled'];
            }
            break;

        case "disable":
            if ( ! empty( ipTV_lib::$request['id'] ) )
            {
                $ipTV_db->query( "UPDATE `cronjobs` SET `enabled` = 0 WHERE id = '%d' ", ipTV_lib::$request['id'] );
                crontab_refresh();
                $ok_message = $_LANG['task_disabled'];
            }
            break;
    }
}

$cronjobs = GetCronjobs();

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'task_manager.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );

@eval( ' ?> ' . $template . ' <?php ' );

?>
