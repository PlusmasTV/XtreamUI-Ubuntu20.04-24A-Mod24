<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


$user_id = false;
if ( ! empty( ipTV_lib::$request['user_id'] ) && is_numeric( ipTV_lib::$request['user_id'] ) )
{
    $user_id = ipTV_lib::$request['user_id'];

    if ( ! RowExists( "reg_users", "id", $user_id ) )
    {
        $er_message = $_LANG['user_id_nexists'];
    }
    else
    {
        $info = GetRegUserInfo( $user_id );
        if ( isset( ipTV_lib::$request['action'] ) )
        {
            $action = ipTV_lib::$request['action'];
            unset( ipTV_lib::$request['action'] );
            switch ( $action )
            {
                case "edit_user":
                    if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['username'] ) && ! empty( ipTV_lib::$request['email'] ) && ! empty( ipTV_lib::$request['member_group_id'] ) )
                    {
                        
                            $username = ipTV_lib::$request['username'];
                            $password = ( ! empty( ipTV_lib::$request['password'] ) ) ? ipTV_lib::$request['password'] : false;
                            $email = ipTV_lib::$request['email'];
                            $member_group_id = intval( ipTV_lib::$request['member_group_id'] );

                            if ( $info['username'] == $username || ! RowExists( "reg_users", "username", $username ) )
                            {
                                if ( $info['email'] == $email || ! RowExists( "reg_users", "email", $email ) )
                                {
                                    if ( RowExists( "member_groups", "id", $member_group_id ) )
                                    {

                                        $ipTV_db->query( "UPDATE `reg_users` SET `username` = '%s',
                                                                                 `email` = '%s',
                                                                                 `member_group_id` = '%d'
                                                                                 WHERE `id` = '%d'", $username, $email, $member_group_id, $user_id );


                                        if ( $password !== false )
                                        {
                                            $ipTV_db->query( "UPDATE `reg_users` SET `password` = '%s' WHERE `id` = '%d'", md5( $password ), $user_id );
                                        }

                                        $ok_message = $_LANG['reg_user_edited'];

                                    }
                                    else
                                    {
                                        $warn_message = $_LANG['group_not_exists'];
                                    }

                                }
                                else
                                {
                                    $warn_message = $_LANG['email_in_use'];
                                }

                            }
                            else
                            {
                                $warn_message = $_LANG['username_exists'];
                            }


                    }
                    else
                    {
                        $warn_message = $_LANG['complete_fields'];
                    }

                    break;
            }
        }
        $info = GetRegUserInfo( $user_id );
        $member_groups = GetMemberGroups();
    }
}
else
{
    $er_message = $_LANG['select_reguser'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'edit_reguser.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
