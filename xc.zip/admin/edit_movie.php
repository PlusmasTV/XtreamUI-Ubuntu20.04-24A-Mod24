<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( ipTV_lib::IsDemo() )
{
    $er_message = "You can't edit Movies to DEMO Version";
}
else
{
    $movie_id = false;
    if ( ! empty( ipTV_lib::$request['movie_id'] ) && is_numeric( ipTV_lib::$request['movie_id'] ) )
    {
        $movie_id = ipTV_lib::$request['movie_id'];

        if ( ! RowExists( "streams", "id", $movie_id ) )
        {
            $er_message = $_LANG['movie_id_nexists'];
        }
        else
        {
            $categories = ( empty( $categories ) ) ? GetCategories( 'movie' ) : $categories;
            $info = GetStreamInfo( $movie_id );
            if ( isset( ipTV_lib::$request['action'] ) )
            {
                $action = ipTV_lib::$request['action'];
                unset( ipTV_lib::$request['action'] );
                switch ( $action )
                {
                    case "edit_movie":
                        if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['movie_name'] ) )
                        {


                                $movie_name = ipTV_lib::$request['movie_name'];
                                $category_id = ( ! empty( ipTV_lib::$request['category_id'] ) ) ? intval( ipTV_lib::$request['category_id'] ) : null;

                                if ( $info['stream_display_name'] == $movie_name || ! RowExists( "streams", "stream_display_name", $movie_name ) )
                                {
                                    $ipTV_db->query( "UPDATE `streams` SET `stream_display_name` = '%s' WHERE `id` = '%d'", $movie_name, $movie_id );

                                    if ( is_null( $category_id ) || ! RowExists( "stream_categories", "id", $category_id ) )
                                    {
                                        $ipTV_db->query( "UPDATE `streams` SET `category_id` = NULL WHERE `id` = '%d'", $movie_id );
                                    }
                                    else
                                    {
                                        $ipTV_db->query( "UPDATE `streams` SET `category_id` = '%d' WHERE `id` = '%d'", $category_id, $movie_id );
                                    }

                                    exec( "mv " . MOVIES_PATH . ipTV_Stream::GetFixedStreamName( $info['stream_display_name'] ) . " " . MOVIES_PATH . ipTV_Stream::GetFixedStreamName( $movie_name ) . "" );
                                    $ok_message = $_LANG['movie_edited'];


                                }
                                else
                                {
                                    $warn_message = $_LANG['stream_exists'];
                                }

                            
                        }
                        else
                        {
                            $warn_message = $_LANG['complete_fields'];
                        }

                        break;

                }
            }
            $info = GetStreamInfo( $movie_id );
        }
    }
    else
    {
        $er_message = $_LANG['select_movie_edit'];
    }

}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'edit_movie.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
