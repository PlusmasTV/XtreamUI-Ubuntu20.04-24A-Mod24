<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


$show = array(
    "restreamers",
    "streamers",
    "show_all" );

$selected_show = "show_all";

if ( ! empty( ipTV_lib::$request['show'] ) )
{
    if ( in_array( ipTV_lib::$request['show'], $show ) )
    {
        $selected_show = ipTV_lib::$request['show'];
    }
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {

        case "user_delete":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                $ipTV_db->query( "DELETE FROM `reg_users` WHERE `id` = '%d'", $user_id );
                $ipTV_db->query( "DELETE FROM `users` WHERE `member_id` = '%d'", $user_id );
                $ok_message = $_LANG['userlines_deleted'];

            }
            break;
    }
}


$registered_users = GetRegUsers();
if ( empty( $registered_users ) )
{
    $warn_message = $_LANG['no_regusers_found'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'mng_regusers.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
