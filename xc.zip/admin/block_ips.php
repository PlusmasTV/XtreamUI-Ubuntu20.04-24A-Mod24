<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "block":
            if ( ! empty( ipTV_lib::$request['ip'] ) )
            {
                $ip = ipTV_lib::$request['ip'];

                if ( inet_pton( $ip ) !== false )
                {
                    $notes = ( ! empty( ipTV_lib::$request['notes'] ) ) ? ipTV_lib::$request['notes'] : "";

                    if ( ! RowExists( "blocked_ips", "ip", $ip ) )
                    {
                        $ipTV_db->query( "INSERT INTO `blocked_ips` (`ip`,`notes`,`date`) VALUES('%s','%s','%d')", $ip, $notes, time() );

                        $ok_message = $_LANG['ip_blocked'];
                    }
                    else
                    {
                        $warn_message = $_LANG['ip_exists'];
                    }
                }
                else
                {
                    $warn_message = $_LANG['invalid_ip'];
                }
            }
            break;

        case "unblock":

            if ( ! empty( ipTV_lib::$request['id'] ) )
            {
                $id_ip = intval( ipTV_lib::$request['id'] );

                if ( RowExists( "blocked_ips", "id", $id_ip ) )
                {
                    $ipTV_db->query( "DELETE FROM `blocked_ips` WHERE `id` = '%d'", $id_ip );
                    $ok_message = $_LANG['ip_unblocked'];
                }
            }
            break;

    }
}

$blocked_ips = GetBlockedIPs();

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'block_ips.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>