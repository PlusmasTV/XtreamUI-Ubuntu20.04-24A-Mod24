<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


$show = array(
    "restreamers",
    "streamers",
    "show_all" );

$selected_show = "show_all";

if ( ! empty( ipTV_lib::$request['show'] ) )
{
    if ( in_array( ipTV_lib::$request['show'], $show ) )
    {
        $selected_show = ipTV_lib::$request['show'];
    }
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "user_enable":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );

                $ipTV_db->query( "UPDATE `users` SET `status` = 1 WHERE `id` = '%d'", $user_id );
                $ok_message = $_LANG['user_enabled'];
            }
            break;

        case "user_disable":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );

                $ipTV_db->query( "UPDATE `users` SET `status` = 0 WHERE `id` = '%d'", $user_id );
                kick_user( $user_id );
                $ok_message = $_LANG['user_disabled'];
            }
            break;


        case "kill_activity":
            if ( ! empty( ipTV_lib::$request['activity_id'] ) )
            {
                $activity_id = intval( ipTV_lib::$request['activity_id'] );
                kick_activity( $activity_id );
                $ok_message = $_LANG['connection_killed'];
            }
            break;

        case "del_activity":
            if ( ! empty( ipTV_lib::$request['activity_id'] ) )
            {
                $activity_id = intval( ipTV_lib::$request['activity_id'] );
                kick_activity( $activity_id );
                $ipTV_db->query( "DELETE FROM `user_activity` WHERE `id` = '%d'", $activity_id );
                $ok_message = $_LANG['connection_delete'];
            }
            break;


        case "user_activity":
            $output = $_LANG['no_activity_found'];
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );

                if ( RowExists( "users", "id", $user_id ) )
                {

                    $ipTV_db->query( "SELECT t1.pid,t1.bandwidth,t1.date_end,t1.id,t1.stream_id,t1.user_ip,t1.user_agent,t1.date_start,t2.stream_display_name,IF(t1.`date_end` IS NULL, 0, 1) AS status FROM `user_activity` t1,`streams` t2 WHERE t1.user_id = '%d' AND t1.stream_id = t2.id ORDER BY status ASC,t1.id DESC", $user_id );

                    if ( $ipTV_db->num_rows() > 0 )
                    {
                        $activities = $ipTV_db->get_rows();
                       
                        $output = "<table class='constable' style='width:1000px;' > 
                                   <thead><tr>
                                        <th>{$_LANG['connection']}</th>
                                        <th>{$_LANG['channel']}</th>
                                        <th>{$_LANG['ip']}</th>
                                        <th>{$_LANG['flag']}</th>
                                        <th>{$_LANG['user_agent']}</th>
                                        <th>{$_LANG['date_started']}</th>
                                        <th>{$_LANG['date_end']}</th>
                                        <th>{$_LANG['total_time_online']}</th>
                                        <th>{$_LANG['bandwidth']}</th>
                                        <th>{$_LANG['options']}</th>
                                   </tr></thead><tbody>";

                        foreach ( $activities as $activity )
                        {
                            $active = false;

                            $output .= "<tr>";
                            if(is_null($activity['pid']))
                            {
                                $color = "FFD6CC";
                                $output .= "<td bgcolor='#$color'><b>{$_LANG['closed']}</b></td>"; 
                            }
                            elseif(ps_running($activity['pid']))
                            {
                                $color = "E0FFD6";
                                $output .= "<td bgcolor='#$color'><b>{$_LANG['opened']}</b></td>"; 
                            }
                            else
                            {
                                $color = "EBD6EB";
                                $output .= "<td bgcolor='#$color'><b>{$_LANG['closed_unex']}</b></td>";  
                            }

                            $output .= "<td bgcolor='#$color'>{$activity['stream_display_name']}</td>";
                            $output .= "<td bgcolor='#$color'>{$activity['user_ip']}</td>";

                            $country = strtoupper( geoip_country_code_by_name( $activity['user_ip'] ) );
                            $country_img = "<img src='../templates/images/flags_country/unknown.png' title='{$_LANG['unknown']}'>";

                            if ( @$country )
                            {
                                $country_img = "<img src='../templates/images/flags_country/$country.png' title='$country' />";
                            }

                            $output .= "<td bgcolor='#$color'>$country_img</td>";

                            $output .= "<td bgcolor='#$color'>{$activity['user_agent']}</td>";
                            $output .= "<td bgcolor='#$color'>" . date( "j F, Y, H:i:s", $activity['date_start'] ) . "</td>";
                            if ( is_null( $activity['date_end'] ) )
                            {

                                $output .= "<td bgcolor='#$color'><font color='orange'>{$_LANG['still_watching']}</font></td>";
                                $output .= "<td bgcolor='#$color'><font color='blue'>" . gmdate( "H:i:s", time() - $activity['date_start'] ) . " +</font></td>";
                                $output .= "<td bgcolor='#$color'><font color='blue'>{$_LANG['waiting']}</font></td>";
                            }
                            else
                            {
                                $output .= "<td bgcolor='#$color'>" . date( "j F, Y, H:i:s", $activity['date_end'] ) . "</td>";
                                $output .= "<td bgcolor='#$color'>" . gmdate( "H:i:s", $activity['date_end'] - $activity['date_start'] ) . "</td>";
                                $output .= "<td bgcolor='#$color'>" . formatBytes( $activity['bandwidth'], 2 ) . "</td>";
                            }


                            $output .= "<td bgcolor='#$color'>";

                            if ( $active === true )
                            {
                                $output .= "<a target='_blank' href='users.php?action=kill_activity&activity_id={$activity['id']}' class='table-icon kill' title='{$_LANG['kill_connection']}'></a>";

                            }
                            $output .= "<a target='_blank' onclick='return confirm('{$_LANG['kill_con']}')' href='users.php?action=del_activity&activity_id={$activity['id']}' class='table-icon delete' title='{$_LANG['delete_activity']}'></a></td>";
                            $output .= "</tr>";
                        }
                        $output .= "</tbody></table>";
                    }

                    echo $output;
                    exit;
                }
            }

            echo $output;
            exit;
            break;
        case "user_kick":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                kick_user( $user_id );
                $ok_message = $_LANG['user_kicked'];
            }
            break;

        case "user_delete":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                $ipTV_db->query( "DELETE FROM `users` WHERE `id` = '%d'", $user_id );
                kick_user( $user_id );
                $ok_message = $_LANG['user_deleted'];

            }
            break;


        case "generate_script":
            if ( ! empty( ipTV_lib::$request['user_id'] ) && ! empty( ipTV_lib::$request['type'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                $type = ipTV_lib::$request['type'];

                $data = GenerateScript( $user_id, $type, true );
            }

            break;
        case "download_list":
            if ( ! empty( ipTV_lib::$request['user_id'] ) && ! empty( ipTV_lib::$request['type'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                $type = ipTV_lib::$request['type'];

                $data = GenerateList( $user_id, $type, true );
            }
            break;

    }
}


$users = GetUsers( $selected_show );
if ( empty( $users ) )
{
    $warn_message = $_LANG['no_streaming_lines_found'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'users.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
