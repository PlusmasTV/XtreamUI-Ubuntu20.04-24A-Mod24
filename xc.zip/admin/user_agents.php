<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "block":
            if ( ! empty( ipTV_lib::$request['user_agent'] ) )
            {
                $user_agent = ipTV_lib::$request['user_agent'];
                $exact_match = ( ! empty( ipTV_lib::$request['exact_match'] ) && ipTV_lib::$request['exact_match'] == 1 ) ? 1 : 0;
                $block_line = ( ! empty( ipTV_lib::$request['block_line'] ) && ipTV_lib::$request['block_line'] == 1 ) ? 1 : 0;


                $ipTV_db->query( "INSERT INTO `blocked_user_agents` (`user_agent`,`exact_match`,`block_line`) VALUES('%s','%s','%d')", $user_agent, $exact_match, $block_line);

                $ok_message = $_LANG['user_agent_blocked'];

            }
            break;

        case "unblock":

            if ( ! empty( ipTV_lib::$request['id'] ) )
            {
                $id_ua = intval( ipTV_lib::$request['id'] );

                if ( RowExists( "blocked_user_agents", "id", $id_ua ) )
                {
                    $ipTV_db->query( "DELETE FROM `blocked_user_agents` WHERE `id` = '%d'", $id_ua );
                    $ok_message = $_LANG['user_agent_unblocked'];
                }
            }
            break;

    }
}

$user_agents = GetBlockedUserAgents();

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'user_agents.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
