<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


$user_id = false;
if ( ! empty( ipTV_lib::$request['user_id'] ) && is_numeric( ipTV_lib::$request['user_id'] ) )
{
    $user_id = ipTV_lib::$request['user_id'];

    if ( ! RowExists( "users", "id", $user_id ) )
    {
        $er_message = $_LANG['line_nexists'];
    }
    else
    {
        $info = GetUserInfo( $user_id );
        $registered_users = GetRegUsers();
        if ( isset( ipTV_lib::$request['action'] ) )
        {
            $action = ipTV_lib::$request['action'];
            unset( ipTV_lib::$request['action'] );
            switch ( $action )
            {
                case "edit_user":
                    if ( count( ipTV_lib::$request ) > 0 && ! empty( ipTV_lib::$request['username'] ) && ! empty( ipTV_lib::$request['password'] ) && ! empty( ipTV_lib::$request['bouquet_selection'] ) )
                    {

                        $username = str_replace( ' ', '', ipTV_lib::$request['username'] );
                        $password = str_replace( ' ', '', ipTV_lib::$request['password'] );
                        $max_connections = ( empty( ipTV_lib::$request['max_connections'] ) ) ? 0 : intval( abs( ipTV_lib::$request['max_connections'] ) );
                        $allowed_bandwidth = ( empty( ipTV_lib::$request['allowed_bandwidth'] ) ) ? 0 : intval( abs( ipTV_lib::$request['allowed_bandwidth'] ) );
                        $expire_date = strtotime( ipTV_lib::$request['expire_date'] );
                        $notes = ipTV_lib::$request['notes'];
                        $bouquet = intval( ipTV_lib::$request['bouquet_selection'] );
                        $is_restreamer = ( empty( ipTV_lib::$request['is_restreamer'] ) || ipTV_lib::$request['is_restreamer'] <= 0 ) ? 0 : 1;

                        $member_id = ( empty( ipTV_lib::$request['member_id'] ) ) ? $info['member_id'] : intval( ipTV_lib::$request['member_id'] );

                        $allowed_ips = ( empty( ipTV_lib::$request['allowed_ips'] ) ) ? array() : ipTV_lib::$request['allowed_ips'];

                        if ( RowExists( "reg_users", "id", $member_id ) )
                        {
                            if ( ! is_array( $allowed_ips ) )
                            {
                                $allowed_ips = array();
                            }
                            else
                            {
                                $allowed_ips = array_filter( array_unique( $allowed_ips ), 'inet_pton' );
                            }


                            $ipTV_db->query( "UPDATE `users` SET `member_id` = '%d',
                                                             `username` = '%s',
                                                             `password` = '%s',
                                                             `exp_date` = '%d',
                                                             `allowed_bandwidth` = '%d',
                                                             `notes` = '%s',
                                                             `max_connections` = '%d',
                                                             `is_restreamer` = '%d',
                                                             `allowed_ips` = '%s',
                                                             `bouquet` = '%d' WHERE `id` = '%d'", $member_id, $username, $password, $expire_date, $allowed_bandwidth, $notes, $max_connections, $is_restreamer, serialize( $allowed_ips ), $bouquet, $user_id );

                            $ok_message = $_LANG['user_edited'];
                        }
                        else
                        {
                            $warn_message = $_LANG['member_not_exists'];
                        }
                    }
                    else
                    {
                        $warn_message = $_LANG['complete_fields'];
                    }

                    break;

            }
        }
        $info = GetUserInfo( $user_id );
        $bouquets = GetBouquets();
    }
}
else
{
    $er_message = $_LANG['select_line_mng'];
}

$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'edit_user.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );
eval( ' ?> ' . $template . ' <?php ' );

?>
