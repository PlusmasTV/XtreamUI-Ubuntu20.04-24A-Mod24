<?php

/**
 * @package ipTV Panel
 * @authors\tXtream-Codes
 */

session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}

if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "delete_stream_logs":
            $ipTV_db->query( "DELETE FROM `logs`" );
            $ok_message = $_LANG['stream_logs_deleted'];
            break;
        case "delete_closed_connections":
            $ipTV_db->query( "DELETE FROM `user_activity` WHERE `pid` = NULL OR `date_end` IS NOT NULL" );
            $ok_message = $_LANG['closed_connections_deleted'];

            break;

        case "delete_connections":
            if ( ! empty( ipTV_lib::$request['seconds'] ) )
            {
                $seconds = intval( trim( ipTV_lib::$request['seconds'] ) );

                $ipTV_db->query( "DELETE FROM `user_activity` WHERE `date_end` IS NOT NULL AND `date_end`-`date_start` <= '%d'", $seconds );
                $ok_message = "All Closed Connections deleted based on the seconds value you provided!";
            }
            break;
        case "kill_active_cons":
            kill_all_activities();
            $ok_message = $_LANG['all_connections_killed'];

            break;

        case "stop_streams":
            if ( ! empty( ipTV_lib::$request['problem_status_in_a_row'] ) )
            {
                $problem_status_in_a_row = intval( ipTV_lib::$request['problem_status_in_a_row'] );

                $ipTV_db->query( "SELECT `id` FROM `streams` WHERE `problem_status_in_a_row` >= %d", $problem_status_in_a_row );

                $closed = 0;
                $streams = ipTV_lib::array_values_recursive( $ipTV_db->get_rows() );

                foreach ( $streams as $stream_id )
                {
                    StreamAction( $stream_id, 'stop', 1 );
                    ++$closed;
                }

                $ok_message = str_replace("{number}",$closed,$_LANG['total_streams_closed_tool']);
            }
            break;
    }
}


$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'tools.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );

@eval( ' ?> ' . $template . ' <?php ' );

?>
