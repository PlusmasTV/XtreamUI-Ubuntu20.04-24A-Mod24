<?php
session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsAdmin() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit( 0 );
}


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "logout":
            logout();
            header( 'Location: ../index.php' );
            exit( 0 );
            break;
        case "information":

            $total_slots = GetTotalConnections( 'total_slots' );
            $total_open = GetTotalConnections( 'open' );

            $json = array();
            $json['cpu'] = intval( GetTotalCPUsage() );
            $temp = memory_usage();


            $json['mem'] = intval( $temp[0]['percent'] );
            //$json['processes'] = TopProcesses( 10 );

            if ( $total_slots != 0 )
                $json['connections'] = ( $total_open / $total_slots ) * 100;
            else
                $json['connections'] = 0;


            $ipTV_db->query( "SELECT COUNT( t1.`id` ) 
            FROM  `users` t1
            WHERE (
            
            SELECT COUNT(  `user_activity`.`id` ) 
            FROM  `user_activity` 
            WHERE ISNULL(  `user_activity`.`date_end` ) 
            AND  `user_activity`.`user_id` =  `t1`.`id`
            ) >0" );

            $json['total_online_users'] = $ipTV_db->get_col();


            $json['live_connections'] = $total_open;


            $ipTV_db->query( "SELECT SUM(`bandwidth`) FROM `user_activity`" );
            $json['total_bandwidth'] = formatBytes( $ipTV_db->get_col(), 2 );

            $ipTV_db->query( "SELECT count(`id`) FROM `user_activity`" );
            $json['total_connections_made'] = $ipTV_db->get_col();

            $json['uptime'] = get_boottime();
            if ( ! $json['uptime'] )
            {
                $json['uptime'] = $_LANG['unknown'];
            }
            else
            {
                $json['uptime'] = "<font color='green' size='1px'>" . $json['uptime'] . "</font>";
            }


            $ipTV_db->query( "SELECT pid FROM `streams` WHERE pid IS NOT NULL" );
            $pids = array_filter( ipTV_lib::array_values_recursive( $ipTV_db->get_rows() ), 'ps_running' );

            $json['total_active_streams'] = count( $pids );

            echo json_encode( $json );
            exit();
            break;
        case "bandwidth":

            $int = ipTV_lib::$settings['network_interface'];

            if ( ! file_exists( "/sys/class/net/$int/statistics/tx_bytes" ) )
            {
                echo json_encode( array( "bytes" => 0 ) );
                exit;
            }

            $bytes_sent_old = trim( file_get_contents( "/sys/class/net/$int/statistics/tx_bytes" ) );
            $bytes_received_old = trim( file_get_contents( "/sys/class/net/$int/statistics/rx_bytes" ) );
            sleep( 1 );
            $bytes_sent_new = trim( file_get_contents( "/sys/class/net/$int/statistics/tx_bytes" ) );
            $bytes_received_new = trim( file_get_contents( "/sys/class/net/$int/statistics/rx_bytes" ) );

            $bytes_old = $bytes_received_old + $bytes_sent_old;
            $bytes_now = $bytes_received_new + $bytes_sent_new;
            $bytes = ( $bytes_now - $bytes_old ) / 1024;
            $bytes = round( $bytes * 0.0078125, 2 );


            $json = array();
            $json['bytes'] = $bytes;

            echo json_encode( $json );
            exit;

            break;


    }
}


if ( isset( $_GET['msg'] ) )
{
    switch ( $_GET['msg'] )
    {
        case "updated":
            crontab_refresh();
            $ok_message = $_LANG['update_done'];
            break;

    }
}

$warn_message = array();
if ( UpdateCheck( true ) )
{
    $warn_message[] = $_LANG['new_version_out'];
}

if ( ipTV_lib::nGinxConfigContain( 'fastcgi_buffering' ) )
{
    $warn_message[] = $_LANG['nginx_buffering_off'];
}

if ( ! file_exists( '/etc/nginx/conf.d/movies.conf' ) )
{
    $warn_message[] = $_LANG['movies_config_nexists'];
}

if ( ! file_exists( VLC_BIN ) )
{
    $warn_message[] = $_LANG['vlc_not_found'];
}

$rtmpdump = trim( shell_exec( "command -v rtmpdump" ) );
if ( empty( $rtmpdump ) )
{
    $warn_message[] = $_LANG['rtmpdump_not_found'];
}

if ( ipTV_lib::IsDemo() )
{
    $warn_message[] = str_replace( "{num}", DEMO_STREAMS, $_LANG['is_demo'] );
}



if ( ! function_exists( "geoip_country_code_by_name" ) )
{
    $warn_message[] = $_LANG['geo_ip_missing'];
}


$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_admin.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/admin/' . 'dashboard.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );

@eval( ' ?> ' . $template . ' <?php ' );

?>
