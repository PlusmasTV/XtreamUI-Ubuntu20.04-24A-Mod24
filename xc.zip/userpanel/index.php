<?php
session_start();

#Include Init File
require("../init.php");

#Access to this page is only visible to admin

if ( ! $mcMember->IsMember() )
{
    $mcMember->logout();
    header( 'Location: ../index.php?error=NO_ADMIN' );
    exit(0);
}


if ( isset( ipTV_lib::$request['action'] ) )
{
    $action = ipTV_lib::$request['action'];
    unset( ipTV_lib::$request['action'] );
    switch ( $action )
    {
        case "logout":
            logout();
            header( 'Location: ../index.php' );
            exit( 0 );
            break;

        case "user_kick":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                if ( LineBelongsTo( $user_id, $mcMember->member_info['id'] ) )
                {
                    kick_user( $user_id );
                    $ok_message = $_LANG['user_kicked'];
                }
            }
            break;

        case "user_enable":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                if ( LineBelongsTo( $user_id, $mcMember->member_info['id'] ) )
                {
                    $ipTV_db->query( "UPDATE `users` SET `status` = 1 WHERE `id` = '%d'", $user_id );
                    $ok_message = $_LANG['user_enabled'];
                }
            }
            break;

        case "user_disable":
            if ( ! empty( ipTV_lib::$request['user_id'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                if ( LineBelongsTo( $user_id, $mcMember->member_info['id'] ) )
                {
                    $ipTV_db->query( "UPDATE `users` SET `status` = 0 WHERE `id` = '%d'", $user_id );
                    kick_user( $user_id );
                    $ok_message = $_LANG['user_disabled'];
                }
            }
            break;

        case "generate_script":
            if ( ! empty( ipTV_lib::$request['user_id'] ) && ! empty( ipTV_lib::$request['type'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                $type = ipTV_lib::$request['type'];

                if ( LineBelongsTo( $user_id, $mcMember->member_info['id'] ) )
                {
                    $data = GenerateScript( $user_id, $type, true );
                }
            }

            break;

        case "download_list":
            if ( ! empty( ipTV_lib::$request['user_id'] ) && ! empty( ipTV_lib::$request['type'] ) )
            {
                $user_id = intval( ipTV_lib::$request['user_id'] );
                $type = ipTV_lib::$request['type'];

                if ( LineBelongsTo( $user_id, $mcMember->member_info['id'] ) )
                {
                    $data = GenerateList( $user_id, $type, true );
                }
            }
            break;
    }
}

$user_lines = GetUserLines( $mcMember->member_info['id'] );

if ( empty( $user_lines ) )
{
    $er_message = $_LANG['no_lines_found'];
}
$template = @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'header_normal.php' );
$template .= file_get_contents( IPTV_TEMPLATES_PATH . '/' . '/userpanel/' . 'mnglines.php' );
$template .= @file_get_contents( IPTV_TEMPLATES_PATH . '/' . 'footer.php' );

@eval( ' ?> ' . $template . ' <?php ' );

?>
