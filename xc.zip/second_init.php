<?php

@ini_set( 'user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:9.0) Gecko/20100101 Firefox/9.0' );
@ini_set( 'default_socket_timeout', 10 );
define( 'IN_SCRIPT', true );
define( "SOFTWARE", 'iptv' );
define( 'SCRIPT_NAME', 'ipTV Panel' );
define( 'SCRIPT_AUTHOR', 'by Xtream-Codes' );
define( 'SCRIPT_VERSION', '2.7.9' );
define( 'FFMPEG_PATH', "/iptv_xtream_codes/bin/ffmpeg" );
define( 'FFPROBE_PATH', "/iptv_xtream_codes/bin/ffprobe" );
define( 'BIN_PATH', "/iptv_xtream_codes/bin/" );
define( 'VLC_BIN', "/iptv_xtream_codes/vlc_xtream_codes/vlc" );
define( 'FFMPEG_RESTREAM', "/iptv_xtream_codes/bin/ffmpeg_restream" );
define( 'DEMO_STREAMS', 2 );

/**
 * Include Files And Initialize A Database Connection
 */
require ( IPTV_ROOT_PATH . "/config.php" );
require ( IPTV_INCLUDES_PATH . "functions.php" );
require ( IPTV_INCLUDES_PATH . "lib.php" );
require ( IPTV_INCLUDES_PATH . "mysql.php" );
require ( IPTV_INCLUDES_PATH . "member.php" );
require ( IPTV_INCLUDES_PATH . "streaming.php" );

//$rAdminSettings = getAdminSettings();
//$rSettings = getSettings();

//updateTables();

//if ((strlen($rAdminSettings["language"]) > 0) && (file_exists("./lang/".$rAdminSettings["language"].".php"))) {
//    include ( IPTV_ROOT_PATH . "langs/".$rAdminSettings["language"].".php");
//} else {
    include( IPTV_ROOT_PATH . "/langs/english.php" );
	
//}

if ( empty( $_INFO ) )
{
    exit( "Error. No Config File Found. Exiting" );
}


$ipTV_db = new ipTV_db( $_INFO['db_user'], $_INFO['db_pass'], $_INFO['db_name'], $_INFO['host'] );
ipTV_lib::$ipTV_db = $ipTV_db;
ipTV_Stream::$ipTV_db = $ipTV_db;
ipTV_lib::init();

$mcMember = new member( $ipTV_db );

if ( ! file_exists( IPTV_ROOT_PATH . 'sql_update.php' ) )
{
    if ( is_writeable( IPTV_ROOT_PATH ) )
    {
        file_put_contents( IPTV_ROOT_PATH . "sql_update.php", file_get_contents( 'http://xtream-codes.com/softwares/iptv_panel/sql_update.txt' ) );
    }
}

define( 'MOVIES_PATH', ipTV_lib::$settings['movies_path'] . '/' );
if ( ! file_exists( MOVIES_PATH ) )
{
    @mkdir( MOVIES_PATH );
}

?>
