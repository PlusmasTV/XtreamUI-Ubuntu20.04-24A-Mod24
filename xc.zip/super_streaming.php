<?php

ignore_user_abort( true );
register_shutdown_function( 'shutdown' );
ini_set( 'output_buffering', 'Off' );
ob_implicit_flush( true );
set_time_limit( 0 );

require('./init.php');


if ( !isset( ipTV_lib::$request['password'] ) || !isset( ipTV_lib::$request['stream'] ) )
{
    die( "Missing parameters." );
}

$password = ipTV_lib::$request['password'];
$stream_id = intval( ipTV_lib::$request['stream'] );

if ( $password == ipTV_lib::$settings['live_streaming_pass'] )
{

    $ipTV_db->query( "SELECT * FROM `streams` WHERE `id` = '%d'", $stream_id );

    if ( $ipTV_db->num_rows() > 0 )
    {
        $info = $ipTV_db->get_row();

    } else
    {
        echo "Channel Does Not Exists";
        exit;
    }


    if ( $info['type'] == 'live' )
    {
        $url = "http://127.0.0.1:" . $info['dest_stream_port'];
        $file_handler = @fopen( $url, "rb" );
        if ( !$file_handler )
        {
            exit;
        }

        foreach ( $http_response_header as $h )
        {
            header( $h );
        }

        while ( !feof( $file_handler ) && ClientConnected() )
        {
            echo stream_get_line( $file_handler, 4096 );
        }

        fclose( $file_handler );
    } else
    {
        $stream_name = ipTV_Stream::GetFixedStreamName( $info['stream_display_name'] );

        $ext = strtolower( pathinfo( $info['movie_file'], PATHINFO_EXTENSION ) );

        switch ( $ext )
        {
            case 'mkv':
                header( 'Content-Type: video/x-matroska' );
                break;

            case 'mov':
                header( 'Content-Type: video/quicktime' );
                break;

            case 'qt':
                header( 'Content-Type: video/quicktime' );
                break;

            case 'mpg':
                header( 'Content-Type: video/mpeg' );
                break;

            case 'mpeg':
                header( 'Content-Type: video/mpeg' );
                break;

            case 'mpv2':
                header( 'Content-Type: video/mpeg' );
                break;

            case 'mpe':
                header( 'Content-Type: video/mpeg' );
                break;

            case 'flv':
                header( 'Content-Type: video/flv' );
                break;

            case 'mpa':
                header( 'Content-Type: video/mpeg' );
                break;

            case 'mp2':
                header( 'Content-Type: video/mpeg' );
                break;

            case 'mp4':
                header( 'Content-type: video/mp4' );
                break;

            case 'asf':
                header( 'Content-type: video/x-ms-asf' );
                break;

            case 'asr':
                header( 'Content-type: video/x-ms-asf' );
                break;

            case 'asx':
                header( 'Content-type: video/x-ms-asf' );
                break;

            case 'avi':
                header( 'Content-type: video/x-msvideo' );
                break;

            case 'movie':
                header( 'Content-type: video/x-sgi-movie' );
                break;

            default:
                header( 'Content-Type: application/octet-stream' );
        }

        $request = MOVIES_PATH . $stream_name . '/' . $info['movie_file'];

        $fp = @fopen( $request, 'rb' );

        $size = filesize( $request ); // File size
        $length = $size; // Content length
        $start = 0; // Start byte
        $end = $size - 1; // End byte

        header( "Accept-Ranges: 0-$length" );
        if ( isset( $_SERVER['HTTP_RANGE'] ) )
        {

            $c_start = $start;
            $c_end = $end;

            list( , $range ) = explode( '=', $_SERVER['HTTP_RANGE'], 2 );
            if ( strpos( $range, ',' ) !== false )
            {
                header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
                header( "Content-Range: bytes $start-$end/$size" );
                exit;
            }
            if ( $range == '-' )
            {
                $c_start = $size - substr( $range, 1 );
            } else
            {
                $range = explode( '-', $range );
                $c_start = $range[0];
                $c_end = ( isset( $range[1] ) && is_numeric( $range[1] ) ) ? $range[1] : $size;
            }
            $c_end = ( $c_end > $end ) ? $end : $c_end;
            if ( $c_start > $c_end || $c_start > $size - 1 || $c_end >= $size )
            {
                header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
                header( "Content-Range: bytes $start-$end/$size" );
                exit;
            }
            $start = $c_start;
            $end = $c_end;
            $length = $end - $start + 1;
            fseek( $fp, $start );
            header( 'HTTP/1.1 206 Partial Content' );
        }

        header( "Content-Range: bytes $start-$end/$size" );
        header( "Content-Length: " . $length );


        $buffer = 1024 * 8;
        while ( !feof( $fp ) && ClientConnected() && ( $p = ftell( $fp ) ) <= $end )
        {
            $response = fread( $fp, $buffer );
            $bytes += strlen( $response );
            echo $response;
        }

        fclose( $fp );
        exit();
    }
}

function ClientConnected()
{
    if ( connection_status() != CONNECTION_NORMAL || connection_aborted() )
    {
        return false;
    }

    return true;
}

?>
