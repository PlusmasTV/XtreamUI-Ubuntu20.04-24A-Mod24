<?php

/**
 * @Author Xtream-Codes.com
 * @Copyright 2014
 * @Title Xtream-Codes.com IPTV Cron User Sync.
 */

if ( ! @$argc )
{
    exit( 0 );
}

require ( str_replace( "\\\\", "/", dirname( $argv[0] ) ) . '/init.php' );


$ipTV_db->query( "SELECT * FROM `users`" );
$users = $ipTV_db->get_rows();
$data = array();
foreach ( $users as $user )
{
    if ( $user['exp_date'] < time() )
    {
        kick_user( $user['id'] );
    }
}

$ipTV_db->query( "SELECT `id`,`pid` FROM `user_activity` WHERE ISNULL(`date_end`)" );
if ( $ipTV_db->num_rows() > 0 )
{
    $connections = $ipTV_db->get_rows();

    foreach ( $connections as $connection )
    {
        if ( ! ps_running( $connection['pid'] ) )
        {
            kick_activity( $connection['id'] );
        }
    }
}

?>

