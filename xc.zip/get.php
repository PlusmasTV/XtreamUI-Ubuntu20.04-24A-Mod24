<?php

require('./init.php');

if ( ! isset( ipTV_lib::$request['username'] ) || ! isset( ipTV_lib::$request['password'] ) || ! isset( ipTV_lib::$request['type'] ) )
{
    die( "Missing parameters." );
}

$username = ipTV_lib::$request['username'];
$password = ipTV_lib::$request['password'];
$type = ipTV_lib::$request['type'];


$ipTV_db->query( "SELECT `id` FROM `users` WHERE `username` = '%s' AND `password` = '%s' LIMIT 1", $username, $password );

if ( $ipTV_db->num_rows() > 0 )
{
    $user_id = $ipTV_db->get_col();
    echo GenerateList( $user_id, $type, true );
}

?>
