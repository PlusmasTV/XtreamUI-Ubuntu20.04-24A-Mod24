<?php 
$_INFO = array(); 
$_INFO['host'] = "localhost"; 
$_INFO['db_user'] = "root"; 
$_INFO['db_pass'] = ""; 
$_INFO['db_name'] = "xoce_iptv"; 

?>