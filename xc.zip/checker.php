<?php

/**
 * @Author Xtream-Codes.com
 * @Copyright 2014
 * @Title Xtream-Codes.com IPTV Stream Checker.
 */

if ( ! @$argc )
{
    exit( 0 );
}

require ( str_replace( "\\\\", "/", dirname( $argv[0] ) ) . '/init.php' );

define( 'IN_CHECKER', true );

$CronJobIdentifier = "/tmp/checker" . GenerateUniqueCode();
$php_bin = sys_var( 'PHP_BIN' );

if ( Is_Running( $CronJobIdentifier ) )
{
    exit( "Already Running\
" );
}


//Inform Xtream-Codes

$ipTV_db->query( "SELECT * FROM `streams` WHERE `pid` IS NOT NULL order by id DESC" );
if ( $ipTV_db->num_rows() > 0 )
{

    $rows = $ipTV_db->get_rows();


    foreach ( $rows as $row )
    {
        echo "Checking: " . $row['stream_display_name'] . "\
";
        switch ( $row['type'] )
        {

            case 'live':
                ipTV_Stream::StreamAnalyze( $row['id'], $php_bin );
                usleep( 340000 );
                break;

            case 'movie':
                if ( ! is_null( $row['pid'] ) && ! ps_running( $row['pid'] ) )
                {
                    //check if stream has been checked
                    $movie_name_fixed = ipTV_Stream::GetFixedStreamName( $row['stream_display_name'] );
                    $movie_file = MOVIES_PATH . $movie_name_fixed . '/' . $row['movie_file'];
                    if ( $codecs = ipTV_Stream::GetCodecs( $movie_file ) )
                    {
                        $ipTV_db->query( "UPDATE `streams` SET `movie_status` = 1,`stream_info` = '%s',`movie_length_secs` = '%d' WHERE `id` = '%s'", json_encode( $codecs ), ipTV_Stream::GetDuration( $movie_file ), $row['id'] );
                    }
                    else
                    {
                        $ipTV_db->query( "UPDATE `streams` SET `movie_status` = 2 WHERE `id` = '%d'", $row['id'] );
                    }

                    $ipTV_db->query( "UPDATE `streams` SET `pid` = NULL WHERE `id` = '%d'", $row['id'] );
                }
                break;
        }
    }
}
@unlink( $CronJobIdentifier );

?>
