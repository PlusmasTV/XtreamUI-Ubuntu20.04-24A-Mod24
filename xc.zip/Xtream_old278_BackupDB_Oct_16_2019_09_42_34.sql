-- MySQL dump 10.13  Distrib 5.5.37, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: xtream_iptv
-- ------------------------------------------------------
-- Server version	5.5.37-0ubuntu0.13.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(39) NOT NULL,
  `notes` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_user_agents`
--

DROP TABLE IF EXISTS `blocked_user_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_user_agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_agent` text NOT NULL,
  `exact_match` int(11) NOT NULL DEFAULT '0',
  `block_line` int(11) NOT NULL DEFAULT '0',
  `attempts_blocked` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_user_agents`
--

LOCK TABLES `blocked_user_agents` WRITE;
/*!40000 ALTER TABLE `blocked_user_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_user_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bouquets`
--

DROP TABLE IF EXISTS `bouquets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bouquets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bouquet_name` text NOT NULL,
  `bouquet_channels` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bouquets`
--

LOCK TABLES `bouquets` WRITE;
/*!40000 ALTER TABLE `bouquets` DISABLE KEYS */;
INSERT INTO `bouquets` VALUES (2,'Turkish-Sport','a:7:{i:0;s:1:\"7\";i:1;s:2:\"13\";i:2;s:1:\"8\";i:3;s:1:\"9\";i:4;s:2:\"12\";i:5;s:2:\"10\";i:6;s:2:\"11\";}'),(3,'Basic Paket','a:2:{i:0;s:2:\"23\";i:1;s:2:\"24\";}');
/*!40000 ALTER TABLE `bouquets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cronjobs`
--

DROP TABLE IF EXISTS `cronjobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cronjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `filename` text NOT NULL,
  `run_per_mins` int(11) NOT NULL DEFAULT '1',
  `enabled` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cronjobs`
--

LOCK TABLES `cronjobs` WRITE;
/*!40000 ALTER TABLE `cronjobs` DISABLE KEYS */;
INSERT INTO `cronjobs` VALUES (1,'User Sync','cron.php',1,1),(2,'Stream Checking','checker.php',1,1);
/*!40000 ALTER TABLE `cronjobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_key` varchar(29) NOT NULL,
  `show_message` tinyint(4) NOT NULL,
  `update_available` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
INSERT INTO `licence` VALUES (1,'eprSR4fMfkB6kYB',1,0);
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `date` text NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=207799 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_groups`
--

DROP TABLE IF EXISTS `member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` text NOT NULL,
  `group_color` varchar(7) NOT NULL DEFAULT '#000000',
  `is_banned` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_groups`
--

LOCK TABLES `member_groups` WRITE;
/*!40000 ALTER TABLE `member_groups` DISABLE KEYS */;
INSERT INTO `member_groups` VALUES (1,'Administrators','#FF0000',0,1,0),(2,'Registered Users','#66FF66',0,0,0),(3,'Banned','#194775',1,0,0);
/*!40000 ALTER TABLE `member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reg_users`
--

DROP TABLE IF EXISTS `reg_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reg_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date_registered` int(11) NOT NULL,
  `verify_key` text,
  `last_login` int(11) DEFAULT NULL,
  `member_group_id` int(11) NOT NULL,
  `verified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_group_id` (`member_group_id`),
  KEY `member_group_id_2` (`member_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reg_users`
--

LOCK TABLES `reg_users` WRITE;
/*!40000 ALTER TABLE `reg_users` DISABLE KEYS */;
INSERT INTO `reg_users` VALUES (1,'admin','5f4dcc3b5aa765d61d8327deb882cf99','test@my-email.com','195.33.237.114',1402437173,NULL,NULL,1,1),(3,'user','ee11cbb19052e40b07aac0ca060c23ee','test@test.de',NULL,1403906899,NULL,NULL,2,1);
/*!40000 ALTER TABLE `reg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bouquet_name` text NOT NULL,
  `site_url` text NOT NULL,
  `live_streaming_pass` text NOT NULL,
  `network_interface` text NOT NULL,
  `email_verify_sub` text NOT NULL,
  `email_verify_cont` text NOT NULL,
  `email_forgot_sub` text NOT NULL,
  `email_forgot_cont` text NOT NULL,
  `mail_from` text NOT NULL,
  `smtp_host` text NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `min_password` int(11) NOT NULL DEFAULT '5',
  `username_strlen` int(11) NOT NULL DEFAULT '15',
  `username_alpha` int(11) NOT NULL DEFAULT '1',
  `allow_multiple_accs` int(11) NOT NULL DEFAULT '0',
  `allow_registrations` int(11) NOT NULL DEFAULT '0',
  `server_name` text NOT NULL,
  `use_remote_smtp` int(11) NOT NULL,
  `smtp_username` text NOT NULL,
  `smtp_password` text NOT NULL,
  `email_new_pass_sub` text NOT NULL,
  `logo_url` text NOT NULL,
  `email_new_pass_cont` text NOT NULL,
  `smtp_from_name` text NOT NULL,
  `confirmation_email` int(11) NOT NULL,
  `smtp_encryption` text NOT NULL,
  `movies_path` varchar(255) NOT NULL,
  `unique_id` text NOT NULL,
  `copyrights_removed` tinyint(4) NOT NULL,
  `copyrights_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'My_Bouquet','myserv.dyndns.tv','N718MA0SDV','venet0','Verify Registration @ {SERVER_NAME}','Hello,<p><br></p><p>Please Click at the following URL to activate your account {VERIFY_LINK}</p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>','Forgot Password @ {SERVER_NAME}','Hello,<p><br></p><p>Someone requested new password @&nbsp;&nbsp;{SERVER_NAME} . To verify this request please click at the following link: {FORGOT_LINK}<br></p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>','test@my-email.com','',0,5,15,1,0,0,'My Streaming Server',0,'','','Your New Password @ {SERVER_NAME}','&#46;&#46;/templates/images/logo.png','Hello,<p><br></p><p>Your New Password is: {NEW_PASSWORD}<br></p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>','',0,'','/iptv_xtream_codes/movies','xtreampanel.dyndns.tv',0,'');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_categories`
--

DROP TABLE IF EXISTS `stream_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_type` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_categories`
--

LOCK TABLES `stream_categories` WRITE;
/*!40000 ALTER TABLE `stream_categories` DISABLE KEYS */;
INSERT INTO `stream_categories` VALUES (1,'live','General Streams'),(2,'movie','General Movies'),(3,'movie','Turkish Movies'),(5,'movie','XXX Movies'),(6,'movie','Bollywood Movies'),(7,'movie','Horror Movies'),(8,'movie','Action Movies'),(9,'live','Sport Streams'),(10,'live','News Streams'),(11,'live','Movie Streams');
/*!40000 ALTER TABLE `stream_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_mux`
--

DROP TABLE IF EXISTS `stream_mux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_mux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mux_name` text NOT NULL,
  `mux_code` text NOT NULL,
  `mux_header` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_mux`
--

LOCK TABLES `stream_mux` WRITE;
/*!40000 ALTER TABLE `stream_mux` DISABLE KEYS */;
INSERT INTO `stream_mux` VALUES (1,'Transport Stream [TS]','ts',NULL),(2,'FFmpeg FLV','ffmpeg{mux=flv}','{mime=video/x-flv}'),(3,'VLC FLV','flv','{mime=video/x-flv}');
/*!40000 ALTER TABLE `stream_mux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `stream_display_name` text NOT NULL,
  `stream_source` text,
  `dest_stream_port` int(11) NOT NULL,
  `notes` text,
  `pid` int(11) DEFAULT NULL,
  `problem_status` int(11) NOT NULL DEFAULT '0',
  `stream_info` text,
  `mux_id` int(11) DEFAULT NULL,
  `movie_length_secs` varchar(255) DEFAULT NULL,
  `movie_file` varchar(255) DEFAULT NULL,
  `movie_status` tinyint(4) DEFAULT NULL,
  `stream_started` int(11) DEFAULT NULL,
  `enable_ffmpeg` tinyint(4) NOT NULL DEFAULT '0',
  `ffmpeg_bin` varchar(255) DEFAULT NULL,
  `h264_filter` tinyint(4) NOT NULL DEFAULT '0',
  `enable_rtmpdump` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_options`
--

DROP TABLE IF EXISTS `streams_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `argument_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `argument_id` (`argument_id`),
  KEY `stream_id_2` (`stream_id`),
  KEY `argument_id_2` (`argument_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_options`
--

LOCK TABLES `streams_options` WRITE;
/*!40000 ALTER TABLE `streams_options` DISABLE KEYS */;
INSERT INTO `streams_options` VALUES (1,22,1,'Xtream-Codes IPTV Panel'),(2,22,6,'20000'),(3,22,7,'4000'),(4,22,8,'2000'),(5,23,1,'Xtream-Codes IPTV Panel'),(6,23,6,'20000'),(7,23,7,'4000'),(8,23,8,'2000'),(13,24,1,'Xtream-Codes IPTV Panel'),(14,24,6,'20000'),(15,24,7,'4000'),(16,24,8,'2000'),(17,25,1,'Xtream-Codes IPTV Panel'),(18,25,6,'20000'),(19,25,7,'4000'),(20,25,8,'2000'),(21,26,1,'Xtream-Codes IPTV Panel'),(22,26,6,'20000'),(23,26,7,'4000'),(24,26,8,'2000'),(25,27,1,'Xtream-Codes IPTV Panel'),(26,27,6,'20000'),(27,27,7,'4000'),(28,27,8,'2000'),(29,28,1,'Xtream-Codes IPTV Panel'),(30,28,6,'20000'),(31,28,7,'4000'),(32,28,8,'2000'),(33,29,1,'Xtream-Codes IPTV Panel'),(34,29,6,'20000'),(35,29,7,'4000'),(36,29,8,'2000'),(37,30,1,'Xtream-Codes IPTV Panel'),(38,30,6,'20000'),(39,30,7,'4000'),(40,30,8,'2000'),(41,31,1,'Xtream-Codes IPTV Panel'),(42,31,6,'20000'),(43,31,7,'4000'),(44,31,8,'2000'),(45,32,1,'Xtream-Codes IPTV Panel'),(46,32,6,'20000'),(47,32,7,'4000'),(48,32,8,'2000'),(49,33,1,'Xtream-Codes IPTV Panel'),(50,33,6,'20000'),(51,33,7,'4000'),(52,33,8,'2000'),(53,34,1,'Xtream-Codes IPTV Panel'),(54,34,6,'20000'),(55,34,7,'4000'),(56,34,8,'2000'),(57,35,1,'Xtream-Codes IPTV Panel'),(58,35,6,'20000'),(59,35,7,'4000'),(60,35,8,'2000'),(61,36,1,'Xtream-Codes IPTV Panel'),(62,36,6,'20000'),(63,36,7,'4000'),(64,36,8,'2000'),(65,37,1,'Xtream-Codes IPTV Panel'),(66,37,6,'20000'),(67,37,7,'4000'),(68,37,8,'2000'),(69,38,1,'Xtream-Codes IPTV Panel'),(70,38,6,'20000'),(71,38,7,'4000'),(72,38,8,'2000'),(73,39,1,'Xtream-Codes IPTV Panel'),(74,39,6,'20000'),(75,39,7,'4000'),(76,39,8,'2000'),(77,40,1,'Xtream-Codes IPTV Panel'),(78,40,6,'20000'),(79,40,7,'4000'),(80,40,8,'2000'),(81,41,1,'Xtream-Codes IPTV Panel'),(82,41,6,'20000'),(83,41,7,'4000'),(84,41,8,'2000');
/*!40000 ALTER TABLE `streams_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity`
--

DROP TABLE IF EXISTS `user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `user_agent` text,
  `user_ip` text NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `bandwidth` int(11) NOT NULL DEFAULT '0',
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`stream_id`),
  KEY `pid` (`pid`),
  KEY `date_end` (`date_end`),
  KEY `user_id_2` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity`
--

LOCK TABLES `user_activity` WRITE;
/*!40000 ALTER TABLE `user_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `exp_date` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `notes` text NOT NULL,
  `bouquet` text NOT NULL,
  `max_connections` int(11) NOT NULL DEFAULT '1',
  `allowed_bandwidth` int(11) NOT NULL DEFAULT '0',
  `is_restreamer` tinyint(4) NOT NULL DEFAULT '0',
  `allowed_ips` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,3,'user','user',1422659220,1,'','2',1,0,0,'a:0:{}'),(2,1,'res','res',1430349000,1,'','1',1,0,0,'a:0:{}');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlc_arguments`
--

DROP TABLE IF EXISTS `vlc_arguments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlc_arguments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `argument_name` text NOT NULL,
  `argument_description` text NOT NULL,
  `argument_key` text NOT NULL,
  `argument_default_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlc_arguments`
--

LOCK TABLES `vlc_arguments` WRITE;
/*!40000 ALTER TABLE `vlc_arguments` DISABLE KEYS */;
INSERT INTO `vlc_arguments` VALUES (1,'User Agent','You can use a custom User agent or use a known one',':http-user-agent','Xtream-Codes IPTV Panel'),(2,'Audio Desync','This delays the audio output. The delay must be given in milliseconds. This can be handy if you notice a lag between the video and the audio.','--audio-desync',''),(3,'HTTP Proxy','HTTP proxy to be used It must be of the form http://[user@]myproxy.mydomain:myport/If empty, the http_proxy environment variable will be tried.','--http-proxy',''),(6,'Live Capture Caching','Caching value for cameras and microphones, in milliseconds.','--live-caching','20000'),(7,'Network Caching','Caching value for network resources, in milliseconds.','--network-caching','4000'),(8,'Stream output muxer caching','This allow you to configure the initial caching amount for stream output muxer. This value should be set in milliseconds.','--sout-mux-caching','2000'),(9,'Transcode Video Encoder','This is the video encoder module that will be used (and its associated options).','--sout-transcode-venc',''),(11,'Transcode Destination Video Codec','This is the video codec that will be used.','--sout-transcode-vcodec',''),(12,'Transcode Video Bitrate','Target bitrate of the transcoded video stream.','--sout-transcode-vb',''),(13,'Transcode Video Scaling','Scale factor to apply to the video while transcoding (eg: 0.25)','--sout-transcode-scale',''),(14,'Transcode Video Frame-Rate','Target output frame rate for the video stream.','--sout-transcode-fps',''),(15,'Transcode Video Width','Output video width.',':sout-transcode-width',''),(16,'Transcode Video Height','Output video height.',':sout-transcode-height',''),(17,'Transcode Maximum Video Width','Maximum output video width.','--sout-transcode-maxwidth',''),(18,'Transcode Maximum Video Height','Maximum output video height.','--sout-transcode-maxheight',''),(19,'Transcode Video Filter','Video filters will be applied to the video streams (after overlays are applied). You can enter a colon-separated list of filters.','--sout-transcode-vfilter',''),(20,'Transcode Audio Encoder','This is the audio encoder module that will be used (and its associated options).','--sout-transcode-aenc',''),(21,'Transcode Destination Audio Codec','This is the audio codec that will be used.','--sout-transcode-acodec',''),(22,'Transcode Audio Bitrate','Target bitrate of the transcoded audio stream.','--sout-transcode-ab',''),(23,'Transcode Audio Sample Rate','Sample rate of the transcoded audio stream (11250, 22500, 44100 or 48000).','--sout-transcode-samplerate',''),(24,'Transcode Audio Filter','Audio filters will be applied to the audio streams (after conversion filters are applied). You can enter a colon-separated list of filters.','--sout-transcode-afilter','');
/*!40000 ALTER TABLE `vlc_arguments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-16  9:42:40
