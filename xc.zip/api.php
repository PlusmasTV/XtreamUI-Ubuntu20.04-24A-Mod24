<?php

define('DB_NAME', 'roku');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

// Nos Conectamos
$BD = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
// Check connection
if ($BD->connect_errno) {
  echo "Failed to connect to MySQL: " . $BD->connect_error;
  exit();
}

/*Function to set JSON output*/
function output($Return=array()){
    /*Set response header*/
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    /*Final JSON response*/
    exit(json_encode($Return,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

empty($_GET['lang']) ? $lang = "en" : $lang = $_GET['lang'];

if (isset($_GET["action"])) {
    if ($_GET["action"] == "tmdb_search") {
        include "tmdb.php";
        $rTMDB = new TMDB("46270abd00c39663cde5d450ff83cbb8", $lang);
        $rTerm = $_GET["term"];
        if (isset($_GET["term"])) {
            include "tmdb_release.php";
            $rRelease = new Release($rTerm);
            $rTerm = $rRelease->getTitle();
        } else {
            $rRelease = parseRelease($rTerm);
            $rTerm = $rRelease["title"];
        }
        $rJSON = Array();
        if ($_GET["type"] == "movie") {
            $rResults = $rTMDB->searchMovie($rTerm);
            foreach ($rResults as $rResult) {
                $rJSON[] = json_decode($rResult->getJSON(), True);
            }
        } else if ($_GET["type"] == "series") {
            $rResults = $rTMDB->searchTVShow($rTerm);
            foreach ($rResults as $rResult) {
                $rJSON[] = json_decode($rResult->getJSON(), True);
            }
        } else {
            $rJSON = json_decode($rTMDB->getSeason($rTerm, intval($_GET["season"]))->getJSON(), True);
        }
        if (count($rJSON) > 0) {
            echo output(Array("result" => True, "data" => $rJSON)); exit;
        }
        echo output(Array("result" => False));exit;
    } else if ($_GET["action"] == "tmdb") {
        include "tmdb.php";
        $rTMDB = new TMDB("46270abd00c39663cde5d450ff83cbb8", $lang);
        $rID = $_GET["id"];
        if ($_GET["type"] == "movie") {
            $rMovie = $rTMDB->getMovie($rID);
            $rResult = json_decode($rMovie->getJSON(), True);
            $rResult["trailer"] = $rMovie->getTrailer();
        } else if ($_GET["type"] == "series") {
            $rSeries = $rTMDB->getTVShow($rID);
            $rResult = json_decode($rSeries->getJSON(), True);
            $rResult["trailer"] = getSeriesTrailer($rID);
        }
        if ($rResult) {
            echo output(Array("result" => True, "data" => $rResult)); exit;
        }
        echo output(Array("result" => False));exit;
    }
}
echo output(Array("result" => False));
?>