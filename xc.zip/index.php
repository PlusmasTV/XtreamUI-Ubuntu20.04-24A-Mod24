<?php
session_start();
#Include Init File
require(realpath(dirname(__FILE__))."/init.php");

//Destroy session
$mcMember->logout();

//show error
$error = ( ! empty( ipTV_lib::$request['error'] ) ) ? ipTV_lib::$request['error'] : false;
switch ( $error )
{

    case "BANNED":
        $er_message = "You Are Banned";
        break;

    case "NO_ADMIN":
        $er_message = "Session Expired. Login Again";
        break;

    case "WRONG_CAPTCHA":
        $er_message = "Wrong Captcha Provided";
        break;
}

#Action Page
$action = ( isset( ipTV_lib::$request['action'] ) ) ? ipTV_lib::$request['action'] : "login";
switch ( $action )
{
    case "register":
        if ( ipTV_lib::$settings['allow_registrations'] == 1 )
        {
            $ip = $_SERVER['REMOTE_ADDR'];
            if ( ipTV_lib::$settings['allow_multiple_accs'] == 0 and $mcMember->ValueExists( "ip", $ip ) )
            {
                $er_message = $_LANG['ip_in_use'];
            }
            else
            {
                if ( ! empty( ipTV_lib::$request['login'] ) && ! empty( ipTV_lib::$request['pass'] ) && ! empty( ipTV_lib::$request['pass_confirm'] ) && ! empty( ipTV_lib::$request['email'] ) )
                {
                    $username = ipTV_lib::$request['login'];
                    $password = ipTV_lib::$request['pass'];
                    $pass_conf = ipTV_lib::$request['pass_confirm'];
                    $email = ipTV_lib::$request['email'];

                    $er_message = array();


                    if ( $password !== $pass_conf )
                    {
                        $er_message[] = $_LANG['dif_pass_conf'];
                    }

                    if ( strlen( $password ) < ipTV_lib::$settings['min_password'] )
                    {
                        $er_message[] = str_replace( "{length}", ipTV_lib::$settings['min_password'], $_LANG['min_password'] );
                    }

                    if ( strlen( $username ) > ipTV_lib::$settings['username_strlen'] )
                    {
                        $er_message[] = str_replace( "{length}", ipTV_lib::$settings['username_strlen'], $_LANG['username_strlen'] );
                    }

                    if ( ipTV_lib::$settings['username_alpha'] == 1 and ctype_alnum( $username ) != true )
                    {
                        $er_message[] = $_LANG['username_alpha'];
                    }

                    if ( ! ipTV_lib::IsEmail( $email ) )
                    {
                        $er_message[] = $_LANG['invalid_email'];
                    }

                    if ( $mcMember->ValueExists( "username", $username ) )
                    {
                        $er_message[] = $_LANG['username_exists'];
                    }

                    if ( $mcMember->ValueExists( "email", $email ) )
                    {
                        $er_message[] = $_LANG['email_in_use'];
                    }

                    if ( empty( $er_message ) )
                    {

                        $reg_info = $mcMember->Register( $username, $password, $email, $ip, ipTV_lib::$settings['confirmation_email'] );

                        if ( ipTV_lib::$settings['confirmation_email'] == 1 )
                        {

                            $subject = str_replace( "{SERVER_NAME}", ipTV_lib::$settings['server_name'], ipTV_lib::$settings['email_verify_sub'] );

                            $content = str_replace( array( "{SERVER_NAME}", "{VERIFY_LINK}" ), array( ipTV_lib::$settings['server_name'], "<a href='http://" . ipTV_lib::$settings['site_url'] . "/index.php?action=verify&user_id=" . $reg_info[0] . "&key=" . $reg_info[1] . "'>http://" . ipTV_lib::$settings['site_url'] . "/index.php?action=verify&user_id=" . $reg_info[0] . "&key=" . $reg_info[1] . "</a>" ), ipTV_lib::$settings['email_verify_cont'] );
                            send_email( $email, $subject, $content );
                            $ok_message = $_LANG['register_confirm'];
                        }
                        else
                        {
                            $ok_message = $_LANG['register_ok'];
                        }

                    }
                }
                else
                {
                    $warn_message = $_LANG['complete_fields'];
                }
            }
        }
        else
        {
            $er_message = $_LANG['registration_closed'];
        }

        $template = @file_get_contents( IPTV_TEMPLATES_PATH . 'register.php' );

        break;

    case "forgot":
        if ( isset( ipTV_lib::$request['email'] ) )
        {

            $email = ipTV_lib::$request['email'];
            if ( ! ipTV_lib::IsEmail( $email ) )
            {
                $er_message = $_LANG['invalid_email'];
            }
            else
            {
                $user_id = $mcMember->ValueExists( "email", $email );

                if ( $user_id != false )
                {
                    $verify_key = ipTV_lib::GenerateString();
                    $ipTV_db->query( "UPDATE `reg_users` SET `verify_key` = '%s' WHERE `id` = '%d'", $verify_key, $user_id );

                    $subject = str_replace( "{SERVER_NAME}", ipTV_lib::$settings['server_name'], ipTV_lib::$settings['email_forgot_sub'] );

                    $content = str_replace( array( "{SERVER_NAME}", "{FORGOT_LINK}" ), array( ipTV_lib::$settings['server_name'], "<a href='http://" . ipTV_lib::$settings['site_url'] . "/index.php?action=new_pass&user_id=" . $user_id . "&key=" . $verify_key . "'>http://" . ipTV_lib::$settings['site_url'] . "/index.php?action=new_pass&user_id=" . $user_id . "&key=" . $verify_key . "</a>" ), ipTV_lib::$settings['email_forgot_cont'] );
                    send_email( $email, $subject, $content );
                    $ok_message = $_LANG['forgot_email_sent'];
                }
                else
                {
                    $er_message = $_LANG['no_email_found'];
                }
            }

        }
        $template = @file_get_contents( IPTV_TEMPLATES_PATH . 'forgot.php' );
        break;

    case "new_pass":
        if ( ! empty( ipTV_lib::$request['user_id'] ) && ! empty( ipTV_lib::$request['key'] ) )
        {
            $user_id = intval( ipTV_lib::$request['user_id'] );
            $key = ipTV_lib::$request['key'];

            if ( $mcMember->ValueExists( 'id', $user_id ) )
            {
                $new_password = ipTV_lib::GenerateString();
                $ipTV_db->query( "SELECT `email` FROM `reg_users` WHERE `id` = '%d'", $user_id );
                $email = $ipTV_db->get_col();

                $ipTV_db->query( "UPDATE `reg_users` SET `password` = '%s' WHERE `id` = '%d' AND `verify_key` = '%s' AND `verified` = 1", md5( $new_password ), $user_id, $key );
                if ( $ipTV_db->affected_rows() > 0 )
                {
                    $ipTV_db->query( "UPDATE `reg_users` SET `verify_key` = NULL WHERE `id` = '%d'", $user_id );

                    if ( $ipTV_db->affected_rows() > 0 )
                    {
                        $subject = str_replace( "{SERVER_NAME}", ipTV_lib::$settings['SERVER_NAME'], ipTV_lib::$settings['email_new_pass_sub'] );
                        $content = str_replace( array("{SERVER_NAME}","{NEW_PASSWORD}"), array(ipTV_lib::$settings['SERVER_NAME'],$new_password), ipTV_lib::$settings['email_new_pass_cont'] );
                        send_email( $email, $subject, $content );
                        $ok_message = $_LANG['new_pass_sent'];
                    }
                }
            }
        }
        break;
        
    case "verify":
        if ( ! empty( ipTV_lib::$request['user_id'] ) && ! empty( ipTV_lib::$request['key'] ) )
        {
            $user_id = intval( ipTV_lib::$request['user_id'] );
            $key = ipTV_lib::$request['key'];

            $ipTV_db->query( "UPDATE `reg_users` SET `verified` = 1,`verify_key` = NULL WHERE `id` = '%d' AND `verify_key` = '%s' AND `verified` = 0", $user_id, $key );
            if ( $ipTV_db->affected_rows() > 0 )
            {
                $ok_message = $_LANG['account_verified'];
            }
        }
        break;

    case "login":
        if ( ! empty( ipTV_lib::$request['login'] ) && ! empty( ipTV_lib::$request['pass'] ) )
        {
            $user_id = $mcMember->CheckLogin( ipTV_lib::$request['login'], ipTV_lib::$request['pass'] );
            if ( $user_id )
            {
                session_regenerate_id();
                $mcMember->LoginUser( $user_id );
                exit;
            }
            else
            {
                $er_message = $_LANG['wrong_uinfo'];
            }
        }

        $template = @file_get_contents( IPTV_TEMPLATES_PATH . 'login.php' );

        break;
}

if ( empty( $template ) )
{
    $template = file_get_contents( IPTV_TEMPLATES_PATH . 'login.php' );
}

eval( ' ?> ' . $template . ' <?php ' );

?>
